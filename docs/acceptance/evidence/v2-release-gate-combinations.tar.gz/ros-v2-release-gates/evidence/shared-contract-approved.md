# #37 共享合同（维护者已确认）

维护者于本次 implement-spec 会话明确回复「确认」，批准以下提案。integration branch: integration/research-os-v2。原工作区用户未提交资料只读，不带入实现分支；上下文指针见下。

## 路由
12 逻辑路线：idea-discovery、experiment-plan、experiment-bridge、paper-writing、proof、rebuttal、resubmit、paper-talk、improvement、pickup、route-only、custom（无匹配先设计有界流程，仅真歧义才问）。paper-writing 三变体 general/ml/systems，14 具体 playbook 文件（含 custom）。固定列 route | variant | triggers | applicability | read-only | playbook；唯一键 (route, variant)。用户只读意图优先，材料限定，规模决定编排而非任意大任务→improvement。new task 重匹配。路线文件/路由行随票原子新增，checker 不要求未交付路线。触发词按 #37/#38 与各票自然语言意图。

## 模型
研究项目 .agents/research-os-models.md。单角色单行 `reviewer: provider/model-id | high`。角色 orchestrator/literature/ideator/implementer/analyst/prover/writer/reviewer。thinking off/minimal/low/medium/high/xhigh/max，必须模型支持。正文引用 `Role: reviewer`。缺配置回退当前 session 可用模型及 thinking，明示，不虚构 slug；不能将同上下文自审冒充 fresh 独立审查。显式指定不可用模型停下确认替代，不静默修改。全局 ~/.agents/pstack-models.md 不动。

## 政策与日志
工作区 compute-policy.md，setup 模板共置。默认政策≠本批授权；未配置授权数值默认0，有效期0小时，范围未指定，绝非运行许可。字段：scope（计划/允许写域/环境）；cost_limit/currency（有限非负数/币种）；compute_limit/compute_unit（有限非负数/cpu-core-hour 或 gpu-device-hour，异构分行）；run_limit/run_count_basis（非负整数/planned-run 或 attempt）；per_attempt_cost_limit、per_attempt_compute_limit（同单位且≤累计上限）；concurrency_limit（非负整数，可执行时≥1）；retry_limit（每 planned run 额外 attempt 次数）；valid_for_hours（政策有限非负小时）；valid_until（批次ISO8601带时区）。禁止 unlimited/负数/NaN/无单位；not-applicable 必须解释，未知须停。
experiment-bridge planned-run 名额，research-improvement attempt 名额，保留原合同差异；每attempt均扣费用/算力。重试额度不替代修复轮数。
日志复用政策字段并增加 batch_id、计划、模式、用户确认内容/时刻/依据、valid_until、授权状态；每attempt run_id/attempt_id、最坏预估、起止时间、实际消耗、结果状态、产物路径。
启动前：已消耗+运行中预留最坏消耗+本次最坏消耗≤额度，同时核对单次/名额/并发/重试/范围/过期；恰好上限允许。失败超时无效仍记账，未知不按0释放。pickup重读真实授权/作业状态，不续命。单编排者写账/启动，无法核实并发状态则停，不造runtime。setup不改既有research-log。

## 门声明
既有审批正文旁固定 `Gate: strategy-confirm | before=reply-drafting | approval=explicit-user | source=SKILL.md#回应策略`；无自带审批点 `Gates: none`。ID稳定，source限定当前skill共置正文/references且锚点有效。#39完整人工盘点存活叶skill及references；#38/#40各负责入口/setup。唯一 scripts/check-skills.py 内维护经审阅 skill→预期gate集合基线。校验缺失/多余/重复/格式/来源/none与基线一致。反例含删一条、全部→none、改ID、重复、坏source、整节删。静态不证明自然语言新增门完整，不证明真实执行停点。

## 验收纪律
UV管理全部Python操作；调用tdd，先红后绿。静态唯一入口不拆checker文件。Seam B必须真实工具轨迹，不得拿模拟/静态/字段保留当行为证明。三宿主命令存在不等于登录/能力可用。证据不足票不关闭，#46不打标签；实现完成与行为待验分开记录。

## 指针
原工作区 /Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio：CONTEXT.md（用户未提交v2部分）、docs/adr/0006-gate-density-batch-preauthorization.md、docs/adr/0007-explicit-invocation-and-research-os-entry.md、docs/planning/unknowns-map-research-os.md、docs/planning/spec-v2-research-os.md 均只读参考，不擅自提交。#37为spec，#38-46为tickets，正文Blocked by为task graph，GitHub原生subissues为空。
