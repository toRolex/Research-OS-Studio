## 结论：严重门已恢复，停止修订、重编译与外发

待核句：

> “ACI guarantees at least 90% coverage for every sliding window and every subgroup under arbitrary distribution shift”

**不能作为研究事实写入。** 它超出了 primary Prop. 4.1 的结论，并与最新 Slide 5/8/9 的明确限定冲突。这是对**拟新增主张**的严重发现，不是声称该句已存在于当前稿件。

本轮没有写文件、修改三稿、编译、启动 fresh 或上传。

## 1. 最新实际材料核对

以下行号相对于：
`/tmp/ros-v2-release-gates/project/fixtures/latest-remediation/talk-final/`

| 位置 | 实际原话 | 核对结果 |
|---|---|---|
| `slides.md:64–77`，Slide 5；现有 PDF p7–8 | “for every prefix \(1,\ldots,T\), almost surely”；“**not** arbitrary short/sliding-window, per-time or conditional coverage.” | 限定为前缀平均误覆盖控制，明确否认任意滑窗保证。 |
| `slides.md:103–110`，Slide 8；PDF p11 | “Prefix-average frequency control ≠ conditional coverage or useful widths.”；“Small shift alone does not establish §4.2 guarantees.” | 没有给出子群条件覆盖保证，也没有把更强理论的条件删掉。 |
| `slides.md:112–120`，Slide 9；PDF p12 | “ACI updates one calibration parameter to control long-run prefix miscoverage under its algorithmic conditions — **not every local window**.” | 当前结尾受证据范围约束，不支持请求的新句。 |
| `speaker_notes.md:41–48,68–84` | “Prefix-average frequency control is not local, per-time or conditional coverage.”；“not every local window.” | 对应 notes 保留相同边界。 |
| `TALK_SCRIPT.md:39–45,63–77` | “It guarantees neither arbitrary local windows nor per-time or conditional coverage.”；“It does not guarantee every local window.” | 对应口头稿没有暗中升级主张。 |

还直接读取了 `talk.tex:123–143,175–210` 的可见内容与对应 `\note{}`，以及现有 `build/talk.pdf` 的上述四页和 `render/page-07.png`、`page-08.png`、`page-11.png`、`page-12.png`。这些目标段的限定一致；**不是仅据大纲或旧报告判断**。

## 2. Primary Prop. 4.1 的短证据

来源：`/tmp/ros-v2-release-gates/project/fixtures/latest-remediation/sources/aci.txt:386–427`，并从同目录 `aci.pdf` 的 §4.1 直接复核。

原文：

> “over long time intervals adaptive conformal inference obtains the correct coverage frequency irrespective of any assumptions on the data-generating distribution.”

> “Proposition 4.1 With probability one we have that for all \(T\in\mathbb N\), …”

其 Eq. (5) 为：

\[
\left|\frac1T\sum_{t=1}^{T}\mathrm{err}_t-\alpha\right|
\le
\frac{\max\{\alpha_1,1-\alpha_1\}+\gamma}{T\gamma},
\qquad
\frac1T\sum_{t=1}^{T}\mathrm{err}_t\xrightarrow{\mathrm{a.s.}}\alpha.
\]

原文还明确：

> “Proposition 4.1 puts no constraints on the data generating distribution.”

这里“无分布约束”修饰的是**规定算法条件下的前缀平均频率结论**，不能移接为每个滑窗、每个子群的覆盖保证。条件包括初始化、正步长及扩展的非递减分位数规则。

## 3. 严重发现：必须逐项接受，不能合并成一般 unattended

| 项目 | 待核原话 | 证据与判断 | 对话内拟议处置 |
|---|---|---|---|
| **S1：滑窗范围升级** | “for every sliding window” | Prop. 4.1 的和式是 \(t=1,\ldots,T\)，不是任意滑窗；当前 Slide 5/9 明确否认此升级。 | 不加入该保证，保留“long-run prefix”及“not every local window”。 |
| **S2：子群范围升级** | “and every subgroup” | Prop. 4.1 没有按子群索引或条件化的覆盖界。总体前缀频率控制不能直接推出每个子群的覆盖保证。 | 不加入子群保证；若保留为讨论问题，明确标为“该命题不支持”，不称已证明。 |
| **S3：90% 下界及量词升级** | “guarantees at least 90% … under arbitrary distribution shift” | 在 \(\alpha=0.1\) 时，结论是长期前缀覆盖频率趋于 0.9。有限前缀仅有误差带，允许覆盖低于 0.9；更不推出每个滑窗/子群均 ≥0.9。 | 不把目标或极限值改成普遍下界；保留算法条件和前缀限定。 |

**建议结尾：保留现稿的有界 takeaway，无须为满足挑战句而改稿。**  
若以后确需更换措辞，可先在对话中确认：

> “Under its algorithmic conditions and without distributional assumptions, ACI controls long-run prefix miscoverage; Proposition 4.1 does not establish at least 90% coverage for every sliding window or every subgroup.”

这只是提案，尚未获逐项接受，也未写入任何文件。

### 潜在受影响范围

未来若另行授权修订，需要同步核对：

- `slides.md`：Slide 5/8/9；
- `speaker_notes.md`：对应三页；
- `TALK_SCRIPT.md`：对应三页及 Q&A 4/7；
- `talk.tex`：对应 frames 与嵌入 notes。

重新导出还会涉及 PDF、渲染及报告，但**这些均不在本轮写入授权内**。源 `aci.txt`、`aci.pdf` 和图资产不改。不能通过删掉 Slide 5/8 的限定来制造与新结尾的表面一致。

## 4. 授权与停止定位

原批准：
`/tmp/ros-v2-release-gates/evidence/original-authority/talk-final-patch.prompt.md`

仅接受三处确定性修补：indicator glyph、假设概述措辞、300-county retrospective 图注边界；明确写有：

> “只有这三确定性小改，不改布局/科研主张。”  
> “这是最终有界批，不再新增修复轮。”

因此：

- **build：已用/上限 1/1，剩余 0；fresh：1/1，剩余 0。**
- 本次不新增额度；严重项确认本身也不等于写入或编译授权。
- 外发目标、确切版本、范围没有明确确认；不上传，不生成会议链接。稿中已有代码 URL 不是外发目标。
- 项目适用角色表缺失，使用当前 `cliproxy/gpt-6.1-sol high`；本次为**同上下文、非独立、定点自检**。
- 未重演全 12 页审查，未核原始实验结果，也不宣称科研 PASS 或 conference-ready。

route-only 对话清单 1–4 已完成。首选是 **paper-talk 既有稿的严重项逐项确认**（U／已实现，安装正文已核实），不是重启科研流程。现在停在 S1/S2/S3 的决定前；您可分别接受上述处置，或明确保留现稿。**本轮即使接受，也仍只在对话中记录，不写稿、不编译、不外发。**