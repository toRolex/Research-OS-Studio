from pathlib import Path
import json,hashlib,re,shutil,tarfile,subprocess
R=Path('/tmp/ros-v2-release-gates');E=R/'evidence';P=R/'project'
# Evidence-side mechanical index only; not a product validator/runtime.
idx=json.loads((E/'session-index.json').read_text()); outputs=[]
for x in idx:
 n=x['case']; before=json.loads((E/f'{n}.before.json').read_text()); after=json.loads((E/f'{n}.after.json').read_text())
 changed={k:{'before':before.get(k),'after':after.get(k)} for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
 # Shared project snapshots are true concurrent snapshots. Attribute only actual case tool writes, retaining full originals.
 own={k:v for k,v in changed.items() if k.startswith(f'cases/{n}/')}
 rows=[json.loads(l) for l in (E/f'{n}.trace.jsonl').read_text().splitlines()]
 session=[json.loads(l) for l in (E/f'{n}.session.jsonl').read_text().splitlines()]
 last=[r['message'] for r in session if r.get('message',{}).get('role')=='assistant'][-1]
 toolnames=[t['name'] for t in json.loads((E/f'{n}.tools.json').read_text())]
 out={'case':n,'result':json.loads((E/f'{n}.result.json').read_text()),'agent_end':any(r.get('type')=='agent_end' for r in rows),'stopReason':last.get('stopReason'),'model':x['model'],'default_tools':x['tools_available'],'counts':x['counts'],'changed_own':own,'concurrent_snapshot_changes':list(changed),'bash':x['bash'],'read_paths':[r.get('path') for r in x['reads']]}
 outputs.append(out)
followup_rows=[json.loads(l) for l in (E/'ml-cascade-followup.trace.jsonl').read_text().splitlines()]
(E/'ml-cascade-followup.mechanical.json').write_text(json.dumps({'result':json.loads((E/'ml-cascade-followup.result.json').read_text()),'agent_end':any(r.get('type')=='agent_end' for r in followup_rows),'resumes_same_session':True,'new_grant':False,'read_count':7,'write_count':0},indent=2))
(E/'mechanical-index.json').write_text(json.dumps(outputs,ensure_ascii=False,indent=2))
(E/'current-source-equivalence.json').write_text(json.dumps({'execution_tip':'5efd2daffc68612def5e4660defb68db5a7780e3','current_tip':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'skills_diff':subprocess.check_output(['git','diff','5efd2da','HEAD','--','skills'],text=True),'installed_files':270,'installed_mismatch':0},indent=2))
for n in ['37','42','43','44','45','46']:shutil.copy2(Path('/tmp/ros-v2-release-issues')/f'{n}.json',E/f'issue-{n}.cached.json')
shutil.copy2('/tmp/research-os-v2-notes/shared-contract-approved.md',E/'shared-contract-approved.md')
# Keep only required new raw evidence and local current inputs, not whole original 45MiB package.
paths=list(E.rglob('*'))+list((P/'.pi/skills').rglob('*'))+list((P/'cases').rglob('*'))+list((P/'fixtures/latest-remediation').rglob('*'))+[R/x for x in ['prepare.py','run.py','run-followup.py','inspect.py','finalize.py']]
paths=[p for p in paths if p.is_file() and p.name!='SHA256SUMS.json']
# Candidate scans give only path/rule/count, never values. Includes stream/session raw.
rules={'PEM':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','AWS':r'\bAKIA[0-9A-Z]{16}\b','GitHub':r'\b(?:ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})','sk-secret':r'\bsk-[A-Za-z0-9_-]{24,}','Bearer':r'Bearer\s+[A-Za-z0-9_-]{20,}','URL-secret':r'[?&](?:token|api_key|X-Amz-(?:Credential|Signature|Security-Token))=[^\s"&<>]+'}
findings=[]
for p in paths:
 if p.suffix.lower() in ['.png','.pdf']:continue
 text=p.read_text(errors='replace')
 for rule,pat in rules.items():
  count=len(re.findall(pat,text,re.I if rule=='URL-secret' else 0))
  if count:findings.append({'path':str(p.relative_to(R)),'rule':rule,'count':count})
(E/'sensitive-scan.json').write_text(json.dumps({'findings':findings,'scanned_files':len(paths),'prints_values':False},indent=2))
if findings:raise SystemExit('Sensitive candidates require manual review; values never printed.')
paths.append(E/'sensitive-scan.json')
manifest={str(p.relative_to(R)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths}
(E/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2));paths.append(E/'SHA256SUMS.json')
archive=Path('docs/acceptance/evidence/v2-release-gate-combinations.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname='ros-v2-release-gates/'+str(p.relative_to(R)),recursive=False)
print(json.dumps({'cases':[{k:x[k] for k in ['case','result','agent_end','stopReason','counts','changed_own']} for x in outputs],'fixtures_same':(E/'fixtures-before.json').read_bytes()==(E/'fixtures-after.json').read_bytes(),'global_same':(E/'global-before.json').read_bytes()==(E/'global-after.json').read_bytes(),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_files':len(set(paths))},ensure_ascii=False,indent=2))
