from pathlib import Path
import json,hashlib
R=Path('/tmp/ros-v2-release-gates'); E=R/'evidence'; summaries=[]
for p in sorted(E.glob('*.session.jsonl')):
 rows=[json.loads(l) for l in p.read_text().splitlines()]; tools=[]; finals=[]; models=[]; systemtools=[]
 for row in rows:
  if row.get('type')=='model_change':models.append({k:row[k] for k in ['provider','modelId']})
  m=row.get('message',{})
  if m.get('role')=='system':systemtools=[t['name'] for t in m.get('toolsAdded',[])]
  if m.get('role')=='assistant':
   texts=[b.get('text','') for b in m.get('content',[]) if b.get('type')=='text']
   for b in m.get('content',[]):
    if b.get('type')=='toolCall':tools.append({'name':b.get('name'),'arguments':b.get('arguments'),'message_id':row.get('id'),'prior_text':'\n'.join(texts)})
   if m.get('stopReason')!='toolUse':finals.append({'stopReason':m.get('stopReason'),'text':'\n'.join(texts)})
 name=p.name.removesuffix('.session.jsonl')
 summary={'case':name,'model':models,'tools_available':systemtools,'counts':{n:sum(t['name']==n for t in tools) for n in ['read','bash','edit','write']},'tool_count':len(tools),'reads':[t['arguments'] for t in tools if t['name']=='read'],'bash':[t['arguments'] for t in tools if t['name']=='bash'],'writes':[t['arguments'].get('path') for t in tools if t['name'] in ['write','edit']],'finals':finals}
 (E/f'{name}.tools.json').write_text(json.dumps(tools,ensure_ascii=False,indent=2))
 (E/f'{name}.final.md').write_text('\n\n'.join(f['text'] for f in finals))
 summaries.append(summary)
(E/'session-index.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2))
print(json.dumps([{k:x[k] for k in ['case','model','tools_available','counts','tool_count','writes']} for x in summaries],ensure_ascii=False,indent=2))
