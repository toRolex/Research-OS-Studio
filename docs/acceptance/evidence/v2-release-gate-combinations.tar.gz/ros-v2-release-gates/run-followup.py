from pathlib import Path
import subprocess,time,json,os,signal,hashlib
R=Path('/tmp/ros-v2-release-gates');E=R/'evidence';P=R/'project';n='ml-cascade-followup'
def hashes():return {str(x.relative_to(P)):hashlib.sha256(x.read_bytes()).hexdigest() for x in P.rglob('*') if x.is_file()}
(E/f'{n}.before.json').write_text(json.dumps(hashes(),indent=2))
cmd=['pi','--no-extensions','--no-context-files','--no-skills','--skill',str(P/'.pi/skills/research-os/SKILL.md'),'--approve','--model','cliproxy/gpt-6.1-sol','--thinking','high','--session',str(E/'ml-fourth-external.session.jsonl'),'--mode','json','-p','@'+str(E/f'{n}.prompt.md')]
(E/f'{n}.command.json').write_text(json.dumps({'argv':cmd,'cwd':str(P/'cases/ml-fourth-external'),'timeout_seconds':500,'resumes':'ml-fourth-external.session.jsonl','reason':'clarify cascade not route recommendation; no new operation grant'},indent=2))
t=time.monotonic();timed=False
with (E/f'{n}.trace.jsonl').open('w') as out,(E/f'{n}.stderr').open('w') as err:
 proc=subprocess.Popen(cmd,cwd=P/'cases/ml-fourth-external',stdout=out,stderr=err,start_new_session=True)
 try:rc=proc.wait(timeout=500)
 except subprocess.TimeoutExpired:timed=True;os.killpg(proc.pid,signal.SIGTERM);rc=proc.wait(timeout=10)
(E/f'{n}.result.json').write_text(json.dumps({'exit':rc,'timeout':timed,'wall_seconds':time.monotonic()-t},indent=2))
(E/f'{n}.after.json').write_text(json.dumps(hashes(),indent=2))
print(rc,flush=True)
