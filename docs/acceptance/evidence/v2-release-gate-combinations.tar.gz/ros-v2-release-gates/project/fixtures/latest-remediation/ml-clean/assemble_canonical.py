"""Assemble one new canonical report from original task, artifacts and message_end only.
No models/experiments/compilation/network. Never edits paper, plan or traces.
"""
from pathlib import Path
import json, hashlib, re
ROOT=Path('/tmp/ros-v2-remediation/project/ml-clean')
EV=Path('/tmp/ros-v2-remediation/evidence')
OUT=ROOT/'canonical.md'
assert not OUT.exists(), 'Refuse overwriting canonical'
HEADER=r'''# ML clean batch — canonical delivery and complete independent records

## Disposition and stop
**Delivery: English venue-neutral article `draft`, usable bounded TOY diagnostic with EVIDENCE GAPS and a failed planned-figure branch. Not a submission-candidate, not scientific PASS.**

Current source: `/tmp/ros-v2-remediation/project/ml-clean/paper/main.tex`.
Current successful PDF: `/tmp/ros-v2-remediation/project/ml-clean/build-1/output/main.pdf`.
Plan contribution: `/tmp/ros-v2-remediation/project/ml-clean/plan.md` (the exact reviewed candidate is retained; its provisional/future-tense assertions are not retroactively marked accepted).
This report: `/tmp/ros-v2-remediation/project/ml-clean/canonical.md`.
Original task: `/tmp/ros-v2-remediation/evidence/ml-clean.prompt.md`, verbatim below.

The final independent reviewer reports “Usable bounded diagnostic draft, with unresolved EVIDENCE GAPS for research-level contribution, literature positioning, and verified reproduction.” The parent read the entire original response and the current source/PDF text/all six pages; this quotation is not a substitute for the complete records below.

Stop: the authorized draft and reviews are delivered; figure generation failed after its one local correction, the shared one-round revision allowance is exhausted, and scientific gaps cannot be closed by wording. No fourth build or budget replenishment is requested or presumed. No automatic switch to another workflow. Remaining build/fresh capacity is not a reason to chase acceptance.

## Fixed scope, authorization and identities
Research input is ONLY the four read-only files under `/tmp/ros-v2-remediation/project/fixtures/ml/`: BRIEF.md, ENVIRONMENT.txt, results.csv, fixture_source.py. All were read completely before writing. Only the source's ML block supports the research article; the entire file was inspected, not executed. No first-round drafts/reports were read, and no old batch artifact was overwritten.

Output writes are exclusively this new `/tmp/ros-v2-remediation/project/ml-clean/` tree and `/tmp/ros-v2-remediation/evidence/ml-clean-*` process records/cache. System `/tmp -> /private/tmp` is the explained alias; no `project/project` prefix was added. Sources, skills, fixtures and talk-input stayed read-only. No global configuration changes, install, downloads, GET, experiments, paid computation, rm, push, submission, upload or publication were performed.

No venue or style-ref is specified; no default conference, page limit, submission entry, anonymity rule or acceptance score is inferred. Venue compliance not checked. Author identities, release license/permissions, and venue-specific ethics/disclosure decisions remain unknown/not assessed. The source's MIT skill licenses are not licenses for the study assets.

Project role table `/tmp/ros-v2-remediation/project/.agents/research-os-models.md` was absent. Explicit fallback: actual parent environment PI_PROVIDER=cliproxy, PI_MODEL=gpt-6.1-sol, PI_REASONING_LEVEL=high. Five actual CLI reviewers use `cliproxy/gpt-6.1-sol --thinking high`. All are **same-family independent fresh**, NOT cross-family. Each was launched with an absolute new session, `--no-extensions --no-context-files --no-skills`, no fork/continue/resume and no parent conversation. Prompts only transmit candidate/current source, original material locations, task and fixed boundaries; no author ranking, execution summary, previous review or desired result. Judge receives only the verbatim attack memo, not attack coverage/context. Final reviewer receives original logs/source, not the earlier audit or repair narrative.

Cross-family requirement in paper-claim-audit/claim-stress-test leaves is not satisfied. Their formal leaf capability disposition stays **BLOCKED** even though the explicitly user-authorized same-family independent content checks actually ran. This limitation is not disguised as cross-family or scientific approval.

## Contemporaneous resource ledger and events
Parent visible action ledgers 01–43 precede every tool message; the authoritative parent session is `/tmp/ros-v2-remediation/evidence/ml-clean.session.jsonl`. Child visible ledgers are preserved below and in original traces. This is the parent's actual cumulative accounting, not an independently proven exhaustive history.

| Bucket | Approved maximum | Actual used | Remaining | Evidence |
|---|---:|---:|---:|---|
| TeX build tasks, cumulative all failure/fix/review/stale categories | 3, each <=120s wall | 1 | 2 | build-1 record, raw logs; 2 internal pdflatex passes within one task |
| Fresh sessions | 6 | 5 | 1 | review-1 through review-5 prompt/session/trace/stderr; optional rereview not launched |
| All expression/self-generated-error revision rounds | 1 | 1 | 0 | one edit to generate.py; no later manuscript or plan edits |
| GET | 0 | 0 | 0 | no network requests |
| New experiments / extra paid compute | 0 / 0 | 0 / 0 | 0 / 0 | neither fixture nor any model experiment executed |
| Local plot export | one generation + at most one local correction | both attempted, both failed | 0 local corrections | both SyntaxError logs retained; no output export |

Chronology:
1. Read installed research-os SKILL, exact ML playbook, applicable leaves/resources and original four inputs. Authorized framing was already supplied by BRIEF.
2. Wrote/read exact plan and neutral review-1 prompt; launched/read plan fresh review. Plan permitted proceeding as a bounded draft with open gaps. No negotiated extra plan rounds or scientific acceptance. Raw plan remains unchanged. Locators in it are imprecise (ML relevant lines16–26, environment1–4); original reviewer corrections retained.
3. Wrote/read generate.py; actual uv invocation failed at f-string line24 before any export. One precisely targeted syntax edit consumed the ONLY revision round. Read corrected source, ran one correction export: failed at another f-string line37. No further edit/retry/replacement plot; expected points.tex/results.tex/data-map.json do NOT exist. Both failures remain failures.
4. First manuscript creation: seven complete prose sections, inline table manually transcribed from original CSV with explicit missing-figure marker. This is not a post-review revision of an existing manuscript. No fabricated image or figure caption/old PDF used.
5. Read main.tex; preflight reviewed closed pure TeX, ancestors/link types/hashes/trusted tool versions; one approved controlled-host check-only build in new source/output directory, true return0, then new PDF parsing/full-page rendering/visual inspection. No source modifications.
6. Fresh combined claim/citation, attack, independent judge and final review, read full raw replies and cross-checked artifacts. No post-review manuscript modifications. Existing PDF remains the current-source PDF.
7. Canonical assembly, verification and final delivery; no further workflows.

This ledger supplies the accounting absent from the final review's read set. The reviewer’s M4 completeness concern is preserved, not rewritten as independently closed. Raw parent session is the authoritative contemporaneous record; this retrospective report is not proof of omniscient historical completeness.

## Planning and acceptance contract
The exact 11-assertion plan and entire six-question review are inline below. Contract status: **accepted to proceed as a bounded draft with open gaps**, not all assertions satisfied, no scientific/venue acceptance. One planning-review interaction, no recursive negotiations.

| Assertion | Actual final state |
|---|---|
| A1 four research inputs/read-only | satisfied in observed batch; original hashes retained |
| A2 bounded toy title/abstract/conclusion | satisfied; source line6/12/102 and final review |
| A3 all five rows/shared setup/metric | satisfied; Table1 all rows; supplied code |
| A4 equal means/named observed min–max/no significance | satisfied; source39–40,66–75 |
| A5 code-only no tuning/ties/generator order | satisfied; source24–37; no historical-selection claim |
| A6 recorded compute facts/gap | satisfied for honest reporting; physical compute facts still missing |
| A7 editable plotted figure/render inspected | **violated / failed**: no plot or source export, generator still broken |
| A8 seven sections/limitations prose | satisfied; actual related-work prose explicitly incomplete, not a completed literature review |
| A9 verified references or exact gap | honest visible gap satisfied; source support/positioning remains missing, no citations verified |
| A10 resource/current PDF/snapshot | observed build/PDF/hash checks satisfied, only parent attests cumulative history; no OS isolation claim |
| A11 complete neutral fresh records/capability honesty | five reviews completed and retained verbatim; leaf cross-family gate not met |

No unresolved scientific or asset gap has been waived by the user. The plan’s estimated4.2 pages was a discussion allocation, not a limit; actual PDF6 pages is not an inferred venue violation.

## Experiment report, all observations and traceability
One experiment: fixed1NN versus train-majority on five seeded synthetic two-dimensional32-train/32-test sets, no tuning procedure in supplied source. The code sets y=int(x0+x1>0), majority tie toward1, squared Euclidean nearest point, first encountered distance minimum; training draws precede test draws. Both methods share train/test points within a seed and score correct/32. Synthetic construction only, no external data. Source configuration fidelity is not immutable run provenance.

| Raw CSV line/seed | Majority proportion -> percent | 1NN proportion -> percent | 100*(1NN-majority), pp |
|---|---|---|---|
| 2 / 0 | .53125 ->53.125 | .84375 ->84.375 |31.250|
| 3 / 1 | .5 ->50.000 | .9375 ->93.750 |43.750|
| 4 / 2 | .5 ->50.000 | .875 ->87.500 |37.500|
| 5 / 3 | .46875 ->46.875 | .90625 ->90.625 |43.750|
| 6 / 4 | .53125 ->53.125 | .9375 ->93.750 |40.625|

Means use five equal seed weights, no exclusions. Majority sum percent253.125 /5=50.625%; 1NN450 /5=90.000%; paired mean196.875 /5=39.375pp. Majority min/max46.875/53.125%; 1NN84.375/93.750%; delta31.250/43.750pp. These are exact displayed conversions, not a confidence interval, SE, significance or relative percent gain. All five differences positive; 1NN imperfect in every seed; majority below50% at seed3. No adverse supplied row dropped. ENVIROMENT reports no failed attempts but its source string is not an attempt audit; no original attempt logs supplied.

Trace mapping: abstract line12 and conclusion102 -> all five CSV rows; methods24–40 -> ML code16–24; inline table49–61 and range66 -> rows2–6; arithmetic68–75 -> raw five values; environment42 -> ENVIRONMENT1–4; provenance94–97 -> source historical root4–5/task plus absent invocation records. Independent73-record full trace table is retained below, including repeated occurrences, original quotes/units/raw values/calculations.

Visible draft gaps:
- COMPUTE NEEDED, line42/PDFp3: CPU model/count, memory, per-run wall time, total experimental compute. No estimates.
- FIGURE NEEDED, line77/PDFp4: absent plot and failed local exports; parent read both original failure logs, final reviewer independently read them. Earlier reviewers' inability to check that process history remains in their original record.
- CITATION NEEDED, line83/PDFp4: original method attribution/closest-work passage checks. GET0, no fabricated authors/DOI/keys/bib.
- EVIDENCE NEEDED, line96/PDFp5: original execution command/immutable revision link. Task identifies fixture as executed, independent reproduction not performed.
- Dedicated limitations87–91: finite toy setting, minimal comparator, no ablations/noise/sample-size/domain controls/causal isolation/efficiency, unknown historical attempts. No scope-changing repair.

## Plot/table contribution
Figure1 planned as all ten individual-seed points,0–100% full axis, square/circle grayscale, no fitted line/error band. Local stdlib UV generation source was inspected and run, but both parser failures prevent any export. Failed source remains at generate.py; its “Render-ready” description is inaccurate, as final reviewer notes. **No generated plot was read or visually verified because none exists. No new plot branch was invented after the local correction failed.** Table1 is actual inline TeX in main.tex, all source cells/units/caption manually checked against CSV and independently checked in final rendered PDF p4. Bolding is reading aid, not significance. Missing plot renders no figure number/placeholder image, only a visible evidence marker.
Reproduction command for the attempted export was `UV_CACHE_DIR=/tmp/ros-v2-remediation/evidence/ml-clean-uv-cache uv run --no-project --offline --no-python-downloads --python /opt/homebrew/bin/python3 python /tmp/ros-v2-remediation/project/ml-clean/generate.py`; do not describe it as successful or rerun without authorization. Transformation Python3.14.7 was a writing-host tool, not the recorded experiment Python3.14.4.

## Author drafting self-check (not independent review)
| Checklist subject | Actual state |
|---|---|
| Plan claims/title/abstract/conclusion bounded | checked; C1–C4 represented, partial reproduction not certified |
| Every number/comparison/delta/source units/denominators | checked full table and arithmetic; all raw rows, original precision preserved |
| Matched baselines/unfavorable outcomes/failures | code-level matched data/metric; all rows, imperfect1NN/seed3 majority; unknown attempt history |
| Seeds/splits/search/uncertainty/compute | stated from originals; min–max labeled; compute visibly unresolved |
| Experiment question/setting/observations; no causal/significance inference | checked; “tests whether” ambiguity flagged by final review and unmodified |
| Formal proof/assumption obligations | not applicable: only method-defining equations, no theorem/lemma/proof |
| One-sentence What/Why/So What; importance/novelty | bounded documentary reporting, no scientific significance established |
| Five-part abstract and introduction/related-work structure | prose complete; related-work sourcing remains incomplete; long/disclosure-heavy abstract |
| Methods/terminology/math intuition | source faithful; q/indicator/percent-mean definition improvements remain open |
| Seven sentence principles/micro-clarity | inspected active actors, proximity, context-before-equations, old-to-new, one paragraph function, consistent terms; repetition/notation/polish issues retained |
| Truth-defining scope/negation unaffected by style | no broadening/no facts edited |
| Skim contribution/table/caption/readability | checked six PDF pages; absent hero figure and table float weaken skim path |
| Citation identity/version/metadata/context or gap | no actual cited key; exact visible gap; no guessed source |
| Labels/include/table refs | only tab:results, resolved final pass; no external include/figure/bib |
| Table/raw/caption/style-examples | identical evidence; no resource example numbers introduced |
| Limits/robustness/theory | dedicated limitation; theory N/A |
| Reproducibility/access/experimental details | supplied source and actual environment distinguished, historical command absent, no release promise |
| Ethics/impacts/safeguards/asset license/humans/disclosure | toy source no humans/external data; no ethics approval/compliance inferred; release terms/identities unknown; AI assistance declared, venue rules not assessed |
| Domain-specific NLP/etc | N/A, synthetic2D classifier only |
| Requested sections and write protection | seven complete sections or precise gaps; originals unchanged; no old batch overwritten |
| Checks/capabilities/status separation | author static check != fresh review != build/PDF != scientific validation |

## Compilation and PDF checks
Mode check-only composed. Controlled host execution, no OS isolation guarantee; reviewed closed pure TeX with trusted installed TeX Live2026 article/fontenc/lmodern/amsmath/booktabs, no local script/rc/Lua/shell-escape/dynamic unknown input. `/tmp` alias explained, source regular single-link file; no project Git, content SHA baselines used. Source snapshot created as ordinary file and chmod444, output initially empty. Process-group subprocess timeout115s plus kill/wait ensures authorized120s wall; no new sandbox/runtime, no extra CPU/memory isolation guarantee.

Actual task command/cwd/return/elapsed are inline in record below. latexmk4.87 `-norc` shows rc NONE, pdfTeX1.40.29 with `-no-shell-escape -no-parse-first-line`; two automatic passes within task1; bibliography backend not applicable (latexmk generic “Using bibtex” text did not launch a BibTeX rule). Return0, elapsed0.636660584s, no timeout. Source/readonly snapshot/current fixtures identical before/after. **宿主执行，无OS隔离保证；经审阅未发现越界操作，前后核对未发现源变化。**

Diagnostics (eight resource categories plus other observed issues): missing package/image/citation/bib-syntax/crefname not observed or N/A; no VERIFY markers; explicit NEEDED markers remain. First-pass two undefined tab references and rerun warnings resolve in pass2. Final residual `Overfull \\hbox (1.15834pt too wide) in paragraph at lines94–95`, PDFp5: minor/no clear clipping on actual render, retained/no repair. No other final warnings found in fully read final log. Orphan detection in authorized new output tree: original main.tex root and build snapshot main.tex root, no input/include dependencies, no orphan/conditional .tex; failed expected figure/table sources absent, no deletes.

Actual fresh PDF223502bytes (~0.213MiB), sixA4 pages, PDF1.7, regular/link1, not encrypted, JavaScript no. pdfinfo, pdftotext, pdffonts, pdftoppm all exit0. Full pagination text/images read; final reviewer also independently parsed actual PDF. No ??/[?]/VERIFY in text, all NEEDED markers visible. All11 font rows emb=yes/sub=yes/uni=yes. Current source hash be5fb652d2f3e4ae59cbfc8e25017016ea470efa1e93902dddb5cedd3f5b1d86 equals snapshot and final reviewer cmp0.

| PDF check | Actual state/evidence |
|---|---|
| Existence/newness/actual parse | successful fresh build-1 output, nonzero223502 bytes, parse0 six pages; not old PDF |
| Actual table/figure content | table p4 faithful/readable; plot absent, no bogus image, visible marker |
| Labels/font/glyph clarity | all six pages viewed, formulas/table readable; no overlap/clipping |
| Headings/whitespace/breaks | no isolated heading found; §4 final short line starts p5, p6 lower whitespace; polish issues retained |
| Float proximity | table first cited p2, result discussion p3, displayedp4: two-page introduction-to-table drift; no plot |
| Table alignment/precision | p4 all numeric columns aligned and three decimals; caption self-contained |
| Margins | p5 tiny1.15834pt log warning, no consequential visual crop; warning retained |
| Total/page ranges | prose p1–6, conclusionp6; no reference section or appendix; six total, not4.2 estimate |
| Anonymous/stage rules | N/A to unspecified-venue internal draft, author placeholder retained, no venue anonymity compliance claimed |
| Font embedding | all11 actual font rows emb=yes |
| Appendix/supplement/size/template/upload rules | no appendix/supplement; size measured; venue-specific limit/template/entry not checked |
| Submission readiness | **not established**, draft only, scientific/source/figure/capability gaps |

## Parallel independent reviews and mechanical dispositions
| Review | Actual execution | Scope findings | Formal status |
|---|---|---|---|
| Plan / review1 | fresh CLI read exact plan and4 raw inputs | C1–C3 bounded support, C4 partial; six questions and11 assertions addressed, future artifacts not yet verified | proceed as draft with gaps, no scientific acceptance |
| Claim / review2 | same fresh session with citation task, whole current draft/4 raw inputs/all pages |73 exact_match,0 all other labels, total reconciled; workflow histories outside experimental count | **BLOCKED** cross-family leaf gate; content fidelity findings preserved, not scientific PASS |
| Citation / review2 | actually enumerated full source/render |0 actual occurrences/keys/bib, no guessed sources; closest-work/history unverified | no actual citation scope; literature evidence gap, NOT literature PASS |
| Proof | not invoked | full manuscript has no theorem/lemma/proof; methods formulas are configuration definitions | not applicable |
| Attack / review3 | fresh independent whole-paper read | single202-word paragraph plus separate coverage, no invalid/theorem attack invented | recorded valid attack, cross-family gate absent |
| Judge / review4 | different new session, same source list+verbatim memo only |4 points:0 answered,4 partial,0 unresolved;1critical+3major; all covered | **BLOCKED** cross-family leaf gate; content mapping **WARN / partial_major_or_critical** (U empty,P contains major/critical) |
| Final / review5 | fresh full source/originals/process logs/actualPDF parsing/all6 pages | usable bounded diagnostic + EVIDENCE GAPS, no critical numerical issue;4major evidence/process gaps,5minor issues | no scientific PASS, no invented venue score |

No reviewer-origin text was edited, severity reduced, or old failure upgraded. No material criticism is omitted. Attack's contribution objection remains open at research level; honest toy reporting answers scope overclaim but does not establish advance.

## Independent review and revision rounds
| Event | Score | Findings | Applied manuscript changes | Rebuild |
|---|---|---|---|---|
| Plan fresh review | none requested | locators/source-level wording, future acceptance evidence | included accurate expressions in first creation, plan candidate unchanged | not yet applicable |
| Sole shared revision round | N/A | figure generation SyntaxError | no manuscript existed; one generate.py syntax edit, second export still failed | not a TeX build |
| Baseline article/build1 | N/A | full prose/table/gaps; one small hbox | first article creation only | success0, current source/PDF |
| Claim/citation/stress/final | unavailable/no venue scale | full records below | **none**, revision allowance exhausted | **no recompile needed**, source unchanged |

Open expression-only recommendations (NOT applied): documentary/pedagogical contribution wording, “tests whether” non-inferential phrasing, q/indicator/mean-scale definitions, repetition reduction, tiny overflow/float/section-break polish. Research-level actions (NOT executed): original source/invocation and compute evidence, actual literature/closest-work verification, substantive question plus claim-matched stronger evidence if desired. Broken plot artifact needs future separately authorized syntax correction/export/visual check; do not pretend a rewrite alone generates it.

## Read-resource coverage and exact playbook checklist
Installed `/tmp/ros-v2-remediation/project/.pi/skills/research-os/SKILL.md` and playbooks/paper-writing-ml.md read fully, matched ML not general/systems. All named applicable leaves and resources were read in visible parent tools before execution. Resource references: ML composition-map/experiment-reporting/reviewer-expectations/report template/LICENSE; paper-plan template/section-planning/venue-and-citations; plotting figure-note/data-visualization/style-guide/table-and-review; drafting writing-guide/draft-checklist/citation-workflow/venue-and-format; compile build/diagnostics/pdf-checks/compilation template; claim audit full audit-prompt/report; citation verification-methods/report; stress attack/adjudication/report rules. Conditional venue/style/systems/proof/extended-axis resources were not applicable; none claimed executed. No resource truncation occurred.

The original playbook steps, unchanged, followed by status/evidence:

1. 读 `skills/writing-cycle/ml-paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。补实验不在本次授权内。
   - completed: leaf read fully, user fixed prompt authorizes every write/build/fresh boundary; new experiments0.
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/ml-paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。
   - completed: exact map read; audit own full prompts used; no plan/author summary transmitted to evidence reviews.
3. ML 专属纪律读全文：
   - `skills/writing-cycle/ml-paper-writing/references/experiment-reporting.md`
   - `skills/writing-cycle/ml-paper-writing/references/reviewer-expectations.md`
   - 用户指定 venue 时读 `skills/writing-cycle/ml-paper-writing/references/venue-checklists.md`
   - completed: first two fully read; venue conditional N/A, explicitly unspecified.
4. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`
   - executed with failure/blocking: all7 applicable leaves/resources read and actual branches attempted; plot failed after correction, claim/stress cross-family blocked, same-family content review completed; proof condition N/A. Not marked unqualified successful completion.
5. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。
   - delivery/stop: draft only, current-source PDF and this complete report. Verification of report occurs immediately after assembly; final user delivery does not launch another workflow.

## Remaining decisions and untouched workflows
The user may retain this bounded candidate. Stronger claims, public release or repaired graphics require separate material/authorization; no automatic follow-on. All following remain NOT STARTED: paper-writing (general), systems-paper-writing, paper-compile-repair, apply-citation-fixes, proof-repair, rebuttal, resubmit-pipeline, paper-talk, research-improvement. No posting/acceptance declared. Existing old batches never read for reuse or overwritten.

## Full original records (verbatim, not replaced by links)
The sections below include original user request, system prompt, exact reviewed plan, all five exact independent requests and every visible assistant message_end text including the complete final response. The final response is not duplicated from message_start/update. Tool return raw records/session remain authoritative for proving direct reads. Extracted textual appendix omits private thinking and toolCall JSON, not reviewer visible prose. Reviewer response boundaries are explicit so wording is never polished into executor text. Identity values are taken from actual message_end objects, not role labels. Raw trace/session/stderr paths and hashes retained for audit, not a substitute for inline original text.
'''
parts=[HEADER]
def verbatim(title,text):
 parts.extend(['\n## '+title+'\n','\n`````text\n',text,'\n`````\n'])
verbatim('Original approved user request', (EV/'ml-clean.prompt.md').read_text())
verbatim('Shared independent reviewer system prompt',Path('/tmp/ros-v2-remediation/reviewer-system-round2.md').read_text())
verbatim('Exact reviewed candidate plan (unmodified)',(ROOT/'plan.md').read_text())
verbatim('Build1 original record',(ROOT/'build-1/record.json').read_text())
verbatim('First figure-generation error log',(EV/'ml-clean-figure-generation.log').read_text())
verbatim('Single local-correction error log',(EV/'ml-clean-figure-correction.log').read_text())
meta=[]
for n in range(1,6):
 prefix=EV/f'ml-clean-review-{n}'
 prompt=Path(str(prefix)+'.prompt.md'); trace=Path(str(prefix)+'.trace.jsonl')
 session=Path(str(prefix)+'.session.jsonl'); stderr=Path(str(prefix)+'.stderr')
 assert prompt.is_file() and trace.is_file() and session.is_file()
 verbatim(f'Review {n}: complete original request',prompt.read_text())
 replies=[]; identities=[]; stop=[]; tool_reads=[]
 for line in trace.read_text().splitlines():
  e=json.loads(line);m=e.get('message',{})
  if e.get('type')=='message_end' and m.get('role')=='assistant':
   texts=[c['text'] for c in m.get('content',[]) if c.get('type')=='text']
   for t in texts:replies.append((m.get('stopReason'),t))
   identities.append({k:m.get(k) for k in ('provider','model','api','stopReason')})
   stop.append(m.get('stopReason'))
   for c in m.get('content',[]):
    if c.get('type')=='toolCall':tool_reads.append({'name':c.get('name'),'arguments':c.get('arguments')})
 assert stop and stop[-1]=='stop', f'No complete final response review{n}'
 for i,(reason,text) in enumerate(replies,1):
  verbatim(f'Review {n}: original assistant message_end {i} ({reason})',text)
 verbatim(f'Review {n}: stderr',stderr.read_text())
 final='\n'.join(text for reason,text in replies if reason=='stop')
 if n==3:
  memo=re.split(r'(?m)^### Coverage',final.split('### Attack memo',1)[1],maxsplit=1)[0].strip()
  assert len(memo.split())<=250 and len(memo.split())==202
  assert memo in (EV/'ml-clean-review-4.prompt.md').read_text()
 entry={'review':n,'prompt_path':str(prompt),'trace_path':str(trace),'session_path':str(session),'stderr_path':str(stderr),'visible_message_end_blocks':len(replies),'identities':identities,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (prompt,trace,session,stderr)}}
 meta.append(entry)
 parts.append('\nOriginal tool-call navigation (raw trace authoritative; not proof from a passed-in path):\n')
 parts.append('`````json\n'+json.dumps(tool_reads,ensure_ascii=False,indent=2)+'\n`````\n')
verbatim('Actual independent identity and raw-record manifest',json.dumps(meta,ensure_ascii=False,indent=2))
parts.append('\n## Actual output inventory at assembly\n\n')
for p in sorted(ROOT.rglob('*')):
 if p.is_file():parts.append('- `'+str(p)+'` ('+str(p.stat().st_size)+' bytes)\n')
parts.append('- `'+str(OUT)+'` (this new canonical file)\n')
parts.append('\nExpected failed exports points.tex/results.tex/data-map.json are absent, not delivered. Source still equals successful build1 snapshot; no post-review alteration. This batch stops at this draft+review/report handoff.\n')
source=ROOT/'paper/main.tex';snap=ROOT/'build-1/source/main.tex'
assert source.read_bytes()==snap.read_bytes()
assert hashlib.sha256(source.read_bytes()).hexdigest()=='be5fb652d2f3e4ae59cbfc8e25017016ea470efa1e93902dddb5cedd3f5b1d86'
text=''.join(parts)
OUT.write_text(text)
print('WROTE',OUT,'bytes',OUT.stat().st_size,'lines',len(text.splitlines()))
print('Each original prompt and each assistant message_end text inserted exactly once per boundary; attack memo intentionally also occurs verbatim inside judge request.')
print('Fresh actual identity:',json.dumps(meta[-1]['identities'],ensure_ascii=False))
