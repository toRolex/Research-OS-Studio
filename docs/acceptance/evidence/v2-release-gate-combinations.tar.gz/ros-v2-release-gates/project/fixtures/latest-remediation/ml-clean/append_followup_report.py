"""Append the specifically authorized followup to existing canonical, preserving its old bytes.
Only report writes. No research/content edit, experiment, build, network or reviewer.
"""
from pathlib import Path
import json, hashlib, re
ROOT=Path('/tmp/ros-v2-remediation/project/ml-clean')
EV=Path('/tmp/ros-v2-remediation/evidence')
REPORT=ROOT/'canonical.md'
old=REPORT.read_bytes()
assert hashlib.sha256(old).hexdigest()=='1757e7e28bc7083bede605107551d92724093d91a9aa642adc5f804f1726520c'
HEADER='''

# ML_WRITING_REPORT — explicitly authorized ML stress/figure followup

This appended section is the CURRENT delivery state. The entire original report above is preserved as the earlier build-1 / same-family review record, including its failed plot, BLOCKED rows, original requests/replies and earlier stopping decision. No historical failure or capability label is changed or retrospectively upgraded. This is a continuation of the same ML route, not a new task or a new budget bucket pretending the original attempts never happened.

## Current delivery and stop
- Delivery remains English venue-neutral article **draft**, bounded five-seed TOY diagnostic, with **EVIDENCE GAPS**, not a scientific or submission PASS.
- Current source `/tmp/ros-v2-remediation/project/ml-clean/paper/main.tex` includes `paper/figures/points.tex` and `paper/tables/results.tex`.
- Latest actual current-source PDF `/tmp/ros-v2-remediation/project/ml-clean/build-2/output/main.pdf`: **7 Letter pages,226281 bytes**, parsed and all seven pages visually inspected by parent and complete final reviewer. Previous build-1 PDF is archival, not current.
- Real figure: ten individual observed seed accuracies, figure1/PDFp5; editable pure TeX picture source; open squares majority, filled circles1NN, y-axis0–100%; original all-five-row CSV, no filtering/fits/error bars/new experiments. Table1/PDFp4 directly includes generated CSV table; data-map.json preserves exact values/transformation.
- Different-family stress content verdict **WARN / unresolved_major_or_minor**: seven atomic points,2 answered,4 partial,1 unresolved (P6 major). Partial points include2 critical and2 major; NO unresolved critical, so do not turn partial critical into FAIL. Scientific scope/provenance/literature objections remain open. No scientific acceptance inferred.
- Final full latest-draft review: usable bounded TOY candidate with3 MAJOR evidence gaps and5 MINOR expression/presentation recommendations, no CRITICAL found within read scope. This review is same-family GPT independent fresh, not cross-family stress.
- STOP: added3 fresh used, original unused1 forfeited; callable fresh remaining0. Sole extra technical correction used. No further review, post-review source modification, new analysis, experiment, GET or workflow switch. Residual build allowance1 is not a reason to recompile unchanged contents or seek PASS.

## Scope/authorization and true resource closure
Original and followup approvals are verbatim below; output remains exclusively `/tmp/ros-v2-remediation/project/ml-clean/` and process evidence `/tmp/ros-v2-remediation/evidence/ml-clean-*`. Source fixtures/skills remain read-only; fixture_source.py NEVER executed; no new models/experiments, external retrieval, install, paid compute, upload/publication/push/rm/global changes. No venue/style reference assumed.

Original role table absent; GPT parent fallback remains actual cliproxy/gpt-6.1-sol high. Followup explicitly approves GLM reviewers, verified by each new session's model_change and actual assistant provider/model, not role name. Attack and judge have different new session IDs, both cliproxy/glm-5.3-flash high, **different-family relative to GPT parent**. Final is cliproxy/gpt-6.1-sol high, **same-family independent fresh**. No fork/continue/resume or parent histories.

Before any followup launch, parent parsed original actual session and5 child sessions: exactly5 independent CLI launches, including the old same-family attack and judge. Original bucket6 CLOSED with5 used and1 forfeited; no false decrement for BLOCKED attempts. Read-only string probes initially also matched their own source as build candidates; parent examined candidate commands and identified exactly1 actual old latexmk task (event85ac8901), not the probes. New task build2 increments original cumulative counter; no reset.

| Resource | Original actual | Followup actual | Cumulative / maximum | Remaining usable |
|---|---|---|---|---|
| Fresh |5/6 including old stress; closed, unused1 forfeited|3/3: GLM attack, GLM judge, GPT latest full review|8/9 authorized ceiling|0 callable; nominal unused1 belongs to closed original bucket|
| TeX build tasks |1|1 new build2|2/3|1 unused, not launched|
| Original shared revision |1/1, line24 error correction retained as used|not reset|1/1|0|
| Specific extra technical correction |none|1/1 line37, plus explicitly permitted real-figure/table integration|one separately approved correction|0|
| GET / new experiments / extra paid compute |0|0|0/0|0|

Actual CLI wall limits enforced via existing UV Python subprocess and new process group: attack/judge <=900s, latest review<=1800s; wait895/1795s plus kill/wait allowance, foreground. Actual runtimes/return codes in verbatim run records below: attack71.482s0; judge152.572s0; final343.169s0, none timed out, no retries. Timeout would have consumed attempt and retained trace/session. Build2 <=120s, wait115 plus termination allowance; actual0.765159s,return0,two internal TeX passes counted as one task.

## Exact technical correction and figure/table integration
One additional approved targeted change to generate.py line37: malformed rf TeX put/makebox string replaced by `% (x-10,i)` formatting. Earlier two SyntaxError logs and original1/1 correction remain in original canonical. New offline UV invocation actually exited0 and created points.tex/results.tex/data-map.json; new log `/tmp/ros-v2-remediation/evidence/ml-clean-stress-figure-generation.log` retained. Script only reads original CSV and applies Decimal percentage/delta/equal mean/range/display transforms; no fixture/model execution. No rerun after the successful export.

Precise unified diff below preserves original main.tex (from build1 snapshot) versus latest and specific generator-line fix. Integration: trusted system graphicx for rotation, real two input dependencies, plot/caption replacing FIGURE NEEDED, removal only of now-obsolete figure-gap words in abstract/limits/conclusion. No numerical/research fact or headline/framing/seed changed; no scientific review suggestions applied. Generated table adds upward delta direction arrow, values unchanged. Figure and table source read in full before building/reviewing.

Old reviews remain limited to old build1; original claim/citation audits not rerun or extended by assertion. Latest full review checks new complete draft/figure/table; original claim cross-family leaf capability remains BLOCKED, not falsely satisfied by a different stress reviewer. Proof-review remains not applicable (no theorem/lemma/proof added).

## Latest build and parent artifact checks
Closed reviewed pureTeX: main plus exactly tables/results.tex and figures/points.tex; local inputs ordinary single-link non-symlink files; system `/tmp -> /private/tmp` explained. All3 ordinary readonly-use snapshots byte equal current, fresh new empty build2 output, latexmk-norc/rcNONE, pdflatex-no-shell-escape/-no-parse-first-line. Trusted TeXLive2026 packages, no local rc/Lua/project executable/no installed dependencies. **宿主执行，无OS隔离保证；经审阅未发现越界操作，前后核对未发现源变化。** No new sandbox/runtime or extra CPU/memory isolation guarantee. Fixture4 hashes unchanged.

PDF actual parse: pdfinfo/pdftotext/pdffonts/pdftoppm exit0; complete latest pagination text and7 actual renders read. Final reviewer directly parsed actual binary with existing pdfinfo/pdffonts/pdftotext/pdfimages(stdout only),3 source/snapshot cmp0, extracted text byte-identical, no raster image objects listed, all12 font rows embedded/subset/uni yes includingLCIRCLE10. PDFnotTagged; complete accessibility certification not performed. New page size is Letter612x792, not the older A4; no venue size requirement exists, not inferred compliance/violation.

- Figure quality: all10 centers verified from original CSV; squares bottom-left offset+2 correctly maps center; actualp5 legend/markers/axes/caption readable in grayscale,no overlapping/cropped labels,no fake uncertainty.
- Layout/headings:7 pages all checked, figure-onlyp5/late float and finalp7 lower whitespace retained; no content missing or solitary heading noticed. Table first citedp2/displayp4; figure first citedp4/displayp5 after positioning prose; polish limitation.
- Tables:all five seed rows and mean,three-decimal precision, bolding/units/direction/caption match rawCSV.
- Warning:first pass undefined table/figure refs resolved in pass2; residual overfullhbox1.15834pt lines88–89/PDFp6 retained, no clear visual clipping. No repair performed. Generic latexmkUsingbibtex line does not mean bibliography execution; bibliography still absent.
- Scope/needed markers:COMPUTE p3,CITATION p4,EVIDENCEp6 remain; no FIGURE NEEDED in latest source/PDF. Current source-dependent includes reachable and main.fls confirms all3 input files; no new orphan claim beyond supplied scope.
- No venue scoring/anonymity/page/font/upload/ethics approval inferred, no submission-ready assertion.

## New stress coverage, classifications and limits
Actual attacker read10 textual originals/current-source files plus7 page images; complete memo201 whitespace words, single paragraph, independent Coverage retained; binaryPDF not opened directly, authorized images/text alternative used. Judge independently same10 textual files+7 pages+only read grep for locators, no attack session/coverage. Core read/material access complete and identity gate met for this NEW stress execution only.

| Point | Classification | Severity | Scope / unresolved issue |
|---|---|---|---|
|P1 headline tautology/coin-flip structural expectation|partially_answered|critical|qualitative claim only, scientific informativeness disputed|
|P2 no theorem|answered_by_current_text|major|draft makes no theory claim|
|P3 no significance test|partially_answered|major|scope disclaimed, no inferential claim established|
|P4 minimal baseline/no controls|partially_answered|major|finite comparison not competitiveness|
|P5 provenance/compute|partially_answered|critical|record consistency not original producing-run authentication|
|P6 visible gaps/zero refs|still_unresolved|major|needed evidence/literature genuinely open|
|P7 AI-assistance/no venue policy|answered_by_current_text|minor|venue-neutral and openly disclosed|

Totals2 answered/4 partial/1 unresolved,7 points. Partial2critical+2major; unresolved0critical+1major. U nonempty with no critical -> **WARN, unresolved_major_or_minor**. No reduction of severity/no executor reinterpretation as scientific approval. Judge Net assessment and maximum3 actions appear VERBATIM below, not replaced by this table.

Research recommendations from judge (restore producing-run link, structural analysis, new geometry baseline/inference/rerun) are NOT executed; statistical analysis/new theorem/new data is outside fixed inputs and specific technical correction. Writing recommendations to remove/convert placeholders also NOT applied; missing facts are not closed by deletion. The new real graph closes the prior figure-artifact deficiency at the current version, not the scientific gaps or historical source error.

Process deviation retained honestly: GLM attack visible tool ledgers are English and partly basename/grouped instead of required Chinese full-absolute per tool. GLM judge visible ledgers are Chinese but grouped without each actual absolute path. Parents' ledgers are Chinese and paths visible; child deviations are preserved verbatim, not silently rewritten or called full protocol compliance. Their actual tool JSON/returns in rawtrace still prove direct file reads. FinalGPT ledgers contain Chinese complete absolute locations. No extra fresh repair/retry used for these deviations.

## Latest complete final review and immutable reviewed version
New same-family GPT final reviewer read entire candidate, generated point/table sources,map/generator/rawCSV4,all3 snapshot copies,rawbuild2 logs/fls/font/meta/figure log,all7 pages and binary PDF. Report states usable limitedTOY candidate; noCRITICAL,3MAJOR (producing-run link;compute/attempt/cumulative-history;literature/research value),5MINOR (q definition;plural tasks;tests whether;float/hbox;workflow language/repetition). Full original response follows.

Parent read full feedback, original current source/figure/table/CSV,map,actual build/meta/fonts/diff and all7 pages, confirmed all10 points/means/ranges and actual identity/readcoverage. Parent's cumulative ledger supplies observed process consumption but DOES NOT overwrite reviewer warning that single-record history was not independently proven in its readset. Quantitative agreement/current hashes do not prove original experimental execution. No science PASS claimed.

**Since the final review was launched, ZERO changes to reviewed main.tex, points.tex, results.tex,generate.py,data-map.json or latestPDF.** Final run record before/after hashes match; final verification will compare again. No build3/4, no ninth/tenth fresh, no new general/Systems/improvement/repair/citation-fix/rebuttal/resubmit/talk workflow. Report-only append is the authorized record operation, not an unreviewed manuscript revision. Existing original report and raw5 reviewer records remain intact.

## Full original followup records
Verbatim requests/replies include visible assistant message_end text only, never duplicated from message_start/update; private thinking not extracted. Actual session model_change/thinkingLevel and run records are included. Rawsession/rawtrace remains authoritative, links/hashes are not substitutes for complete original feedback. No author summary/repair narrative/previous review was given to new reviewers; judge alone receives exactattackmemo, not coverage. Latest reviewer receives rawprocess evidence but no previous opinions.
'''
parts=[HEADER]
def verbatim(title,text):
 parts.extend(['\n## '+title+'\n\n`````text\n',text,'\n`````\n'])
for name in ('ml-clean-stress-followup.prompt.md','ml-clean-stress-authorization.md'):
 verbatim('Original specific approval '+name,(EV/name).read_text())
verbatim('Neutral GLM reviewer system original',Path('/tmp/ros-v2-remediation/reviewer-system-stress.md').read_text())
verbatim('Precise authorized diff',(ROOT/'followup-diff.patch').read_text())
verbatim('Actual successful figure-generation original log',(EV/'ml-clean-stress-figure-generation.log').read_text())
verbatim('Actual editable figure source',(ROOT/'paper/figures/points.tex').read_text())
verbatim('Actual table source',(ROOT/'paper/tables/results.tex').read_text())
verbatim('Complete CSV mapping',(ROOT/'data-map.json').read_text())
verbatim('Build2 original record',(ROOT/'build-2/record.json').read_text())
manifest=[]
for role,model in (('attack','glm-5.3-flash'),('judge','glm-5.3-flash'),('final','gpt-6.1-sol')):
 prefix=EV/f'ml-clean-stress-{role}'
 prompt=Path(str(prefix)+'.prompt.md');trace=Path(str(prefix)+'.trace.jsonl');session=Path(str(prefix)+'.session.jsonl');run=Path(str(prefix)+'.run.json');stderr=Path(str(prefix)+'.stderr')
 identity=[];sessionid=None
 for line in session.read_text().splitlines():
  e=json.loads(line)
  if e.get('type')=='session':sessionid=e['id']
  if e.get('type') in ('session','model_change','thinking_level_change'):identity.append(e)
 assert any(e.get('type')=='model_change' and e.get('provider')=='cliproxy' and e.get('modelId')==model for e in identity)
 assert any(e.get('type')=='thinking_level_change' and e.get('thinkingLevel')=='high' for e in identity)
 verbatim(role+': complete original neutral request',prompt.read_text())
 replies=[];calls=[]
 for line in trace.read_text().splitlines():
  e=json.loads(line);m=e.get('message',{})
  if e.get('type')=='message_end' and m.get('role')=='assistant':
   assert m.get('provider')=='cliproxy' and m.get('model')==model
   for c in m.get('content',[]):
    if c.get('type')=='text':replies.append((m.get('stopReason'),c['text']))
    if c.get('type')=='toolCall':calls.append({'name':c.get('name'),'arguments':c.get('arguments')})
 assert len([t for reason,t in replies if reason=='stop'])==1
 for i,(reason,text) in enumerate(replies,1):verbatim(f'{role}: original assistant message_end {i} ({reason})',text)
 if role=='attack':
  final='\n'.join(t for reason,t in replies if reason=='stop')
  memo=re.split(r'(?m)^### Coverage',final.split('### Attack memo',1)[1],maxsplit=1)[0].strip()
  assert len(memo.split())==201 and len(re.split(r'\n\s*\n',memo))==1
  assert memo in (EV/'ml-clean-stress-judge.prompt.md').read_text()
 verbatim(role+': actual new-session identity records',json.dumps(identity,ensure_ascii=False,indent=2))
 verbatim(role+': original foreground run record',run.read_text())
 verbatim(role+': original stderr',stderr.read_text())
 manifest.append({'role':role,'actual_model':model,'session_id':sessionid,'raw_paths':{p.suffix:str(p) for p in (prompt,trace,session,run,stderr)},'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (prompt,trace,session,run,stderr)},'actual_tool_calls':calls})
assert manifest[0]['session_id']!=manifest[1]['session_id']!=manifest[2]['session_id']
verbatim('All original raw paths/hashes and actual-tool coverage manifest',json.dumps(manifest,ensure_ascii=False,indent=2))
finalrecord=json.loads((EV/'ml-clean-stress-final.run.json').read_text())
for path,h in finalrecord['reviewed_before_sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
buildrecord=json.loads((ROOT/'build-2/record.json').read_text())
for rel,h in buildrecord['source_sha256'].items():
 assert (ROOT/'paper'/rel).read_bytes()==(ROOT/'build-2/source'/rel).read_bytes()
 assert hashlib.sha256((ROOT/'paper'/rel).read_bytes()).hexdigest()==h
for name,h in buildrecord['raw_before'].items():assert hashlib.sha256((Path('/tmp/ros-v2-remediation/project/fixtures/ml')/name).read_bytes()).hexdigest()==h
parts.append('\n## Followup stop / latest identities and source evidence retained\nOriginal canonical bytes unchanged; new3 requests/full feedback inline; new2GLM different-family stress + new1GPT same-family latest full review. Totalfresh8/9 but callable0, build2/3, originalrevision1/1 plus explicitly approved technicalcorrection1/1,GET0/newexperiment0. OldBLOCKED and both failedfigure logs remain historical. Reviewedsource/PDF unchanged; no scientificPASS or submission. Delivery stops here.\n')
addition=''.join(parts).encode()
with REPORT.open('ab') as f:f.write(addition)
assert REPORT.read_bytes().startswith(old)
print('APPENDED',len(addition),'bytes /',len(addition.decode().splitlines()),'lines')
print('ORIGINAL preserved bytes',len(old),'oldlines',len(old.decode().splitlines()))
print('TOTAL',len(REPORT.read_bytes()),'bytes /',len(REPORT.read_text().splitlines()),'lines')
print('Latest reviewed content unchanged; source3 snapshots/raw4 hashes unchanged; no new reviewer/build/content edits.')
