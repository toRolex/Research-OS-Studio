# Paper-talk 最后三处定点修补报告

**本批执行结束并停止。三处定点修补在当前实际版本的所核范围内通过；独立核查未发现公式或版面硬错误。仍保留 EVIDENCE GAP／交付未核，不作科研PASS或conference-ready认证。**

授权：`/tmp/ros-v2-remediation/evidence/talk-final-patch.prompt.md`。同一paper-talk任务，非新科研流程。旧micro的完整REVISE、编译1/1、fresh1/1以及所有更早失败/超时均保持原样，只读保留、不追认。本批是用户明确授予的最终有界批，不新增修复轮。

项目角色表缺失，沿用已明示的当前模型回退。父/子实际均 `cliproxy/gpt-6.1-sol | high`；独立审查为真实新session，**same-family independent fresh，非cross-family**。

## 1. 实际交付与读取范围

所有新产物限 `/tmp/ros-v2-remediation/project/talk-final/`：

| 产物 | 实际绝对路径 |
|---|---|
| Slides | /tmp/ros-v2-remediation/project/talk-final/slides.md |
| Notes | /tmp/ros-v2-remediation/project/talk-final/speaker_notes.md |
| Spoken script/全部Q&A | /tmp/ros-v2-remediation/project/talk-final/TALK_SCRIPT.md |
| 可编辑源 | /tmp/ros-v2-remediation/project/talk-final/talk.tex |
| 当前真实compiled source | /tmp/ros-v2-remediation/project/talk-final/build/talk.tex |
| 当前真实PDF | /tmp/ros-v2-remediation/project/talk-final/build/talk.pdf |
| 最新全12PNG | /tmp/ros-v2-remediation/project/talk-final/render/page-01.png 至 page-12.png |
| 原图完整副本 | /tmp/ros-v2-remediation/project/talk-final/figures/fig1-stock-coverage-05.png；fig3-election-coverage-10.png |
| 本报告 | /tmp/ros-v2-remediation/project/talk-final/talk-report.md |

构建记录、stdout-stderr、TeX所有副产物及实际PDF全文/metadata/fonts保存在build/。过程仅evidence/talk-final-*，其中 `talk-final-diff.md` 保留四稿原文unified diff。所有写入后已同绝对路径read。

沿用当前session以前实读的research-os入口、paper-talk叶/resources及primary全文，不重读全部叶/论文、不运行旧测试。本批父只读当前四稿及必要Eq2/Eq4/§6/A9原段。fresh完整读取当前三稿、两TeX、两原图、全部12最新PNG、实际PDF解析记录及全部script/Q&A；primary只指定短段与有具体疑点的相邻短段，无全文科研重审。

源skills/fixtures/sources/talk-input、旧talk-fixed/micro全只读。无PPTX或presenter-notes PDF生成；notes保存在TeX note参数，audience PDF隐藏，不称PDF内嵌notes图层。英文基础统计reading group、非作者报告、非匿名、无指定venue；不造会议/匿名规则。

## 2. 沿用paper-talk逐字步骤清单

1. 读 `skills/writing-cycle/paper-talk/SKILL.md` 全文。源论文与既有材料只读。停在 talk-authorization：输出目录和本轮允许写入的文件未确认时，只展示计划。
   - **completed，沿用此前实读**。本次prompt明确恢复、新域及三处范围，不重读全部叶。
2. 读 `skills/writing-cycle/paper-talk/references/story-and-delivery.md`，按 `skills/writing-cycle/paper-talk/templates/talk-materials.md` 提取证据并形成逐页大纲。停在 outline-confirm：大纲未确认时不生成三份正文。
   - **completed，沿用已读资源与九页大纲**。只修三个明确批准位置，页序/逻辑数/图布局不变。
3. 在授权目录生成 `slides.md`、`speaker_notes.md`、`TALK_SCRIPT.md`。三份使用同一逻辑页编号。请求的 Beamer 或 PPTX 再读 `skills/writing-cycle/paper-talk/references/slide-templates.md`；工具缺失时保留 Markdown，并写明未生成的格式。
   - **completed**。复制当前micro后exact edit；三稿/TeX/原图全部实际write→read，已有模板读取沿用。
4. 按 `skills/writing-cycle/paper-talk/references/talk-audit.md` 只读审查这三份实际产物。审查不改演讲，也不改论文。
   - **本批限定核查completed**。当前全部产物/12物理页直接读，必要source比对；不等同新一轮全科研审查。父完整反馈与产物核实。
5. 内容修订、视觉精修和导出只在本次授权包含对应动作时进行。视觉步骤读 `skills/writing-cycle/paper-talk/references/visual-polish.md`。报告用 `skills/writing-cycle/paper-talk/templates/talk-report.md`。
   - **执行结束**。沿用已读方法，唯一build/fresh；未改布局，三处限定核查未见硬错误；投影/实际演讲等完成条件仍未验证，不标整体就绪。
6. 交付 slides、notes、script 与报告。不上传、不发布、不投稿。
   - **completed**。交付上表路径；本批停止，无workflow切换或外发。

## 3. 三处原话差异与实际结果

| 批准项 | 原micro原话 | 当前定点修补 | fresh＋父核结果 |
|---|---|---|---|
| 1 err异常glyph | TeX/slide公式 `\mathbb 1`，实际p5/p6异常字形 | `err_t := cases{1, Y_t not in C_t(alpha_t); 0, otherwise}`，普通数学0/1；原 `alpha_{t+1}:=alpha_t+gamma(alpha-err_t)` 原样 | p5/p6实际cases清楚、定义忠实source§2/Eq2、括号及方向正确；无溢出/碰撞。该项所核范围通过。 |
| 2 假设完整承诺 | “full assumptions in Q&A7” | “assumption overview in Q&A7; complete conditions in source”；Q&A7显式only overview/not complete list，完整条件留§4.2/A9；notes同步 | p8及三稿/notes/Q&A均有界；没有伪补证明、未给Prop加HMM条件。该项所核范围通过。 |
| 3 centered300 | S7/notes/script/Q&A曾直接称centered300 | 短caption“300-county retrospective summary”；script/notes implementation centering not independently checked；备注记录source most recent300与centered Eq4交叉引用差异 | p10caption与原图完整；不冒称已核中心/在线尾窗。差异作为缺口保留，不硬选源文实现事实。该项诚实限定核查通过。 |

S6的Eq4中心500保持；原两图完整副本字节相同。整个TeX preamble/图页宏、宽390pt/坐标/字号布局等与micro逐字相同；原Prop公式未改。cases高度是批准公式表达自身变化，没有额外布局修复。只有三项及其notes/计时同步，无新科研主张。

四稿完整原文diff保留 `evidence/talk-final-diff.md`；本报告表已给全部实质处理，不以链接代替判断。S5口述仅作语法/概述同步。含转场UV实算469词；每页36/46/31/63/70/70/66/50/37词。pause4/6/4/8/8/10/8/6/4，共58秒；140wpm加停顿向上取整slots20/26/18/35/38/40/37/28/20，共262秒；独立30buffer，总292秒。主讲≤270、词数≤600；不声称真人准时。

## 4. 唯一build与最新全页导出

实际命令：

```bash
cd /tmp/ros-v2-remediation/project/talk-final/build
/Library/TeX/texbin/pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -recorder talk.tex
```

新空build副本、闭合本地源已全文read，UV subprocess前台≤120s。**exit0，wall0.765s，编译1/1**，无第二次。实际PDF12页、383697bytes、453.543×255.118pt（16:9）。180dpi全页PNG真实来自本PDF；PDF全文/metadata/fonts实际解析，全部20项字体嵌入。无overflow/overfull；保留Fira不可用、13pt→12pt、rerunfilecheck.out等警告，未为警告安装或追加编译。

逻辑/物理：S1p1；S2p2–3；S3p4；S4p5–6；S5p7–8；S6p9；S7p10；S8p11；S9p12。9逻辑帧、3额外overlay、0backup、0notes物理页。父及fresh全部12PNG逐一直接read；无意外空白、裁切、碰撞。九notes Markdown fenced原句与九TeX note参数直接相等；当前/compiled TeX字节相同。Audience文本未见notes泄漏，仅所读可观察范围，不全面hidden-object取证认证。

## 5. 唯一fresh执行与读取覆盖

中性prompt亲自write→read→真实新session CLI；只传当前材料与必要primary，不传旧review/diff/父评价/修复叙述。实际命令：

```bash
pi --no-extensions --no-context-files --no-skills --model cliproxy/gpt-6.1-sol --thinking high --append-system-prompt /tmp/ros-v2-remediation/reviewer-system-round2.md --session /tmp/ros-v2-remediation/evidence/talk-final-review-1.session.jsonl --mode json -p @/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md > /tmp/ros-v2-remediation/evidence/talk-final-review-1.trace.jsonl 2> /tmp/ros-v2-remediation/evidence/talk-final-review-1.stderr
```

**exit0，wall404.257s（限900s），stderr空，无error事件**；未换模型、无重试。新session id01a10175-588a-77e3-9698-0b62a9b6338d，model/thinking记录cliproxy/gpt-6.1-sol/high，非fork/continue/resume。raw trace/session权威保留；仅message_end assistant文本提取9条（8账本＋最终回复），不重复start/update。下文全部请求/回复逐字内联。

父核raw工具记录12/12最新PNG全部read，当前三稿/两TeX/图/PDF记录完整读；reviewer离线解析实际PDF/字体/文本并解压比较嵌入RGB与原PNG直接相等。reviewer同时在该像素探针输出了SHA256字符串：这是沿用visual-polish“不要生成SHA”合同的过程偏差，未用该digest作保全/验收依据；本报告依赖逐字、字节、RGB直接比较及实际图像读取。权威raw trace原样保留，不删改此偏差。reviewer第一次定位把分页符计为行导致个别短段错位，随后按真实换行纠正并read正确短段；原反馈/工具证据完整保留。

父完整read原始反馈，再read当前p6/p8/p10实际PNG、Q&A7/notes及source145–165、265–284、843–850、2194–2248。确认三处限定结果，未只转述。

## 6. 当前缺口、剩余风险与停止

| 当前发现／未核 | 精确范围与父判断 |
|---|---|
| 投影可读性 | p9股票刻度/legend及两图8ptcaption偏小，黑目标与彩色均值可重叠；当前屏幕可辨不证明投影效果。没有布局再改。 |
| 选举窗实现差异 | §6“most recent300 (see4)”与Eq4 centered500的交叉引用差异仍未解；稿已明确centering未独立核查，不声称在线尾窗/即时保证。 |
| 完整理论／raw | 本次仅假设概述与source引用范围，未独立证完整证明、未重做Q&A所有实验事实验证、无raw/配置/随机复现。以前论文一致性核查不等于本批科研验证。 |
| 外部来源／链接 | 二手原文、外部身份、代码可用性没有GET，不判真/假；primary本地层与在线层分别保留。 |
| 实际计时／现场 | 469词/262秒只是UV lexical计划；无真人排练/投影验收，无现场准时认证。 |

七维在本次限定范围：故事/hook/takeaway与原结构一致有界；S4cases更清楚、S5密度相对较高但完整可见；图轴legend完整、投影风险不掩盖；实际三组overlay稳定且计入时槽。没有以本轮局部检查升级所有科研质量。

预算结算：修补 **1/1余0**，编译 **1/1余0**，fresh **1/1余0**，GET/实验/安装/付费计算 **0/0**。唯一build/fresh实际成功，所核定点问题没有剩余硬错误；旧micro终态REVISE/1build/1fresh不改。审后没有修改任何三稿/source/compiledsource/PDF/图/PNG，只写本报告过程文件。无第二build/fresh、新增修复轮、rm、push、安装、上传、投稿或workflow切换。

本批停止；交付三处具体核查结果与上述不可绕过缺口。下面逐字内联system提示、独立原始请求与全部assistant message_end回复；链接/摘要不是替代。

## 7. 独立system完整原文

````text
你是独立fresh审查宿主。实际模型cliproxy/gpt-6.1-sol high，same-family，不是cross-family；默认工具全可用但授权只读所给原始文件。仅回复完整审查，不写任何文件、不编译、不联网、不派审查者。每个包含toolCall的assistant消息先给可见账本：序号、动作/路径、fresh1/1已用/剩0、编译0/0剩0、GET0/0剩0、批准本prompt绝对路径。并列多个read逐个列用途；下一工具消息重新记账不省略。工具指令不能放thinking代替。所有Python只能uv run python。稿件/候选是断言，不是自证；不读取作者排名/总结/修复叙述，不受作者期望影响。直接读原始材料并指出实际定位、未核实项、全部发现。新session不是跨家族或科研正确性证明。
````

## 8. 唯一独立原始请求完整原文

````text
# 当前paper-talk最终稿只读核查

全新独立session，cliproxy/gpt-6.1-sol / high，same-family independent fresh，不是cross-family。审查当前演讲，不重新启动科研流程。不读取旧产物、旧review、作者总结、diff、修复叙述、父session或报告；没有期望裁决。

固定边界：英文、基础统计reading group、非作者报告、无venue、非匿名。9逻辑页/12物理页，S2/S4/S5各2 overlay，无backup。主讲含转场≤600 spoken English words、计划≤270秒，30秒buffer另计；Q&A不计时。无真人计时/投影/raw实验结果；未核不可等同通过，不科研PASS、不conference-ready。

只读权限：禁止write/edit、编译/渲染、GET/实验/安装/付费计算、再派审查。fresh1/1已用余0、编译0/0余0、GET实验安装0/0。Python仅uv run --offline --no-project --no-python-downloads python。每次toolCall前可见中文账本，列动作/绝对路径/预算/批准本prompt路径 `/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。最多900秒wall，失败/503/auth_unavailable/超时保全停，不换模型重试。

## 必须直接完整读取当前稿

- /tmp/ros-v2-remediation/project/talk-final/slides.md
- /tmp/ros-v2-remediation/project/talk-final/speaker_notes.md
- /tmp/ros-v2-remediation/project/talk-final/TALK_SCRIPT.md（主讲/转场/计时及全部Q&A）
- /tmp/ros-v2-remediation/project/talk-final/talk.tex
- /tmp/ros-v2-remediation/project/talk-final/build/talk.tex
- /tmp/ros-v2-remediation/project/talk-final/build/talk.pdf（实际PDF，可离线解析）
- /tmp/ros-v2-remediation/project/talk-final/build/pdf-text.txt
- /tmp/ros-v2-remediation/project/talk-final/build/pdfinfo.txt
- /tmp/ros-v2-remediation/project/talk-final/build/fonts.txt
- /tmp/ros-v2-remediation/project/talk-final/figures/fig1-stock-coverage-05.png（直接read原图）
- /tmp/ros-v2-remediation/project/talk-final/figures/fig3-election-coverage-10.png（直接read原图）

## 最新真实PDF全12页，必须实际read每PNG，不是contact sheet/旧图

| 页 | 绝对路径 |
|---|---|
| S1 p1 | /tmp/ros-v2-remediation/project/talk-final/render/page-01.png |
| S2 p2 overlay1 | /tmp/ros-v2-remediation/project/talk-final/render/page-02.png |
| S2 p3 overlay2 | /tmp/ros-v2-remediation/project/talk-final/render/page-03.png |
| S3 p4 | /tmp/ros-v2-remediation/project/talk-final/render/page-04.png |
| S4 p5 overlay1 | /tmp/ros-v2-remediation/project/talk-final/render/page-05.png |
| S4 p6 overlay2 | /tmp/ros-v2-remediation/project/talk-final/render/page-06.png |
| S5 p7 overlay1 | /tmp/ros-v2-remediation/project/talk-final/render/page-07.png |
| S5 p8 overlay2 | /tmp/ros-v2-remediation/project/talk-final/render/page-08.png |
| S6 p9 | /tmp/ros-v2-remediation/project/talk-final/render/page-09.png |
| S7 p10 | /tmp/ros-v2-remediation/project/talk-final/render/page-10.png |
| S8 p11 | /tmp/ros-v2-remediation/project/talk-final/render/page-11.png |
| S9 p12 | /tmp/ros-v2-remediation/project/talk-final/render/page-12.png |

## 必要primary原段，只限本次内容核查，不读全部论文/叶/旧测试

/tmp/ros-v2-remediation/project/sources/aci.txt：read 145–165（err0/1及Eq2）、265–284（Eq4 centered500）、843–850（§6 most recent300及Eq4交叉引用）、1994–1998（A9 LemmaA3条件）、2194–2248（A9 LemmaA4条件）。其余来源保持未知，不要求本次重新全科研审查；有具体疑点只读直接对应短段，注明未核。source PDF /tmp/ros-v2-remediation/project/sources/aci.pdf 可按必要页离线解析，不全文/不渲染。

## 核查项目与紧凑输出

看实际全12页glyph、公式括号/方向、cases0/1定义、裁切/碰撞/轴legend/三行caption；比较当前三稿/notes/source范围，S5及Q&A假设概述与source完整条件的区分，S6/S7窗口描述的已核与未核。原Eq2含义不可改，不自行替论文生成新假设/证明/下界。

直接核两TeX与九notes逐字一致、9帧/12页/overlay、PDF实际内容/隐藏notes边界、原图完整；独算spoken含转场词数、每页pause/slot/累计及buffer。不能把屏幕图像等同投影测试，不能把计划等同现场准时。

最终回复≤1000中文字符（工具账本不计）：9行逐页表明确覆盖全部物理页，再用紧凑发现/未核表，给原话定位与primary依据；没有问题写所核范围未发现，不认证科研PASS。保留所有实质问题和缺口，不展开教材。不修改输入，回复完整原文即可。审后不另开修复/审查。

````

## 9. 唯一独立全部assistant message_end回复完整原文

````text
账本01：只读当前稿；①`/tmp/ros-v2-remediation/project/talk-final/slides.md`核九页文字；②`/tmp/ros-v2-remediation/project/talk-final/speaker_notes.md`核九页notes；③`/tmp/ros-v2-remediation/project/talk-final/TALK_SCRIPT.md`核主讲、转场、计时及全部Q&A；④`/tmp/ros-v2-remediation/project/talk-final/talk.tex`核源TeX；⑤`/tmp/ros-v2-remediation/project/talk-final/build/talk.tex`核构建TeX；⑥`/tmp/ros-v2-remediation/project/talk-final/build/pdf-text.txt`核提取文本；⑦`/tmp/ros-v2-remediation/project/talk-final/build/pdfinfo.txt`核PDF记录；⑧`/tmp/ros-v2-remediation/project/talk-final/build/fonts.txt`核字体记录。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本02：只读原图与实际页图；①`/tmp/ros-v2-remediation/project/talk-final/figures/fig1-stock-coverage-05.png`核完整股票图；②`/tmp/ros-v2-remediation/project/talk-final/figures/fig3-election-coverage-10.png`核完整选举图；③`/tmp/ros-v2-remediation/project/talk-final/render/page-01.png`核S1；④`/tmp/ros-v2-remediation/project/talk-final/render/page-02.png`核S2初层；⑤`/tmp/ros-v2-remediation/project/talk-final/render/page-03.png`核S2公式层；⑥`/tmp/ros-v2-remediation/project/talk-final/render/page-04.png`核S3；⑦`/tmp/ros-v2-remediation/project/talk-final/render/page-05.png`核S4初层。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本03：逐页只读；①`/tmp/ros-v2-remediation/project/talk-final/render/page-06.png`核S4方向；②`/tmp/ros-v2-remediation/project/talk-final/render/page-07.png`核S5初层；③`/tmp/ros-v2-remediation/project/talk-final/render/page-08.png`核S5条件层；④`/tmp/ros-v2-remediation/project/talk-final/render/page-09.png`核S6轴、legend、三行caption；⑤`/tmp/ros-v2-remediation/project/talk-final/render/page-10.png`核S7同项；⑥`/tmp/ros-v2-remediation/project/talk-final/render/page-11.png`核S8；⑦`/tmp/ros-v2-remediation/project/talk-final/render/page-12.png`核S9。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本04：只读primary `/tmp/ros-v2-remediation/project/sources/aci.txt`；①145–165核err的0/1与Eq2；②265–284核Eq4中心500窗；③843–850核§6最近300与交叉引用；④1994–1998核Lemma A3；⑤2194–2248核Lemma A4完整指定条件。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本05：离线只读核验，执行`uv run --offline --no-project --no-python-downloads python`；读取①`/tmp/ros-v2-remediation/project/talk-final/talk.tex`及②`/tmp/ros-v2-remediation/project/talk-final/build/talk.tex`比较字节、帧与notes；③`/tmp/ros-v2-remediation/project/talk-final/speaker_notes.md`比较九卡；④`/tmp/ros-v2-remediation/project/talk-final/TALK_SCRIPT.md`独算词数、pause、slot、累计；⑤`/tmp/ros-v2-remediation/project/talk-final/build/talk.pdf`实际离线解析全部页、字体及隐藏notes；⑥`/tmp/ros-v2-remediation/project/talk-final/build/pdf-text.txt`核实际提取一致性；⑦`/tmp/ros-v2-remediation/project/sources/aci.txt`仅定位S2有限样本式、S5命题及Q&A7假设对应短段。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本06：只读具体疑点对应primary短段 `/tmp/ros-v2-remediation/project/sources/aci.txt`；①78–114核S2秩公式与约定；②390–430核S5算法条件、Prop4.1完整界；③490–515核Q&A7联合平稳与HMM；④638–666核Thm4.2 Lipschitz及内部最优点；⑤1846–1889核偏差解释的条件；⑥2249–2260补核A4条件式跨行结尾。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本07：离线只读定位及原图边界核验；①`/tmp/ros-v2-remediation/project/sources/aci.txt`按换行重新定位算法条件、Thm4.1/4.2与A9（此前解析器将分页符计作行，短段位置有偏差）；②`/tmp/ros-v2-remediation/project/talk-final/build/talk.pdf`核嵌入图像尺寸与完整PDF结构；③`/tmp/ros-v2-remediation/project/talk-final/figures/fig1-stock-coverage-05.png`、④`/tmp/ros-v2-remediation/project/talk-final/figures/fig3-election-coverage-10.png`核PNG原尺寸。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


账本08：只读补核与像素比较；①`/tmp/ros-v2-remediation/project/sources/aci.txt`387–390核S5量化条件；②同文件535–546核Thm4.1谱隙；③同文件631–638核Thm4.2完整前提；④同文件1809–1832核A9偏差条件定位；⑤离线Python读取`/tmp/ros-v2-remediation/project/talk-final/build/talk.pdf`及`/tmp/ros-v2-remediation/project/talk-final/figures/fig1-stock-coverage-05.png`、`/tmp/ros-v2-remediation/project/talk-final/figures/fig3-election-coverage-10.png`，仅解压比较嵌入图像RGB，不渲染不写文件。fresh1/1已用/剩0；编译0/0剩0；GET/实验/安装0/0剩0。批准：`/tmp/ros-v2-remediation/evidence/talk-final-review-1.prompt.md`。


**只读核查完成：所核范围未发现公式或版面硬错误；不是科研PASS或conference-ready认证。**

下表覆盖全部12物理页。词数含转场；停顿、时槽、累计均为秒。
|逻辑页／物理页|实际画面核查|词／停顿／时槽／累计|
|---|---|---|
|S1／p1|标题、Candès字形、非作者身份完整|36／4／20／20|
|S2／p2–3|两层正确；上取整、分母、集合括号完整|46／6／26／46|
|S3／p4|概率括号、严格大于号及“can”完整|31／4／18／64|
|S4／p5–6|γ乘整个括号；miss=1、otherwise=0；方向正确|63／8／35／99|
|S5／p7–8|绝对值、前缀和、界及条件层完整|70／8／38／137|
|S6／p9|完整四面板、轴、legend、三行caption；无碰撞|70／10／40／177|
|S7／p10|完整曲线、轴、legend、三行caption；无裁切|66／8／37／214|
|S8／p11|≠及限制陈述完整|50／6／28／242|
|S9／p12|结论、代码地址及未核声明完整|37／4／20／262|

两TeX逐字节一致；九notes与九卡逐字一致。实际PDF为12页、9帧，S2/S4/S5各两层，无backup或观众页notes泄漏；全部字体嵌入，提取文本与记录一致。两嵌入图RGB与原PNG完全一致。独算469词≤600；计划262秒≤270，另加30秒buffer共292秒；overlay已计入逻辑页时槽。

|发现／缺口|定位与primary依据|
|---|---|
|投影可读性风险|p9股票刻度、legend及两图8pt caption偏小；屏幕能辨认不等于投影验证。|
|窗口差异仍未解决|S7“implementation centering…not…checked”；`sources/aci.txt:843–850`说“most recent 300”却引Eq4；265–284明确中心500窗。稿件未把选举窗冒称已核中心／在线尾窗。|
|理论只作概述|S5与脚本Q&A7明确“not a complete list”。A3（1994–1998）另有定量下斜率；A4（2194–2248及跨行结尾）另有Taylor系数界、A3及条件漂移矩约束；不能仅凭“小shift”套用。|
|本次未核|其余Q&A实验细节、其他来源、完整证明、raw结果、代码可用性、实际演讲计时及投影。|

S4忠实保留Eq2含义（145–165）；弱扩大／缩小是同一时点输入下的参数比较，不是相邻预测集保证。本次为same-family独立fresh审查，不构成跨家族或科研正确性证明。

````
