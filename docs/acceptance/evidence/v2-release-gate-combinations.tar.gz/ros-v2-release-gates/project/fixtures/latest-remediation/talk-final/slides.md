# Slides: Adaptive Conformal Inference Under Distribution Shift

Source: `/tmp/ros-v2-remediation/project/sources/aci.pdf`, arXiv:2106.00170v3 [stat.ME], 28 October 2021; local full-text companion `aci.txt`. English, basic-statistics reading group; short oral practice, no specified venue; non-anonymous. Not the authors' talk. Nine logical slides, no backups; S2/S4/S5 each have two overlays. Main plan 262 seconds + 30-second buffer = 292 seconds; Q&A outside. Original paper/results are not modified; raw result files were not supplied. Primary source locations below are support for talk-to-paper consistency, not independent validation of the research.

## Slide 1: Adaptive Conformal Inference Under Distribution Shift

**Adaptive Conformal Inference Under Distribution Shift**

Paper by Isaac Gibbs & Emmanuel J. Candès — Stanford University.

arXiv:2106.00170v3 [stat.ME] · 28 October 2021 · Source labels itself “Preprint. Under review.”

*Reading-group presentation, not authors' talk.*

**What happens to prediction intervals when the data drift?**

Source: title page; §1. 20 seconds; cumulative 0:20. No overlay.

## Slide 2: Exchangeability supports finite-sample marginal coverage

Overlay 1:
- Score $S(X,y)$: e.g. absolute residual $|\hat\mu(X)-y|$.
- Calibrate $\hat Q(p)$ on held-out scores; $m=|\mathcal D_{\mathrm{cal}}|$.
- Predict $\hat C_t=\{y:S(X_t,y)\le\hat Q(1-\alpha)\}$.

Overlay 2 adds:
- **Exchangeable calibration + test data; ties broken uniformly at random.**

$$P(Y_t\in\hat C_t)=\frac{\lceil m(1-\alpha)\rceil}{m+1}.$$

Source's finite-sample convention: approximately $1-\alpha$, not a universal “at least 90%” bound at $\alpha=0.1$.

Source: ACI §1.1, Eq. (1) and following rank argument, p.2. Marginal, not conditional coverage. 26 seconds total; cumulative 0:46.

## Slide 3: Drift can leave fixed-alpha coverage off target

$$M_t(\alpha):=P\big(S_t(X_t,Y_t)>\hat Q_t(1-\alpha)\big).$$

- Under drift, $M_t(\alpha)$ **can** differ from $\alpha$; not necessarily.
- Gaps can persist in examples, rather than being inevitable.
- Financial and election illustrations follow in S6/S7.

Source: ACI §§1–2; examples §2.2 and §6. 18 seconds; cumulative 1:04. No overlay.

## Slide 4: Misses lower alpha-t; calibration sets need not grow strictly

Overlay 1: target $\alpha\in(0,1)$, step $\gamma>0$; after observing $Y_t$,

$$\alpha_{t+1}:=\alpha_t+\gamma(\alpha-\mathrm{err}_t),\qquad \mathrm{err}_t:=\begin{cases}1,&Y_t\notin\hat C_t(\alpha_t),\\0,&\text{otherwise}.\end{cases}$$

Hold the score and nondecreasing quantile functions fixed; these are not comparisons of consecutive refitted sets.

Overlay 2 adds:
- Miss ($\mathrm{err}_t=1$): $\Delta\alpha_t=-\gamma(1-\alpha)$ → **weak enlargement**.
- Covered label ($\mathrm{err}_t=0$): $\Delta\alpha_t=+\gamma\alpha$ → **weak shrinking**.
- Sets may remain unchanged; neither change is necessarily strict.

Always visible:
- $\gamma$ balances adaptation and stability.
- Experiments: $\gamma=0.005$, initialization $\alpha_1=\alpha$.

Source: ACI §2 Eq. (2), §2.1. General initialization/quantile conditions appear in S5. 35 seconds total; cumulative 1:39.

## Slide 5: Proposition 4.1 controls prefix-average miscoverage

Overlay 1: **Proposition 4.1 — for every prefix $1,\ldots,T$, almost surely**

$$\left|\frac1T\sum_{t=1}^{T}\mathrm{err}_t-\alpha\right|\le\frac{\max\{\alpha_1,1-\alpha_1\}+\gamma}{T\gamma}.$$

- Target $\alpha\in(0,1)$; $\alpha_1\in[0,1]$; $\gamma>0$.
- Nondecreasing $\hat Q_t$: $\hat Q_t(p)=-\infty$ for $p<0$; $+\infty$ for $p>1$.
- No distributional assumptions; **not** arbitrary short/sliding-window, per-time or conditional coverage.

Overlay 2 adds:
- For §4.2 only: joint stationary initialization, fixed $S,\hat Q$ and theorem-specific conditions. Small shift alone is insufficient; assumption overview in Q&A 7; complete conditions in source.

Source: ACI §4.1, Prop. 4.1, Eq. (5). **For §4.2 only:** HMM assumptions and theorem-specific conditions (Q&A 7). The unique joint stationary law, nonzero absolute spectral gap for Thm 4.1, bias Taylor/regularity conditions, and Thm 4.2 Lipschitz/interior-optimum conditions are only summarized in the script Q&A; complete hypotheses remain in source §4.2 and A.9, not conditions of Proposition 4.1. 38 seconds total; cumulative 2:17.

## Slide 6: Selected-stock coverage

![Original Figure 1 asset, unchanged](figures/fig1-stock-coverage-05.png)

Caption visible beneath enlarged figure:

Centered retrospective 500-day coverage; selected 4 of 12 stocks/indices.  
Black: target 0.9; colored dashes: all-time means; grey: Bernoulli reference (not uncertainty).  
Source: ACI Fig. 1, Sec. 2.2; Eq. (4). Raw results not supplied.

No extra bullets. Reuse the complete original cropped asset; no further crop, redraw, axis removal or data change. Local curves fluctuate, including ACI; no claim of constant 90% coverage. The plot axes retain coverage fractions and calendar time. Overlapping windows are not trailing online diagnostics or instantaneous guarantees. GARCH, 1250-day calibration and the Fig. 2 score caveat remain in notes/Q&A. Blue ACI/red fixed alpha remain in the original legend and script. 40 seconds; cumulative 2:57.

## Slide 7: Time-zone election replication

![Original Figure 3 asset, unchanged](figures/fig3-election-coverage-10.png)

Caption visible beneath enlarged figure:

300-county retrospective summary; time-zone replication, not live.  
Black: target 0.9; colored dashes: all-time means; grey: Bernoulli reference (not uncertainty).  
Source: ACI Fig. 3, Sec. 6; Eq. (4). Raw results not supplied.

No extra bullets. Reuse complete original asset, no further crop or data changes. Local ACI dips remain visible; not guaranteed 90% at every point. The Washington Post attribution is via ACI §6/reference [13]; secondary original was not directly checked. X-axis is sequence time, not clock time. Retrospective 300-county summary; implementation centering not independently checked. Primary §6 says most recent 300 counties but cross-refers to centered Eq. (4); the implementation difference remains unresolved here. Not an instantaneous guarantee. CQR, 3111 matched counties, 500-county burn-in and attribution details remain in notes/Q&A. 37 seconds; cumulative 3:34.

## Slide 8: Frequency control does not ensure prediction quality

- Prefix-average frequency control ≠ conditional coverage or useful widths.
- Small shift alone does not establish §4.2 guarantees.
- Open: delayed/batched labels; adaptive $\gamma$; online-refitted-quantile theory.
- Evidence: two real-world domains; broader protection remains unknown.

Source: ACI §§4.1–4.2, 5, 7. 28 seconds; cumulative 4:02. No overlay.

## Slide 9: Online recalibration controls long-run prefix frequency

**ACI updates one calibration parameter to control long-run prefix miscoverage under its algorithmic conditions — not every local window.**

- Paper: arXiv:2106.00170v3.
- Reported code: `github.com/isgibbs/AdaptiveConformal` (ACI A.6.2; availability unchecked).
- Questions welcome; Q&A outside the timed talk.

Source: ACI §4.1 Prop. 4.1; A.6.2. 20 seconds; cumulative 4:22. No overlay, QR code or backup frame. No external link was fetched.

## Mapping and delivery boundaries

Expected audience PDF: S1→p1; S2→p2–3; S3→p4; S4→p5–6; S5→p7–8; S6→p9; S7→p10; S8→p11; S9→p12. Confirm against the actual compiled PDF rather than assuming this mapping. Embedded notes use the same numbered cue cards as speaker_notes.md. Timing is lexical planning, not actual punctuality; projection readability and actual presentation behavior require human testing. No PPTX requested or generated.
