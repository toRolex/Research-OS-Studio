# Talk Script: Adaptive Conformal Inference Under Distribution Shift

English; basic-statistics reading group, short oral practice; no specified venue; non-anonymous, not the authors' talk. Source: local arXiv:2106.00170v3, 28 October 2021. Nine logical slides; Q&A outside the timed talk. Spoken text is only the paragraphs and the Transition sentences below; headings, directions and Q&A are not spoken.

Timing method: count spoken English words including transitions; allow 140 words/minute plus explicit pauses/page changes. Planned main talk must be at most 270 seconds, plus a separate 30-second buffer. No human rehearsal has been performed. The measured counts and final per-slide slots are in the table below.

## Slide 1: Adaptive Conformal Inference Under Distribution Shift

What happens to prediction intervals when the data drift? This reading-group talk examines Adaptive Conformal Inference Under Distribution Shift, by Isaac Gibbs and Emmanuel Candès. I am not presenting as an author.

*[Pause after the question.]*

Transition: First, the calibration idea.

## Slide 2: Exchangeability supports finite-sample marginal coverage

Calibrate a score quantile on held-out data; accept labels at or below it. Exchangeability and uniformly randomized ties support the displayed source formula. At alpha point one, coverage is approximately ninety percent, not a universal ninety-percent lower bound under this convention.

*[Point to the score and quantile, then reveal the formula. Pause at the assumptions.]*

Transition: Drift can undermine that calibration.

## Slide 3: Drift can leave fixed-alpha coverage off target

Nonstationarity can move fixed-alpha miscoverage away from its target, but does not necessarily do so. The paper illustrates persistent gaps in financial and election data.

*[Pause at “can”.]*

Transition: ACI responds by tracking one parameter.

## Slide 4: Misses lower alpha-t; calibration sets need not grow strictly

Record a miss as one. Add gamma multiplied by the entire quantity alpha minus error. A miss lowers alpha-t; a covered label raises it. Holding the score and quantile functions fixed, sets weakly enlarge or shrink: they can remain unchanged. This does not compare consecutive refitted sets. Gamma balances adaptation and stability; experiments use zero-point-zero-zero-five and target initialization.

*[Point to the error term; reveal both directions. Pause before the two cases.]*

Transition: What does this feedback guarantee?

## Slide 5: Proposition 4.1 controls prefix-average miscoverage

Proposition four point one controls prefix-average miscoverage under the displayed initialization, step-size and extended-quantile conditions, without distributional assumptions. It guarantees neither arbitrary local windows nor per-time or conditional coverage. Section four point two alone assumes a stationary joint hidden Markov model, fixed scores and quantiles, and theorem-specific conditions. Q and A is an assumption overview; complete conditions are in the source. Small shift alone is insufficient.

*[Point to the prefix sum, then the assumptions; reveal the HMM scope.]*

Transition: Now, two empirical illustrations.

## Slide 6: Selected-stock coverage

Four stocks were selected from twelve stocks and indices because fixed alpha visibly failed. These overlapping five-hundred-day windows are centered retrospective summaries, not trailing online diagnostics or instantaneous guarantees. Blue is ACI, red fixed alpha, grey a Bernoulli reference. Black marks the target; colored dashes mark all-time means, not uncertainty. Notice Fannie Mae around two thousand eight; blue also fluctuates. Unnormalized scores perform worse.

*[Point to legend, target, colored means, then the Fannie Mae panel. Leave time to inspect the axes.]*

Transition: The second illustration changes the ordering.

## Slide 7: Time-zone election replication

The election experiment uses conformalized quantile regression on time-zone-ordered counties. It replicates the Washington Post method's core elements, not a live deployment. These are retrospective three-hundred-county summaries, not instantaneous guarantees; implementation centering has not been independently checked. Fixed alpha shows troughs; ACI is closer overall but also dips. Colors, target and all-time means have the same meanings as before.

*[Point to the red troughs and a blue dip, then the axes.]*

Transition: Keep the guarantees separate from these plots.

## Slide 8: Frequency control does not ensure prediction quality

Long-run prefix frequency control is not conditional coverage or a promise of useful interval widths. The paper leaves delayed labels, adaptive gamma, and theory for online-refitted quantiles open. Its empirical evidence covers only two domains. Small shift alone is insufficient for the stronger theoretical guarantees.

*[Pause after the first sentence.]*

Transition: Here is the bounded takeaway.

## Slide 9: Online recalibration controls long-run prefix frequency

ACI updates one calibration parameter to control long-run prefix miscoverage under its algorithmic conditions. It does not guarantee every local window. The paper and its reported code link are shown. Questions?

*[Pause; remain on this slide for untimed Q&A.]*

Transition: We can discuss the assumptions next.

## Main-talk timing

Count rule: Unicode alphanumeric words, apostrophes and internal hyphens retained as one word; transitions included. This lexical count is not a syllable count. Slots allow 140 words/minute plus the listed pauses/page changes, rounded up; formula/number pronunciation and audience response may require more time in practice.

| Slide | Spoken words | Pause/change seconds | Slot seconds | Cumulative |
|---|---:|---:|---:|---|
| 1 | 36 | 4 | 20 | 0:20 |
| 2 | 46 | 6 | 26 | 0:46 |
| 3 | 31 | 4 | 18 | 1:04 |
| 4 | 63 | 8 | 35 | 1:39 |
| 5 | 70 | 8 | 38 | 2:17 |
| 6 | 70 | 10 | 40 | 2:57 |
| 7 | 66 | 8 | 37 | 3:34 |
| 8 | 50 | 6 | 28 | 4:02 |
| 9 | 37 | 4 | 20 | 4:22 |

Total: 469 spoken words; planned main talk 262 seconds, below the 270-second ceiling. Separate buffer 30 seconds; planned total 292 seconds within 300. Q&A is outside this allocation. These are preparation estimates; actual punctuality is unverified without a timed human rehearsal.

## Anticipated Q&A (outside the timed talk; no backup frames)

### 1. How much better is ACI than fixed alpha?
The paper presents local-coverage curves, not a single pooled improvement number. Figures 1 and 3 show prominent fixed-alpha excursions; ACI also varies locally. The 500-day stock summary is centered and retrospective by Eq. (4). The election figure reports a retrospective 300-county summary; implementation centering was not independently checked. Primary §6 says most recent 300 counties while cross-referring to centered Eq. (4); this difference remains unresolved, not evidence of a verified online trailing diagnostic or instantaneous guarantee. Colored horizontal lines represent each method's all-time average, not uncertainty intervals. Raw results were not supplied, so only consistency with the paper can be checked. Evidence: §2.2, Eq. (4), Fig. 1; §6, Fig. 3. Return to S6/S7.

### 2. What are the main limitations?
The method as studied observes each label at each step. Delayed or batched responses, adaptive step sizes, and stronger theory with online-refitted quantiles remain open. Empirical tests cover two domains. Evidence: §7; S8. These are research gaps, not a claim that every delayed-label adaptation is impossible.

### 3. What is the computation cost?
The calibration-level update is a scalar arithmetic operation. The underlying experiments refit their prediction models: GARCH with the latest 1250 trading days, and election quantile regression with a random roughly 75/25 training/calibration split after 500 observed counties. The paper does not report latency or memory measurements. Evidence: §2.2 and Appendix A.6.2, Algorithm 1. No cost experiment was run here.

### 4. Does this generalize to other domains?
Proposition 4.1 controls prefix miscoverage frequency for any generating process under its algorithmic conditions; it does not promise narrow or useful sets. The evidence is stock volatility and election prediction, with four selected stocks in Fig. 1 and eight additional stocks/indices in Fig. 9. Wider empirical protection is unknown. Evidence: §4.1, A.4, §7; S5/S8.

### 5. What is the score-design counterexample?
Figure 2 replaces the normalized stock-volatility score with an unnormalized score and shows much wider local coverage swings, even for ACI. This illustrates score sensitivity, not an extra stationarity assumption required by Proposition 4.1. Evidence: §5, Fig. 2; S6.

### 6. How is gamma selected?
The experiments choose 0.005 heuristically. Larger steps improve responsiveness but increase calibration-level volatility; too-small steps resemble fixed alpha. Theorem 4.2 discusses an optimizing step size in terms of unknown drift under its assumptions, not an implemented adaptive tuning rule. Evidence: §2.1, §4.2.3, §7; S4/S8.

### 7. What exactly are the theoretical conditions?
This is only an assumption overview, not a complete list of hypotheses. Complete conditions, including the quantitative regularity and conditional drift-moment requirements, remain in source §4.2 and A.9; no additional proof is supplied here. Proposition 4.1 uses target alpha in (0,1), alpha-one in [0,1], gamma > 0, and nondecreasing quantiles extended to minus infinity for arguments below zero and plus infinity for arguments above one. Its sum is over 1 through T, not an arbitrary sliding window. Section 4.2 assumes HMM emissions conditionally independent given the environment, fixed score and quantile functions, and a unique stationary law for the joint (alpha-t, environment) chain with initialization from that law. Theorem 4.1 additionally requires a nonzero absolute spectral gap for the environment; its useful bias interpretation invokes the Taylor/regularity conditions discussed in §4.2.2 and A.9. Theorem 4.2 instead requires Lipschitz miscoverage and an interior optimal calibration level in each state; its bound is a stationary expectation of squared miscoverage deviation, not a guarantee for every realized time point. Evidence: §4.1–4.2.3, A.7–A.9; S5.

### 8. What comes next, and what about other methods?
The paper proposes delayed/batched feedback, online-refitting theory, adaptive gamma and additional domains as future work. It describes reweighting and divergence-robust approaches in §3 but does not provide head-to-head experiments against them. Their original papers were not directly checked here, so any comparison is attributed only to ACI's discussion, not independently validated. Evidence: §3, §7. The reported GitHub URL is from A.6.2; link availability was not checked.
