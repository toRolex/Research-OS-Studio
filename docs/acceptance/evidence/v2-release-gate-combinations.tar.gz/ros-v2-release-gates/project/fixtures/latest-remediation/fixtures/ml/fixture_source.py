"""Explicit TOY research inputs; not paper/report generator. stdlib only."""
from pathlib import Path
import csv, random, statistics, time, platform
root=Path('/tmp/ros-v2-deliverables/project/fixtures');root.mkdir(exist_ok=True)
for v in ('general','ml','systems'):(root/v).mkdir(exist_ok=True)
# General: paired numerical rounding error of naive vs compensated sum.
rows=[]
for n in (10,100,1000):
 vals=[1e16]+[1.0]*n+[-1e16]
 import math
 rows.append((n,n,sum(vals),math.fsum(vals),abs(sum(vals)-n),abs(math.fsum(vals)-n)))
with (root/'general/results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['small_terms','exact','naive','fsum','naive_abs_error','fsum_abs_error']);w.writerows(rows)
# ML: fixed toy two-dimensional binary task, explicit training/test seeds.
rows=[]
for seed in range(5):
 r=random.Random(seed)
 train=[(r.uniform(-1,1),r.uniform(-1,1)) for _ in range(32)]
 test=[(r.uniform(-1,1),r.uniform(-1,1)) for _ in range(32)]
 def label(x):return int(x[0]+x[1]>0)
 majority=int(sum(map(label,train))>=len(train)/2)
 # actual 1NN nearest-neighbor fit (no tuned hyperparams)
 nn=[label(min(train,key=lambda q:(q[0]-x[0])**2+(q[1]-x[1])**2)) for x in test]
 rows.append((seed,32,32,sum(majority==label(x) for x in test)/32,sum(a==label(x) for a,x in zip(nn,test))/32))
with (root/'ml/results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['seed','train_n','test_n','majority_accuracy','one_nn_accuracy']);w.writerows(rows)
# Systems: small implemented membership system vs list baseline, correctness + measured microbench.
rows=[]
for trial in range(5):
 data=list(range(1000));idx=set(data); queries=[(i*37)%1200 for i in range(2000)]
 timings=[];counts=[]
 for obj in (data,idx):
  t=time.perf_counter_ns();count=sum(q in obj for q in queries);timings.append(time.perf_counter_ns()-t);counts.append(count)
 assert counts[0]==counts[1]
 rows.append((trial,1000,2000,counts[0],*timings))
with (root/'systems/results.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['trial','items','queries','matched','list_ns','set_ns']);w.writerows(rows)
for v in ('general','ml','systems'):
 (root/v/'ENVIRONMENT.txt').write_text(f'TOY fixture only\nPython {platform.python_version()}\n{platform.platform()}\nCPU only, no external data. No failed attempts.\n')
