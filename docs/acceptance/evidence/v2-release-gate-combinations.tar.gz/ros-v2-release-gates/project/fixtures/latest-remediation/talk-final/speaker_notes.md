# Speaker Notes: Adaptive Conformal Inference Under Distribution Shift

English cue cards, not a full script. Reading group, not the authors' talk; no specified venue, non-anonymous. Main plan 262 seconds plus 30 seconds buffer; Q&A outside. Notes below are embedded verbatim as plain text in the corresponding TeX frame's note argument; audience PDF hides notes. Times are estimates, not a rehearsal result.

## Slide 1: Adaptive Conformal Inference Under Distribution Shift
```text
Timing: 20s; 0:00-0:20.
Key point: Open with the drift question; identify the paper and reading-group role.
Action: Pause after the question; no figure.
Evidence/boundary: Source title page and Section 1; not the authors' talk.
Transition: First, the calibration idea.
```

## Slide 2: Exchangeability supports finite-sample marginal coverage
```text
Timing: 26s; 0:20-0:46.
Key point: Explain score, calibration quantile and accepted labels.
Action: Overlay 1 shows the mechanism; overlay 2 reveals assumptions and coverage. Pause at exchangeability and uniform random ties.
Evidence/boundary: Section 1.1, Eq. (1) and following rank argument; the displayed source convention is approximate at 90 percent, not a universal lower bound.
Transition: Drift can undermine that calibration.
```

## Slide 3: Drift can leave fixed-alpha coverage off target
```text
Timing: 18s; 0:46-1:04.
Key point: Drift can move miscoverage off target; it need not do so.
Action: Pause at can; reserve the data plots for Slides 6 and 7.
Evidence/boundary: Sections 1 and 2; illustrative examples, not inevitable failure.
Transition: ACI responds by tracking one parameter.
```

## Slide 4: Misses lower alpha-t; calibration sets need not grow strictly
```text
Timing: 35s; 1:04-1:39.
Key point: A miss lowers alpha-t; a covered label raises it. Multiply gamma by the entire quantity alpha minus error.
Action: Point to the parenthesized error term on overlay 1; reveal weak enlargement and weak shrinking on overlay 2.
Evidence/boundary: Section 2, Eq. (2), Section 2.1; hold score and quantile functions fixed. Sets can remain unchanged; this is not a comparison of consecutive refitted sets. 0.005 and target initialization are experimental choices.
Transition: What does this feedback guarantee?
```

## Slide 5: Proposition 4.1 controls prefix-average miscoverage
```text
Timing: 38s; 1:39-2:17.
Key point: Prefix-average frequency control is not local, per-time or conditional coverage.
Action: Overlay 1 shows the bound and algorithmic conditions; overlay 2 shows restricted HMM theory.
Evidence/boundary: Section 4.1, Proposition 4.1; initialization in [0,1], positive gamma and extended monotone quantiles. For Section 4.2 only: joint stationary initialization, fixed score/quantile functions and theorem-specific conditions; Q and A 7 gives only an assumption overview, not complete hypotheses; complete conditions remain in source Sections 4.2 and A.9.
Transition: Now, two empirical illustrations.
```

## Slide 6: Selected-stock coverage
```text
Timing: 40s; 2:17-2:57.
Key point: Disclose four selected stocks out of twelve stocks/indices; blue also fluctuates.
Action: Point to the legend, black target and colored all-time means, then Fannie Mae around 2008; leave time for the axes.
Evidence/boundary: Section 2.2, Eq. (4), Fig. 1; overlapping centered retrospective 500-day local summaries, not trailing online diagnostics or instantaneous guarantees; GARCH and 1250-day calibration. Section 5, Fig. 2 shows score sensitivity; A.4, Fig. 9 has eight additional stocks/indices. Grey is a reference sequence, not an uncertainty band; raw results not supplied.
Transition: The second illustration changes the ordering.
```

## Slide 7: Time-zone election replication
```text
Timing: 37s; 2:57-3:34.
Key point: Replication ordered by time zone, not a live deployment; local coverage can dip.
Action: Point to red troughs, a blue dip and the axes; distinguish target from all-time mean lines.
Evidence/boundary: Section 6, Fig. 3 and A.6; retrospective 300-county summary; implementation centering not independently checked. The primary text says most recent 300 counties but cross-refers to centered Eq. (4); this difference is unresolved here. Not an instantaneous guarantee; 3111 matched counties and 500-county burn-in. Washington Post attribution is via ACI, not a directly checked secondary source; raw results not supplied.
Transition: Keep the guarantees separate from these plots.
```

## Slide 8: Frequency control does not ensure prediction quality
```text
Timing: 28s; 3:34-4:02.
Key point: Frequency control does not guarantee conditional coverage or useful widths.
Action: Pause after the first sentence; distinguish algorithmic guarantees from open problems.
Evidence/boundary: Sections 4.1, 4.2, 5 and 7; delayed labels, adaptive gamma, online-refitting theory and wider empirical evidence remain open.
Transition: Here is the bounded takeaway.
```

## Slide 9: Online recalibration controls long-run prefix frequency
```text
Timing: 20s; 4:02-4:22.
Key point: One calibration update controls prefix frequency under its conditions, not every local window.
Action: Pause; stay on the slide for untimed Q and A; no QR code.
Evidence/boundary: Section 4.1, Proposition 4.1; reported code URL from A.6.2, availability unchecked.
Transition: We can discuss the assumptions next.
```

No backup frames. All three overlays are included in their logical slide's slot. The 30-second buffer is separate; no actual rehearsal or projector test has been performed.
