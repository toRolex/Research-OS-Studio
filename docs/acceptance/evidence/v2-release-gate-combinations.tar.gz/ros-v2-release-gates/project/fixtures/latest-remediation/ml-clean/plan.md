# Composed ML paper plan and acceptance contract

This is the plan contribution to canonical.md, not a parallel workflow. Status: provisional, not independently reviewed yet. Delivery: English venue-neutral article LaTeX, draft. No venue, style reference, default page limit, or submission authorization. Framing is supplied in fixtures/ml/BRIEF.md: a reproducible toy comparison under fixed synthetic conditions, without generalization to real datasets. The source is not runnable in this batch.

## Scope and resources
Read-only inputs (all read completely):
- /tmp/ros-v2-remediation/project/fixtures/ml/BRIEF.md: fixed task and scope.
- /tmp/ros-v2-remediation/project/fixtures/ml/ENVIRONMENT.txt: recorded execution environment; missing hardware/time fields remain unknown.
- /tmp/ros-v2-remediation/project/fixtures/ml/results.csv: header and all five seed rows, no exclusions.
- /tmp/ros-v2-remediation/project/fixtures/ml/fixture_source.py: only the ML block supports this article; the complete file has other fixture generators and a historical hard-coded output root. Do not execute it.
Writes only /tmp/ros-v2-remediation/project/ml-clean/ and process records /tmp/ros-v2-remediation/evidence/ml-clean-*.
Budgets: build <=3 cumulative, each <=120 s wall including child processes, new empty output and ordinary source snapshot; revision <=1 (all expression/error fixes share it); fresh <=6 (plan, combined claim/citation, attack, judge, final, optional rereview); GET0, experiments0, additional paid compute0. Existing tools only. Parent and reviewers cliproxy/gpt-6.1-sol high; same-family independent fresh, not cross-family. Project role table missing, explicit fallback. Cross-family requirements of audit leaves are not met and must remain reported, not silently waived.

## Claim—Evidence matrix
| ID | Candidate | Original evidence and locator | Read/existence | Support and restriction | Status | Allowed wording | Section |
|---|---|---|---|---|---|---|---|
| C1 | Fixed untuned paired protocol | fixture_source.py ML block, lines 15–30; results.csv all rows; BRIEF paragraph | read/existing | Same seed train/test used for both classifiers, two coordinates sampled uniformly, y=int(x0+x1>0), 32 train/32 test; training-majority ties choose class1; nearest ties use first minimum. No validation or search is coded. | supported | Five fixed seeds of a toy task; no tuning in supplied code | Methods |
| C2 | 1NN has higher recorded accuracy in every supplied seed | results.csv data rows 1–5, majority_accuracy and one_nn_accuracy | read/existing | Only these five finite test sets; paired accuracy is correct/32, larger is better; no significance test. | supported | Higher on each of the five recorded splits, not a population guarantee | Abstract/results/figure/conclusion |
| C3 | Descriptive mean and spread | results.csv all five rows | read/existing | Arithmetic mean over five equally weighted seeds; observed min–max only, not confidence intervals or standard errors. Compute transparently from raw values, do not run models. | supported pending arithmetic verification | State mean, min–max, and mean paired difference in percentage points | Results/table/abstract |
| C4 | Reproduction environment and bounded artifact status | ENVIRONMENT.txt lines 1–5; fixture_source.py historical root | read/existing | CPU-only, Python3.14.4 and OS recorded; hardware model/count, memory, wall time and total compute absent. Original command and revision hash absent; source points to an old root and writes other fixtures. | partial | Supplied code describes protocol; current batch did not rerun it and artifact is not a verified one-command reproduction package | Reproducibility/limitations |

Supported here means planning interpretation, not scientific validation. No failure/negative rows are dropped. ENVIRONMENT.txt states no failed attempts, but no separate run-attempt logs exist.

## Evidence/citation gaps
G1 hardware model/count, memory, wall time per run and total compute: visible COMPUTE NEEDED marker in Methods; no estimates.
G2 original execution command and immutable source revision not recorded; current source historical output root is unsafe to run: visible EVIDENCE NEEDED marker in reproducibility.
G3 closest prior work/novelty and external method attribution have no original sources within approved four inputs, GET0: visible CITATION NEEDED in related-work section; no fabricated cited key or BibTeX. No first/SOTA/novel-method claim.
G4 no modern stronger baseline, ablation, sensitivity, noise, other distributions, larger sizes or real datasets: named limitations; not required to establish the bounded observed five-row comparison, not evidence of research significance.
G5 asset publication license/author identities and applicable venue disclosure policy not supplied: explicitly unknown, no publication promise or compliance claim.
These are remaining risks, not user-accepted closed gaps. No additional experiments or retrieval are run.

## Narrative and section plan
One sentence: This diagnostic records the difference between a geometry-using one-nearest-neighbor rule and a training-majority rule on five fixed small synthetic train/test splits.
What: finite paired comparison. Why: all observed rows and full decision rules. So what: an inspectable reporting example, not a new learning method or a benchmark claim.

| Section | Purpose / paragraph order | Claims and original locators | Figures/citations | Discussed space | Gaps |
|---|---|---|---|---|---|
| Title/Abstract | Contribution, reporting challenge, approach, evidence, means and paired difference, scope | C1–C3; raw ML block/CSV | none | ~0.5 page | no significance/novelty claim |
| 1 Introduction | finite diagnostic question; what/why/so-what; observations and roadmap | C1–C3 | first figure referenced in results | ~0.5 page | bounded importance only |
| 2 Methods and recorded environment | samples/labels; precise decision rules; metric; seeds and no selection; compute facts/gap | C1,C4 | none | ~0.8 page | G1 |
| 3 Results | claim tested, matched conditions, all seed outcomes; mean/min–max and units; interpretation | C2,C3 | Figure1, Table1 | ~1 page | no inferential test |
| 4 Related work and positioning | geometry-using versus constant prediction; no literature review claimed; closest-work gap | C1 | citation gap, no invented references | ~0.3 page | G3 |
| 5 Limitations | finite toy scope, weak baseline, missing controls, no causal explanation, missing compute | C2,C4 | none | ~0.4 page | G1,G4 |
| 6 Reproducibility and availability | exact local evidence, source caveat, recorded environment vs writing host, original command gap, license/disclosure unknown | C4 | none | ~0.5 page | G2,G5 |
| 7 Conclusion | only bounded finite observations | C2,C3 | none | ~0.2 page | no deployment claim |

Seven main sections; diagnostic structure. No theorem/proof or supplementary appendix. Discussion budget ~4.2 pages including title/figure/table/declarations, not an official ceiling and not compiled yet. References have no populated entries; a related-work source gap remains visible. There is no rule-based exclusion of references/appendix from a page count.

## Figure / table plan
Figure1: quantitative TOY data, five seed categories x-axis, test accuracy percent y-axis spanning0–100. Majority open square and 1NN filled circle; grayscale plus shape encodings. No fitted line, error band, or causal interpretation. All ten points mapped directly to results.csv, 100*accuracy. Editable pure TeX picture source generated using stdlib CSV loader, rendered with the manuscript in the approved build (not a separate build). Caption: Test accuracy for fixed 1NN and training-majority prediction on five synthetic splits, each with32 train and32 test examples. Points are individual seed outcomes, not mean/error bars; no rows excluded. Source: results.csv. 1NN is higher on each displayed split only.
Table1: all seed accuracies, paired delta in percentage points; mean and observed range. Uniform five-decimal percent precision retains exact finite values; bold higher accuracy in comparable rows as reading aid only. Mean/min–max defined, not CI. Source-generated editable TeX.
Graph resources: existing Python stdlib through uv, existing trusted LaTeX picture commands, no package/library install or external renderer. One generation <=120s, at most one correction inside shared revision budget; visual inspection occurs on fresh built PDF pages before handoff.

## Citation plan
Related work: closest published treatment of nearest-neighbor and constant-baseline rules, to substantiate historical/novelty positioning if such positioning is desired. Source identity/metadata/context: missing. GET0; leave CITATION NEEDED, omit unsupported historical factual claims and do not synthesize fake bibliography. Current decision rules come from original source, not an external attribution.

## Acceptance contract (11 assertions; unresolved gaps are not waived)
A1 exact four-input boundary and source read-only.
A2 title/abstract/conclusion restricted to explicit TOY five-seed comparison.
A3 all five CSV rows retained, paired splits/configuration/metric stated.
A4 mean over five equally weighted seeds, min–max named, no statistical significance.
A5 no tuning/validation in supplied code, tie rules and generator order stated.
A6 CPU/environment facts only from ENVIRONMENT; missing compute visible in text.
A7 Figure1 editable/source-mapped, axes0–100, individual seed points, actual fresh render inspected.
A8 actual article prose in all seven sections, dedicated limitations.
A9 citations verified or exact visible source gap; zero invented bibliography keys.
A10 cumulative build/revision/fresh/GET bounds; successful current-source PDF parsed and visually checked; source snapshot equality.
A11 neutral actual independent fresh plan, numerical/citation, attack/judge and final records retained verbatim in canonical; cross-family capability gap honestly visible; no posting/upload/experiment.
Contract status: provisional pending independent plan feedback. No negotiated extra rounds or claim of scientific acceptance.

## Handoff
Plan reviewer directly reads this plan, user boundary and the four raw inputs, without author ranking, pre-review conclusions or prior material. Required checks: six paper-plan review questions and smallest expression-only adjustments. Preserve unresolved objections; no new study fact may be added. Plan review consumes1/6 fresh. Full workflow, not this local leaf, owns later drafting/build/audits and the stop after draft+canonical delivery.
