"""Render-ready pure TeX data figure/table; never executes the fixture or models.
Run: UV_CACHE_DIR=/tmp/ros-v2-remediation/evidence/ml-clean-uv-cache uv run
 --no-project --offline --no-python-downloads --python /opt/homebrew/bin/python3
 python /tmp/ros-v2-remediation/project/ml-clean/generate.py
Outputs are exclusively in the approved ml-clean directory.
"""
from pathlib import Path
import csv, json, sys
from decimal import Decimal as D
ROOT = Path('/tmp/ros-v2-remediation/project/ml-clean')
RAW = Path('/tmp/ros-v2-remediation/project/fixtures/ml/results.csv')
rows = list(csv.DictReader(RAW.open()))
assert len(rows) == 5 and [int(r['seed']) for r in rows] == list(range(5))
assert all(r['train_n'] == r['test_n'] == '32' for r in rows)
a = [D(r['majority_accuracy'])*100 for r in rows]
b = [D(r['one_nn_accuracy'])*100 for r in rows]
d = [v-u for u,v in zip(a,b)]
figure = [r'% Generated from all five CSV rows; no fitting, filtering or error bars.',
          r'\setlength{\unitlength}{1pt}', r'\begin{picture}(330,210)',
          r'\put(45,25){\line(1,0){260}}', r'\put(45,25){\line(0,1){150}}']
for value in (0,25,50,75,100):
 y = D(25)+D('1.5')*value
 figure += [rf'\put(42,{y}){{\line(1,0){{3}}}}',
            r'\put(15,%s){\makebox(24,8)[r]{\small %s}}' % (y-D(4), value)]
figure += [r'\put(0,38){\rotatebox{90}{\small Test accuracy (\%)}}',
           r'\put(94,0){\makebox(180,12){\small Seed (fixed synthetic split)}}',
           r'\put(65,195){\framebox(4,4){}}',
           r'\put(76,190){\makebox(130,14)[l]{\small Training-majority}}',
           r'\put(213,197){\circle*{4}}',
           r'\put(223,190){\makebox(90,14)[l]{\small 1NN}}']
for i,(u,v) in enumerate(zip(a,b)):
 x = 65+55*i
 yu = D(25)+D('1.5')*u
 yv = D(25)+D('1.5')*v
 figure += [rf'\put({x-2},{yu-D(2)}){{\framebox(4,4){{}}}}',
            rf'\put({x},{yv}){{\circle*{{4}}}}',
            r'\put(%s,12){\makebox(20,10){\small %s}}' % (x-10, i)]
figure += [r'\end{picture}', '']
table = [r'% Percent accuracy and percentage-point paired differences; all rows.',
         r'\begin{tabular}{rrrr}', r'\toprule',
         r'Seed & Majority (\%) $\uparrow$ & 1NN (\%) $\uparrow$ & $\Delta$ (pp) $\uparrow$ \\',
         r'\midrule']
for i,(u,v,delta) in enumerate(zip(a,b,d)):
 table.append(f'{i} & {u:.3f} & '+r'\textbf{'+f'{v:.3f}'+r'} & '+f'{delta:.3f} '+r'\\')
means = [sum(z)/D(len(z)) for z in (a,b,d)]
table += [r'\midrule', f'Mean & {means[0]:.3f} & '+r'\textbf{'+f'{means[1]:.3f}'+r'} & '+f'{means[2]:.3f} '+r'\\',r'\bottomrule',r'\end{tabular}', '']
paths = {ROOT/'paper/figures/points.tex':'\n'.join(figure),
         ROOT/'paper/tables/results.tex':'\n'.join(table)}
for path, text in paths.items():
 path.parent.mkdir(parents=True,exist_ok=True)
 assert not path.exists(), f'Refusing to overwrite {path}'
 path.write_text(text)
record = {'raw':str(RAW), 'python_for_transformation_only':sys.version,
          'rows_used':5,'excluded_rows':[], 'figure_transform':'x=65+55*seed, y=25+1.5*(100*accuracy); y-axis 0–100%; square=majority, filled circle=1NN',
          'statistics':'equal-weight mean and observed min/max, no inferential uncertainty',
          'majority_percent':[str(x) for x in a],'one_nn_percent':[str(x) for x in b],
          'paired_pp':[str(x) for x in d], 'means':[str(x) for x in means],
          'ranges':[[str(min(z)),str(max(z))] for z in (a,b,d)]}
p=ROOT/'data-map.json'
assert not p.exists()
p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print('Generated editable TeX; rendered output requires the approved manuscript build.')
