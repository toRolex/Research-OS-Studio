import csv,json,sys,resource,time,importlib.util
from pathlib import Path
mode,out=sys.argv[1:]
t0=time.monotonic(); r0=resource.getrusage(resource.RUSAGE_SELF)
rows=list(csv.DictReader(open("data.csv")))
if mode=="sanity": rows=rows[:1]
if mode=="baseline": predict=lambda x:x
else:
 spec=importlib.util.spec_from_file_location("candidate","candidate.py")
 m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); predict=m.predict
values=[{"x":int(r["x"]),"y":int(r["y"]),"prediction":predict(int(r["x"]))} for r in rows]
mae=sum(abs(v["prediction"]-v["y"]) for v in values)/len(values)
r1=resource.getrusage(resource.RUSAGE_SELF)
result={"toy":True,"mode":mode,"n":len(values),"mae":mae,"rows":values,"cpu_core_hour":(r1.ru_utime+r1.ru_stime)/3600,"wall_seconds":time.monotonic()-t0,"process_cpu_total_includes_startup":True}
p=Path(out); p.parent.mkdir(exist_ok=True)
with p.open("x") as f: json.dump(result,f,indent=2)
print(json.dumps(result))
