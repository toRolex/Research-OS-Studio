Default policy, NOT AUTHORIZATION. scope: unspecified
cost_limit: 0
currency: USD
compute_limit: 0
compute_unit: cpu-core-hour
run_limit: 0
run_count_basis: planned-run
per_attempt_cost_limit: 0
per_attempt_compute_limit: 0
concurrency_limit: 0
retry_limit: 0
valid_for_hours: 0
