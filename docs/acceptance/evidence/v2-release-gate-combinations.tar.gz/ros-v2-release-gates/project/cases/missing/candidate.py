def predict(x): return x*x
