# TOY matrix scenario
Fixed squaring fixture. One command: uv run python evaluator.py main results/new.json. Immutable candidate/evaluator/data. Estimated worst cost 0 USD, CPU 0.001 cpu-core-hour. Only fresh result, stdout and research-log are writable. No external effects.
