# Round-1 Task

## 固定命题（逐字冻结，来自 /tmp/ros-v2-validation/proof/source-proof.md）

> For every integer n >= 0, sum_{k=1}^n k = n(n+1)/2; empty sum is zero.

- 量词：全部整数 n >= 0。
- 域：整数 n >= 0；求和指标 k = 1..n。
- 空和定义：n = 0 时 sum_{k=1}^0 k = 0（命题内显式给出，不得更改）。
- 本命题是刻意错误的 toy 材料，不是外部论文。

## 续接状态（继承核对）

- 旧轮目录：/tmp/ros-v2-validation/proof/ 下未找到 task.md、local-proof.md、audit.md、next.md、handoff.md。缺口如实列出，不虚构继承内容。可用的继承材料仅 source-proof.md（固定命题 + 刻意错误的证明正文）。
- compute-policy.md：默认政策，非本批授权；本批授权以下文本为准。research-log.md：无实验作业。
- source-proof.md 本轮只读，不可修改。

## 本轮唯一 obligation

核实并修复 source-proof.md 证明正文中的归纳步。命题、量词、域、空和定义不得变化；不允许新增假设或弱化结论。

## 授权（本 prompt 即本轮明确授权，不继承旧轮次）

- 新输出目录：/tmp/ros-v2-validation/proof/round-1/（新建）。旧目录与 source-proof.md 只读。
- proof-repair 写入契约：只允许修改 round-1/local-proof.md 的 "Proof body" 段，及写 round-1/record.md。
- 允许新建：round-1/task.md, audit.md, final.md, next.md, handoff.md, independent-review.md, repair-record.md, source-manifest.md, browser-prompt.md，及 round-1/prompts/（含 reviews/sessions）内证据。
- 预算：最多一次本地尝试；一次 fresh proof-review 诊断；最多一次 proof-repair 修复批次；修复后一次 fresh proof-review 复审。wall 45 分钟，文本 150KB。
- 工具边界：普通数学；不使用、不安装 Lean/LaTeX；不运行数值程序。允许模型对话（子 CLI 独立审查会话），禁止额外付费计算、禁止远程材料上传。子代理禁止再派代理。
- 独立审查方式：宿主用 bash 调 `pi --no-extensions --no-context-files --no-skills --approve --model cliproxy/glm-5.3-flash --thinking high --session <唯一新文件> --mode json -p @<prompt>`；第一次只让 reviewer 读取 source-proof.md + proof-review 及共置资源，不传入宿主判断；第二次 fresh 上下文只读本轮当前完整证明与固定命题，不含"已修好"摘要，限定只读。审查者不写文件。
- 宿主职责：核实子会话结果后记录；不冒充自己为独立 fresh review。

## 停止条件

修复后复审完成并核实、或预算耗尽、或出现需要改变命题/假设的冲突（本命题已知不需要），即停止。下一 obligation 只写 next.md 一项。
