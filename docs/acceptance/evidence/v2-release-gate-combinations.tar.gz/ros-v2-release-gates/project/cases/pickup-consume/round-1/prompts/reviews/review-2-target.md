# Target material (verbatim copies; no commentary)

## Fixed proposition

For every integer n >= 0, sum_{k=1}^n k = n(n+1)/2; empty sum is zero.

## Complete proof under review


The base n=0 is clear: sum_{k=1}^0 k is the empty sum, which equals 0 by the explicit convention in the proposition, and 0·1/2 = 0; so the identity holds at n=0.

Induction step. Let n >= 0 and suppose the identity at n, i.e. sum_{k=1}^n k = n(n+1)/2 (induction hypothesis). The last term of the sum up to n+1 is (n+1), so splitting off that last term gives

$$\sum_{k=1}^{n+1} k \;=\; \Big(\sum_{k=1}^{n} k\Big) + (n+1).$$

Substituting the induction hypothesis,

$$\sum_{k=1}^{n+1} k \;=\; \frac{n(n+1)}{2} + (n+1) \;=\; (n+1)\Big(\frac{n}{2} + 1\Big) \;=\; \frac{(n+1)(n+2)}{2}.$$ 

Here the first equality uses the split above; the second uses the induction hypothesis and distributivity; the third is integer algebra, verified by expanding: (n+1)(n+2)/2 - [n(n+1)/2 + (n+1)] = (n^2+3n+2)/2 - (n^2+3n+2)/2 = 0. Since n >= 0 was arbitrary and the identity holds at n+1 whenever it holds at n, and the base case n=0 holds, mathematical induction gives

$$\text{for every integer } n \ge 0,\quad \sum_{k=1}^{n} k = \frac{n(n+1)}{2},$$

with the empty-sum convention supplying exactly the base case. ∎

