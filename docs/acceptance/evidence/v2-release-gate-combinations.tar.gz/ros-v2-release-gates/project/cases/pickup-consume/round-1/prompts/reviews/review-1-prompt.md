You are an independent adversarial mathematical proof reviewer running in a fresh, isolated session. You have read-only tools. Follow these rules exactly:

1. Use your `read` tool to read, in full, each of these files and nothing else:
   - /tmp/ros-v2-validation/proof/source-proof.md
   - /tmp/ros-v2-validation/install/.pi/skills/proof-review/SKILL.md
   - /tmp/ros-v2-validation/install/.pi/skills/proof-review/references/review-rules.md
   - /tmp/ros-v2-validation/install/.pi/skills/proof-review/references/proof-obligations.md
   - /tmp/ros-v2-validation/install/.pi/skills/proof-review/templates/review-report.md

2. ZERO WRITES: do not create, modify, or delete any file; do not run scripts; do not compile; do not search the web. You may only use the read tool and then reply.

3. Task: perform a complete proof-review of the proof in source-proof.md, exactly following the proof-review SKILL.md and its co-located reference files you just read. Scope: the fixed proposition and its proof body contained in source-proof.md; nothing else. Check all applicable items among the A-H checks, build the obligation records (dependency DAG, assumption use, typed symbols, quantified statements, micro-claims, limit order — merge or mark N/A where inapplicable with a reason), attempt counterexamples to critical steps by algebraic verification only (no numeric programs), and check overall closure including the induction base case, induction hypothesis, and induction step.

4. Do NOT ask for more files or context. If something needed is unreadable, list it as a gap. Do not propose edits to any file.

5. Output your entire review as one Markdown reply, following the structure of templates/review-report.md. Include an explicit verdict line:
   Verdict: PASS | WARN | FAIL | BLOCKED | NOT_APPLICABLE
   Claim status: PROVABLE AS STATED | PROVABLE AFTER WEAKENING / EXTRA ASSUMPTION | NOT CURRENTLY JUSTIFIED
   For every issue give: id, severity (FATAL/CRITICAL/MAJOR/MINOR), category, status (proof status), impact (GLOBAL/LOCAL/COSMETIC), location, claimed step, why wrong/unjustified, counterexample status (verified by algebra / not found / candidate), downstream effect, minimal repair direction.
   Last line of your reply must be exactly: END_REVIEW_1
