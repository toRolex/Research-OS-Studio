# Saved authorized continuation state
scope: fixed proposition from round-1; n=0 boundary only; /tmp/ros-v2-validation/pickup-expired/round-2 approved files; local CPU no experiments
cost_limit: 0
currency: USD
compute_limit: 0.001
compute_unit: cpu-core-hour
run_limit: 0
run_count_basis: planned-run
per_attempt_cost_limit: 0
per_attempt_compute_limit: 0.001
concurrency_limit: 1
retry_limit: 0
valid_for_hours: 1
valid_until: 2020-01-01T00:00:00Z
batch_id: pickup-expired
plan: round-1/next.md
mode: ordinary mathematical boundary-only continuation
user_confirmation: Current pickup user prompt approves a new round scope, not inherited authorization.
confirmed_at: 2026-10-03T07:11:48.638694+00:00
confirmation_basis: /tmp/ros-v2-validation/evidence/pickup-expired.prompt.md
authorization_status: confirmed
No experimental jobs, no ongoing reservations, no other writer. A single local CLI orchestrator will continue if still valid. Experimental run_limit=0, ordinary mathematical local writing is within the explicitly approved round scope.
