# Next — Round-1

## 下一 obligation（唯一）

核对继承后的 n=0 边界，不重复完整归纳尝试。

具体内容：下一轮在新授权下，仅核对 round-1/local-proof.md "Proof body" 中 n=0 边界的继承状态——空和约定（∑_{k=1}^0 k := 0）作为命题内显式定义在基例中的使用是否与原命题逐字一致、边界语义无漂移。这是边界核对义务，不是重做归纳证明；归纳主体已在本轮闭合（review #2 PASS / PROVABLE AS STATED），下一轮不得重复完整归纳尝试。

## 授权提示

- 下一轮需要新的用户授权；本轮授权不继承。旧目录（/tmp/ros-v2-validation/proof/ 下除新轮目录外的全部内容，含 round-1/）在新授权下达前保持只读。
- 从 handoff.md 恢复。
