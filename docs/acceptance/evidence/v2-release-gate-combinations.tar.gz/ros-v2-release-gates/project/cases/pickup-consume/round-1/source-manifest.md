# Source Manifest — Round-1

| 来源 | 位置 | 状态 | 本轮用途 | 修改 |
|---|---|---|---|---|
| 固定命题 + 错误 toy 正文 | /tmp/ros-v2-validation/proof/source-proof.md | 已全文读取（5 行） | 命题逐字冻结来源；修复前基线正文来源 | 只读，未修改 |
| 计算政策 | /tmp/ros-v2-validation/proof/compute-policy.md | 已读取 | 确认为默认政策、非本批授权 | 只读 |
| 研究日志 | /tmp/ros-v2-validation/proof/research-log.md | 已读取 | 确认无实验作业 | 只读 |
| research-os 安装 | /tmp/ros-v2-validation/install/.pi/skills/（SKILL.md、proof playbook、4 个叶 SKILL.md、references/templates） | 已按路径级联全文读取 | 流程合同与审查规则来源 | 只读 |
| 旧轮次材料（task/local-proof/audit/next/handoff） | /tmp/ros-v2-validation/proof/ | 不存在 | 缺口如实记录，无继承内容 | — |

外部来源：无。无远程检索、无上传、无付费计算。来源均未发生版本/内容变化；无快照复制需求。
