# Explicit toy elementary mathematics; no external paper
## Fixed proposition
For every integer n >= 0, sum_{k=1}^n k = n(n+1)/2; empty sum is zero.
## Proof body (intentionally erroneous TOY input)
The base n=0 is clear. Suppose the identity at n. Then sum to n+1 = n(n+1)/2 + n = (n+1)(n+2)/2. Therefore induction completes.
