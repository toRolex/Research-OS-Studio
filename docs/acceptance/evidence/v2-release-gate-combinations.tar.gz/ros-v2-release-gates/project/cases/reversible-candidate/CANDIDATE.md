# 未应用候选

原话（新提议，未采纳）：
> ACI guarantees at least 90% coverage for every sliding window and every subgroup under arbitrary distribution shift

证据：`sources/aci.txt` §4.1，p.6，Prop.4.1/Eq.(5)：前缀误覆盖偏差≤(max{α₁,1−α₁}+γ)/(Tγ)；§4.2，p.7–8须额外条件。

当前三稿S5/8/9均有界：slides S5“for every prefix”；S8“≠ conditional coverage”；S9“not every local window”。notes/script同页一致。

建议：满足初始化、步长及扩展单调分位数条件时，ACI前缀覆盖频率趋近1−α；α=.1时趋近90%，非有限窗90%下界。

待人逐项决定：
- [ ] 拒绝逐滑窗保证。
- [ ] 拒绝逐子组保证。
- [ ] 拒绝有限样本“至少90%”；接受上述有界措辞？

未经另批，不改`talk-final/{slides.md,speaker_notes.md,TALK_SCRIPT.md}`；不编译/外发。

全文只读；角色表缺失，cliproxy/gpt-6.1-sol high非独立自检。未核原始结果、联网身份、图/渲染；非PASS。
