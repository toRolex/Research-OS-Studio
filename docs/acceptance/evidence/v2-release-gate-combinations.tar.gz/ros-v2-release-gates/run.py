from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,concurrent.futures,signal
R=Path('/tmp/ros-v2-release-gates'); P=R/'project'; E=R/'evidence'
def hashes(root):return {str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in root.rglob('*') if x.is_file()}
def run(name):
 d=P/'cases'/name
 (E/f'{name}.before.json').write_text(json.dumps(hashes(P),indent=2))
 cmd=['pi','--no-extensions','--no-context-files','--no-skills','--skill',str(P/'.pi/skills/research-os/SKILL.md'),'--approve','--model','cliproxy/gpt-6.1-sol','--thinking','high','--session',str(E/f'{name}.session.jsonl'),'--mode','json','-p','@'+str(E/f'{name}.prompt.md')]
 (E/f'{name}.command.json').write_text(json.dumps({'argv':cmd,'cwd':str(d),'timeout_seconds':500,'default_tools':'read/bash/edit/write (no tools/exclude flags)'},indent=2))
 start=time.monotonic(); timed=False
 with (E/f'{name}.trace.jsonl').open('w') as out,(E/f'{name}.stderr').open('w') as err:
  proc=subprocess.Popen(cmd,cwd=d,stdout=out,stderr=err,start_new_session=True)
  try:rc=proc.wait(timeout=500)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(proc.pid,signal.SIGTERM);rc=proc.wait(timeout=10)
 result={'case':name,'exit':rc,'timeout':timed,'wall_seconds':time.monotonic()-start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (E/f'{name}.result.json').write_text(json.dumps(result,indent=2))
 (E/f'{name}.after.json').write_text(json.dumps(hashes(P),indent=2))
 # Case-specific changes prevent parallel candidate from contaminating other snapshot comparisons.
 (E/f'{name}.case-after.json').write_text(json.dumps(hashes(d),indent=2))
 print(json.dumps(result),flush=True)
 return result
names=['missing','spent','unknown','pickup-expired','pickup-consume','ml-fourth-external','talk-serious-external','reversible-candidate']
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,names))
(E/'results.json').write_text(json.dumps(results,indent=2))
(E/'fixtures-after.json').write_text(json.dumps(hashes(P/'fixtures'),indent=2))
G=Path.home()/'.agents/pstack-models.md';(E/'global-after.json').write_text(json.dumps({'sha256':hashlib.sha256(G.read_bytes()).hexdigest(),'mtime_ns':G.stat().st_mtime_ns}))
