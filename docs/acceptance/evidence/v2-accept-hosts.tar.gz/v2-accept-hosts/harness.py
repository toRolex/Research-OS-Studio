from pathlib import Path
import subprocess, json, hashlib, os, time, argparse
ROOT=Path('/tmp/research-os-v2-hosts'); PROJECT=ROOT/'project'
def snapshot(path):
    d={}
    for f in path.rglob('*'):
        if f.is_file() and '.git' not in f.parts:
            d[str(f.relative_to(path))]=hashlib.sha256(f.read_bytes()).hexdigest()
    return d
def run(host,case,prompt,resume=None,project=PROJECT):
    out=ROOT/case/host; out.mkdir(parents=True,exist_ok=True)
    (out/'prompt.txt').write_text(prompt)
    (out/'before.json').write_text(json.dumps(snapshot(project),indent=2))
    globalfile=Path.home()/'.agents/pstack-models.md'
    glob={'exists':globalfile.exists()}
    if globalfile.exists():glob.update(sha256=hashlib.sha256(globalfile.read_bytes()).hexdigest(),mtime_ns=globalfile.stat().st_mtime_ns)
    (out/'global-before.json').write_text(json.dumps(glob))
    if host=='pi':
        session=resume or str(out/'session.jsonl')
        cmd=['pi',* ([] if os.environ.get('ROS_FULL_DEFAULT') else ['--no-extensions']),'--approve','--model','cliproxy/glm-5.3-flash','--thinking','off','--mode','json','--print','--session',session,prompt]
    elif host=='claude':
        cmd=['claude','--print','--verbose','--output-format','stream-json','--permission-mode','bypassPermissions','--model','haiku']
        if resume:cmd+=['--resume',resume]
        cmd+=[prompt]
    else:
        cmd=['codex','exec','-C',str(project),'--skip-git-repo-check','-m','deepseek-v4.1-flash','-c','model_reasoning_effort="low"','-s',('danger-full-access' if os.environ.get('ROS_CODEX_FULL') else 'workspace-write'),'--json']
        if resume:cmd+=['resume',resume]
        cmd+=[prompt]
    (out/'command.json').write_text(json.dumps(cmd,ensure_ascii=False,indent=2))
    start=time.time()
    with (out/'stdout.jsonl').open('w') as stdout,(out/'stderr.txt').open('w') as stderr:
        try:r=subprocess.run(cmd,cwd=project,stdout=stdout,stderr=stderr,timeout=int(os.environ.get('ROS_TIMEOUT','240')));code=r.returncode
        except subprocess.TimeoutExpired:code='timeout'
    (out/'result.json').write_text(json.dumps({'exit':code,'seconds':time.time()-start}))
    (out/'after.json').write_text(json.dumps(snapshot(project),indent=2))
    if globalfile.exists():glob={'exists':True,'sha256':hashlib.sha256(globalfile.read_bytes()).hexdigest(),'mtime_ns':globalfile.stat().st_mtime_ns}
    else:glob={'exists':False}
    (out/'global-after.json').write_text(json.dumps(glob))
    print(host,case,code,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('host');p.add_argument('case');p.add_argument('promptfile');p.add_argument('--resume');p.add_argument('--project',default=str(PROJECT));a=p.parse_args()
    run(a.host,a.case,Path(a.promptfile).read_text(),a.resume,Path(a.project))
