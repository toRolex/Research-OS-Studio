/skill:proof-review /tmp/research-os-v2-hosts/fresh-toy/proof.md

请对上述文件执行完整的 proof-review（standalone 审查）。该文件为明确标注的 toy 原材料。请按 SKILL 流程执行：读取与界定、建立证明义务图、A–H 八项审查、对关键命题做反例尝试、整体闭合检查，最后按审查报告结构输出完整 Markdown 报告。注意：零写入（不修改任何文件、不创建任何文件）；不联网；不修复；不得改变命题或替作者加条件。 Toy 也要走完整检查清单，不得因 trivial 而跳过义务图与闭合检查。
