from pathlib import Path
import json,hashlib,subprocess
from harness import ROOT,snapshot
repo=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.v2-accept-hosts')
manifest={'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'hosts':{}}
for rootname in ['.agents','.claude','.pi']:
 installed=ROOT/'project'/rootname/'skills'; mismatches=[];counts=0;files={}
 for src in (repo/'skills').glob('*/*/SKILL.md'):
  leaf=src.parent
  for f in leaf.rglob('*'):
   if f.is_file():
    dest=installed/leaf.name/f.relative_to(leaf); digest=hashlib.sha256(f.read_bytes()).hexdigest();files[str(dest.relative_to(ROOT))]=digest
    if not dest.exists() or hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:mismatches.append(str(dest))
  counts+=1
 manifest['hosts'][rootname]={'skill_count':counts,'mismatches':mismatches,'files':files}
(ROOT/'installation-manifest.json').write_text(json.dumps(manifest,indent=2));print('INSTALL',[(k,v['skill_count'],len(v['mismatches']))for k,v in manifest['hosts'].items()])
rows=[]
for p in sorted(ROOT.glob('*/*/result.json')):
 d=json.loads(p.read_text());b=json.loads((p.parent/'before.json').read_text());a=json.loads((p.parent/'after.json').read_text());changed=[k for k in b.keys()|a.keys() if b.get(k)!=a.get(k)]
 g=(p.parent/'global-before.json').read_bytes()==(p.parent/'global-after.json').read_bytes()
 rows.append({'case':p.parent.parent.name,'host':p.parent.name,**d,'changed':changed,'global_unchanged':g})
(ROOT/'evidence-index.json').write_text(json.dumps(rows,indent=2));print('CASES',len(rows),'GLOBAL ALL SAME',all(r['global_unchanged'] for r in rows))
for r in rows:
 if r['changed']:print('CHANGED',r['case'],r['host'],r['changed'])
before=json.loads((ROOT/'conflict-fixture-before.json').read_text());after=snapshot(ROOT/'setup-project-conflict');print('CONFLICT PRESERVED',[(k,before[k]==after[k])for k in ['research/research-log.md','research/project.md','.agents/research-os-models.md','research/compute-policy.md']])
(ROOT/'conflict-fixture-after.json').write_text(json.dumps(after,indent=2))
