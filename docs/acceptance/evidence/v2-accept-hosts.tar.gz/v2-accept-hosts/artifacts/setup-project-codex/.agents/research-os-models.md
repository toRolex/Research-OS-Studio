orchestrator: custom/deepseek-v4.1-flash | low
literature: custom/deepseek-v4.1-flash | low
ideator: custom/deepseek-v4.1-flash | low
implementer: custom/deepseek-v4.1-flash | low
analyst: custom/deepseek-v4.1-flash | low
prover: custom/deepseek-v4.1-flash | low
writer: custom/deepseek-v4.1-flash | low
reviewer: custom/deepseek-v4.1-flash | low
