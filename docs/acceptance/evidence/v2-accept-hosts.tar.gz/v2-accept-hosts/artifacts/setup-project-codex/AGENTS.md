## Research OS

研究工作区位于 `research/`。处理本项目的研究任务前，先读 [研究导航](research/README.md)，再读取其中与当前任务相关的原始材料。材料保持原有自然格式和位置。

Idea Discovery、Validation、Paper Writing and Improvement 均由用户显式发起，互不自动启动。内部能力仅在当前授权职责、写入范围与资源内执行；缺少材料、工具或授权时说明缺口。

初始化补齐基础导航、项目级角色表和默认算力政策。默认政策的额度是 0，不是运行许可。各 Workflow 的具体产物在用户首次授权使用时创建。环境、付费资源和远程副作用由项目用户决定。
