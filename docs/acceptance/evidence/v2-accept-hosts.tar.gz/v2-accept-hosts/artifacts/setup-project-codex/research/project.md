# 项目说明

验收 fixture（acceptance fixture）。项目名称：integer-sum-toy。

研究材料沿用项目原有格式和位置；本导航不改变环境配置。
