# integer-sum-toy · 研究导航

本项目的研究工作区位于 `research/`；已有材料原位保留。

- [项目说明](project.md)
- [Findings](findings.md)
- [研究日志](research-log.md)
