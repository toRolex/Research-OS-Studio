# 项目级 Research OS 角色表 · integer-sum-toy
# 模型均来自初始化当日宿主 GET /v1/models 逐字返回清单；thinking 档位未在清单分列，由用户逐角色确认。
# 范围：仅本 toy 项目。

orchestrator: anthropic/claude-sonnet-4-6 | high
literature: anthropic/claude-sonnet-4-6 | high
ideator: anthropic/claude-sonnet-4-6 | high
implementer: anthropic/claude-sonnet-4-6 | high
analyst: anthropic/claude-sonnet-4-6 | high
prover: anthropic/claude-sonnet-4-6 | high
writer: anthropic/claude-sonnet-4-6 | high
reviewer: anthropic/claude-sonnet-4-6 | high
