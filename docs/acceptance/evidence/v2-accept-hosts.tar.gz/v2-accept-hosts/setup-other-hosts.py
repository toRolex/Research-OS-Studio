from harness import run,ROOT,PROJECT
from pathlib import Path
import shutil,concurrent.futures
prompt='请初始化当前/tmp toy项目，名称integer-sum-toy，说明明确标注的验收fixture，research/工作区，指令文件选AGENTS.md。按真正安装的setup skill执行：你自己查询当前宿主session真正可用模型，只有清单内slug可以推荐，八角色一次确认一个，完整草稿后等待批准。不读取凭据、不改全局配置、不跑科研任务，本轮未确认任何角色或写入。若当前宿主没有模型清单能力，准确记录尝试和停止缺口，不能拿pi清单替代。'
def one(host):
 project=ROOT/f'setup-project-{host}';shutil.copytree(PROJECT,project,dirs_exist_ok=True)
 for f in ['AGENTS.md','.agents/research-os-models.md']:
  p=project/f
  if p.exists():p.unlink()
 if (project/'research').exists():shutil.rmtree(project/'research')
 run(host,'setup-native',('/setup-research-os ' if host=='claude' else '$setup-research-os ')+prompt,project=project)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(one,['claude','codex']))
