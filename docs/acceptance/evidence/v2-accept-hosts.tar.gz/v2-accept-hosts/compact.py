import json,pathlib,sys
for case in sys.argv[1:]:
 for p in (pathlib.Path('/tmp/research-os-v2-hosts')/case).iterdir():
  if not (p/'stdout.jsonl').exists():continue
  print('\nCASE',case,p.name)
  for l in (p/'stdout.jsonl').read_text().splitlines():
   try:v=json.loads(l)
   except:continue
   if v.get('type')=='message_end' and v.get('message',{}).get('role')=='assistant':
    for c in v['message']['content']:
     if c['type']=='text':print(c['text'])
     if c['type']=='toolCall':print('TOOL',c['name'],str(c.get('arguments'))[:300])
   if v.get('type')=='assistant':
    for c in v['message']['content']:
     if c['type']=='text':print(c['text'])
     if c['type']=='tool_use':print('TOOL',c['name'],str(c.get('input'))[:300])
   if v.get('type')=='item.completed':
    i=v['item']
    if i['type']=='agent_message':print(i['text'])
    if i['type']=='command_execution':print('TOOL',i.get('command'),i.get('exit_code'))
   if v.get('type') in ['result','thread.started']:print('META',v.get('session_id') or v.get('thread_id'))
