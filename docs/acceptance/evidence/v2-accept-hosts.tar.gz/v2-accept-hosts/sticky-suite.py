from harness import ROOT,run
import json,concurrent.futures
roles=['pi','claude','codex']
def one(host):
 p=ROOT/'serial-plan'/host/'stdout.jsonl'
 events=[]
 for l in p.read_text().splitlines():
  try:events.append(json.loads(l))
  except:pass
 if host=='pi':session=str(ROOT/'serial-plan/pi/session.jsonl')
 elif host=='claude':session=next(v['session_id'] for v in events if v.get('type')=='result') if any(v.get('type')=='result' for v in events) else next(v['session_id'] for v in events if v.get('type')=='system')
 else:session=next(v['thread_id'] for v in events if v.get('type')=='thread.started')
 project=ROOT/f'boundary-project-{host}'
 run(host,'sticky','继续，看下一阶段。仍只规划，不授权执行或文件写入；如当前计划已经交付，说明路线粘性、停止边界，不能借此切换实验执行。所有Python工具用UV。',session,project)
 run(host,'new-task','new task 我该从哪开始？现在我只要入口推荐，实际材料换为toy论文初稿+toy人工评审，但没有新的执行授权。未来想回复审稿并跑实验，现在不要执行、不写文件、不联网、不创建任务、不委派。请重匹配，只读推荐并读推荐叶全文。',session,project)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(one,roles))
