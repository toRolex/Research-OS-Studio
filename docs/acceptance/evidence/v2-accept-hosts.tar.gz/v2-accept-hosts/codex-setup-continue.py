from harness import run,ROOT
import json,pathlib
base=ROOT/'setup-native/codex/stdout.jsonl'
thread=next(json.loads(l)['thread_id'] for l in base.read_text().splitlines() if json.loads(l).get('type')=='thread.started')
project=ROOT/'setup-project-codex'
run('codex','setup-codex-provider','先不要发明codex/前缀。只读宿主非凭据配置字段model_provider，用UV运行tomllib仅输出此字段，不输出其他值，不读auth文件。结合真正codex debug models的deepseek-v4.1-flash slug和已成功运行的当前session，核实完整provider/model-id是否为custom/deepseek-v4.1-flash。所有Python操作用uv run。核实后确认orchestrator: custom/deepseek-v4.1-flash | low，仅本toy项目。继续一次只询问一个角色，未批准写入。',thread,project)
for role in ['literature','ideator','implementer','analyst','prover','writer','reviewer']:
 run('codex',f'setup-codex-{role}',f'确认当前 {role}: custom/deepseek-v4.1-flash | low，仅本toy项目，支持档位已在本轮清单。所有Python用uv run。只确认这一个角色，继续下一个询问，最后一个后展示完整草稿，仍未批准写入。',thread,project)
