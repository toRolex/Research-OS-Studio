from pathlib import Path
import shutil,json,hashlib,tarfile
from harness import ROOT
repo=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.v2-accept-hosts')
stage=ROOT/'archive';stage.mkdir(exist_ok=True)
for p in ROOT.glob('*/*/result.json'):
 out=stage/p.parent.relative_to(ROOT);out.mkdir(parents=True,exist_ok=True)
 for f in p.parent.iterdir():
  if f.is_file():shutil.copy2(f,out/f.name)
for name in ['host-sessions','fresh-toy']:
 shutil.copytree(ROOT/name,stage/name,dirs_exist_ok=True)
for p in ROOT.glob('*'):
 if p.is_file() and p.suffix in ['.py','.json','.txt','.log']:shutil.copy2(p,stage/p.name)
for name in ['project','setup-project-codex','setup-project-claude','setup-project-conflict']:
 src=ROOT/name;dst=stage/'artifacts'/name
 for rel in ['.agents/research-os-models.md','AGENTS.md','research']:
  f=src/rel;target=dst/rel
  if f.exists():
   target.parent.mkdir(parents=True,exist_ok=True)
   if f.is_dir():shutil.copytree(f,target,dirs_exist_ok=True)
   else:shutil.copy2(f,target)
manifest={str(f.relative_to(stage)):hashlib.sha256(f.read_bytes()).hexdigest() for f in stage.rglob('*') if f.is_file()}
(stage/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
output=repo/'docs/acceptance/evidence/v2-accept-hosts.tar.gz';output.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(output,'w:gz') as t:t.add(stage,arcname='v2-accept-hosts')
print(output,output.stat().st_size,hashlib.sha256(output.read_bytes()).hexdigest())
