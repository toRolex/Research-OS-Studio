from harness import run,ROOT
import concurrent.futures
prompt=(ROOT/'route-prompt.txt').read_text()
def one(h):run(h,'route-current',prompt.replace('/research-os','$research-os' if h=='codex' else '/research-os'),project=ROOT/f'boundary-project-{h}')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(one,['claude','codex']))
