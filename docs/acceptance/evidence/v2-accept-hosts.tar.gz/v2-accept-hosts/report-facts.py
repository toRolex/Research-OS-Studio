import json,pathlib
r=pathlib.Path('/tmp/research-os-v2-hosts')
for case in ['custom','ambiguity','cascade-gate','mismatch','sticky','new-task']:
 for p in (r/case).iterdir():
  if not (p/'stdout.jsonl').exists():continue
  texts=[]
  for l in (p/'stdout.jsonl').read_text().splitlines():
   try:v=json.loads(l)
   except:continue
   if v.get('type')=='message_end' and v.get('message',{}).get('role')=='assistant':texts +=[c['text']for c in v['message']['content']if c['type']=='text']
   if v.get('type')=='assistant':texts +=[c['text']for c in v['message']['content']if c['type']=='text']
   if v.get('type')=='item.completed' and v['item']['type']=='agent_message':texts.append(v['item']['text'])
  print(case,p.name,' | '.join(texts)[-1800:])
