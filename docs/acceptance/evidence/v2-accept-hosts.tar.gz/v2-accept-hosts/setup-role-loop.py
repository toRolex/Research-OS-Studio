from pathlib import Path
from harness import run,ROOT
session=str(ROOT/'setup-01/pi/session.jsonl')
roles=['orchestrator','literature','ideator','implementer','analyst','prover','writer','reviewer']
for i,role in enumerate(roles,3):
 prompt=f'确认 {role}: cliproxy/glm-5.3-flash | off，仅本toy项目配置。只确认当前这个角色，继续下一角色询问；最后一个角色后继续展示完整草稿，未批准写入。'
 run('pi',f'setup-{i:02d}-{role}',prompt,session)
