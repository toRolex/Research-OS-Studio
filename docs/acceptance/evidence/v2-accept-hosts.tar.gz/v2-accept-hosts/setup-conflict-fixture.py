from pathlib import Path
import shutil,json,hashlib
from harness import ROOT,PROJECT,snapshot
p=ROOT/'setup-project-conflict';shutil.copytree(PROJECT,p,dirs_exist_ok=True)
(p/'AGENTS.md').write_text('# Existing instructions\n\nKEEP-OUTSIDE-BEFORE\n\n## Research OS\n\nLegacy workspace is research/. Preserve existing log.\n\n## Local commands\n\nKEEP-OUTSIDE-AFTER\n')
(p/'research/research-log.md').write_text('# Existing toy research log\n\nfixture baseline bytes; no real experiments; unknown costs stay unknown.\n')
(p/'research/project.md').write_text('# Existing toy material\n\nMATERIAL-DO-NOT-MOVE\n')
(p/'research/findings.md').unlink()
(ROOT/'conflict-fixture-before.json').write_text(json.dumps(snapshot(p),indent=2))
