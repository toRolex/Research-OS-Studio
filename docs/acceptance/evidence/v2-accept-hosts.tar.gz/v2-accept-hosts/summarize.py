import json,pathlib,sys
r=pathlib.Path('/tmp/research-os-v2-hosts')/sys.argv[1]
for p in r.iterdir():
 if not (p/'result.json').exists():continue
 print('\nHOST',p.name,(p/'result.json').read_text(),'UNCHANGED',json.loads((p/'before.json').read_text())==json.loads((p/'after.json').read_text()))
 for l in (p/'stdout.jsonl').read_text().splitlines():
  try:v=json.loads(l)
  except:continue
  t=v.get('type')
  if t in ['message_end','assistant','result','item.completed','tool_execution_start']:
   print(json.dumps(v,ensure_ascii=False)[:9000])
 print('ERR',(p/'stderr.txt').read_text()[-1000:])
