from pathlib import Path
import shutil, concurrent.futures
from harness import run,ROOT,PROJECT
cases={
'implicit':'请用普通算术解释为什么1+2=3。本轮不需要Research OS初始化或任何科研工作流；不用读skill、不写文件、不联网。',
'direct':'{cmd}proof-review 请只读审查toy证明：固定命题是对所有实数x有x²>0，作者论证x²≥0所以x²>0。指出边界反例，在回复输出审查，不写文件、不换命题、不安装Lean。这是明确标注的toy证明，不是外部论文。',
'serial-plan':'{cmd}research-os 设计实验：toy固定问题：在相同本地整数序列上比较Python sum和显式for循环，命题仅限正确性是否一致，不主张速度或论文新颖性。没有代码、数据、评估器或已批准预算。请按playbook走叶全文和适用资源，本次只在对话完成待补全计划，不授权落盘、不实现、不跑实验，不要把缺口编成可执行计划。当前没有委派工具时按正文串行执行；有工具也不必为此只读规划派发。',
'mismatch':'{cmd}research-os 写机器学习论文：我实际只有toy整数求和的两行普通数学证明，没有模型、训练、seeds、实验数据或代码。不要虚构ML材料。未批准任何写入或工作流预算，按实际材料决定适用入口，在叶现有授权门等待。不要运行实验、联网、上传。',
'custom':'{cmd}research-os 没有对应流程：请设计一个明确不属于科研写作、证明、实验、文献或改进的流程，用于本toy实验室把库存物品名称人工归类到架位。只设计有界流程，禁止执行和文件写入。材料缺少条目但目标没有歧义，可以标缺口不要为了缺项先追问。',
'ambiguity':'{cmd}research-os 没有对应流程：本toy库存清单里我说“清理记录”，可能是仅标记重复供人工核查，也可能是删除重复条目，两者我还没选定；请处理这个真歧义。未批准删除、写入或任何执行。',
'cascade-gate':'{cmd}research-os 回复审稿：这是明确标注toy自建材料，不是真实论文或外部评审。toy论文声称所有实数x的x²>0；toy评审指出x=0反例。请按rebuttal处理concern和策略，在策略确认门停下，未批准回复起草、文件写入、上传或外发，也不能伪称真实外部评审。'
}
def one(host):
 project=ROOT/f'boundary-project-{host}';shutil.copytree(PROJECT,project,dirs_exist_ok=True)
 # Setup writes belong only to the separate setup project, not this fixture.
 for f in ['AGENTS.md','.agents/research-os-models.md']:
  p=project/f
  if p.exists():p.unlink()
 if (project/'research').exists():shutil.rmtree(project/'research')
 prefix={'pi':'/skill:','claude':'/','codex':'$'}[host]
 for case,prompt in cases.items():run(host,case,prompt.format(cmd=prefix),project=project)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,['pi','claude','codex']))
