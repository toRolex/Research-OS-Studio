from harness import run,ROOT
thread='f7aefc86-9878-44ab-8806-0b156295e29f';project=ROOT/'setup-project-claude'
for role in ['orchestrator','literature','ideator','implementer','analyst','prover','writer','reviewer']:
 run('claude',f'setup-claude-{role}',f'确认当前 {role}: anthropic/claude-sonnet-4-6 | high，仅本toy项目。model-id是刚才宿主GET /v1/models里逐字返回的claude-sonnet-4-6，provider用宿主anthropic兼容身份anthropic，不发明别的slug；high来自当前Claude --effort支持档，目录未分列已知限制。只确认这个角色，继续询问下一角色，最后一个后展示完整7文件全文，仍未批准写入。不要读取任何凭据，Python全UV。',thread,project)
