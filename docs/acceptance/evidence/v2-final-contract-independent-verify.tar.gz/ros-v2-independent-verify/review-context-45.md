## 已闭合票的 improvement 补实验 review 补强

#45此前已完成并闭合；本次最终review发现既有补实验分支缺批次完整核实，现补强，不重开票、不声称旧零实验轨迹已覆盖新分支。

本地 integration --no-ff merge `9091baf` → `1e67d82`（未push），仅既有入口/14playbook/共享reference/checker和回归测试，不重写叶科研步骤、不建产品runtime。

improvement必须读共享batch及真实本批log；每次同时核scope/expiry/per-attempt/累计actual+running最坏预留/attempt名额/concurrency/retry，未知不释放预留、单写账者。独立原始trace核：expired-retest22工具、0job、0文件/账变化；valid-retest实际fresh implementer GLM high + 两reviewer gpt medium，真attempt exit7再0，CPU累计 `0.000016298333333333333` core-hour，失败同占2/2，第三明确拒绝、无产物；两原回应在canonical逐字相同。

历史裸Python与原3MB存储越界仍FAIL；追加20MB/15min只允许最后复审与日志，不追认、不增attempt。五行TOY ready9/10是当前产物有限PASS，不等于科研真值/publication-ready/完整历史流程PASS；执行时源码身份和独立历史admission见证有限。

独立checker39/U38M1、74tests、LSP0/diff clean；本地 `docs/acceptance/v2-final-contract-fixes.md` + 原始2.49MB包 hash/payload/current-source/sensitive核通过。三宿主当前skill轻验另记。#37/#46关闭留主；不tag/push/PR。
