## 已闭合票的最终 review 补强（不重开，不追认旧失败）

#40 先前已完成并闭合；最终独立 review 后对既有合同补强，不宣称原闭合时已具备这些新校验。

本地 integration 已 --no-ff 合入 `v2/final-contract-fixes` `9091baf`，merge `1e67d82`，未 push：GitHub暂不可读本机源/包。

- 项目八角色现有入口/14 playbook 的实际阶段 `Role:` 明确绑定；fresh 显式传 project provider/model-id + thinking，不修改当前宿主/全局配置，缺行fallback明示，显式无效/重复停。
- 唯一既有 checker 补政策非空、有限数/整数、单次累计配对、唯一scalar、币种形态与带时区合法ISO日期/offset。独立反例：空currency/bad ISO/重复cost原checker exit0，合后exit1；默认模板及合法异构正例继续通过。
- 独立重跑 checker39/U38M1、29+45=74tests；改动Python主动LSP0；diff check通过。真实fresh角色与失败7/成功0两attempt证据及历史预算失败明确分开。

本地报告 `docs/acceptance/v2-final-contract-fixes.md`；包2489643bytes SHA256 `f2657476febf3689258397dc35d924b0e32ba5b4ca505d946374438d056b2df1`，455payload+272 current skill bytes独立匹配，secret候选0。原UV/3MB存储越界、独立见证局限保留，不升成完整历史PASS。#37/#46不关闭；不tag/push/PR。
