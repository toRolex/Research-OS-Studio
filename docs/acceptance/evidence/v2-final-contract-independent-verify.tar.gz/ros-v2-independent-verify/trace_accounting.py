from pathlib import Path
import tarfile,json,re
A=Path('docs/acceptance/evidence/v2-final-contract-fixes.tar.gz');O=Path('/tmp/ros-v2-independent-verify')
with tarfile.open(A) as t:
 B={m.name.removeprefix('ros-v2-final-contract/'):t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
records=[json.loads(l) for l in B['valid-retest/sessions/implementer-fresh.jsonl'].decode().splitlines()]
interesting=[];before_reservations=[];launches=[];refusals=[]
results={e['message']['toolCallId']:e['message'] for e in records if e.get('message',{}).get('role')=='toolResult'}
for e in records:
 m=e.get('message',{})
 for c in m.get('content',[]):
  if c.get('type')!='toolCall':continue
  a=c['arguments'];s=json.dumps(a,ensure_ascii=False)
  if c['name'] in ('edit','write') and 'research-log.md' in s:
   interesting.append({'timestamp':e['timestamp'],'name':c['name'],'arguments':a})
   new_content='\n'.join(edit.get('newText','') for edit in a.get('edits',[]))
   if 'Prelaunch reservation' in new_content and not results.get(c['id'],{}).get('isError',True):before_reservations.append(e['timestamp'])
   if 'Third-attempt refusal' in s:refusals.append(e['timestamp'])
  if c['name']=='bash' and re.search('uv run python meter.py (fail|success)',a['command'].split('<<',1)[0]):
   launches.append(e['timestamp']);interesting.append({'timestamp':e['timestamp'],'name':c['name'],'arguments':a})
assert len(launches)==2 and len(before_reservations)==2
assert before_reservations[0]<launches[0]<before_reservations[1]<launches[1]<refusals[0]
(O/'trace-ledger-order.json').write_text(json.dumps({'reservations':before_reservations,'launches':launches,'refusals':refusals,'in_order':True,'events':interesting},ensure_ascii=False,indent=2))
print('Actual session tool write reservation precedes each true job; failed completion precedes next reservation; refusal follows 2nd job. Independent filesystem history/source runtime identity still not certified.')
