from pathlib import Path
import hashlib,json,re,tarfile
O=Path('/tmp/ros-v2-independent-verify');root=Path.cwd();files={p.name:p.read_bytes() for p in O.iterdir() if p.is_file() and p.name not in ('package.py','SHA256SUMS.json','scan.json')}
files['package.py']=Path(__file__).read_bytes()
patterns={'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','provider_key':r'\b(?:sk-[A-Za-z0-9]{24,}|ghp_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,}|AKIA[A-Z0-9]{16})','bearer':r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}','url_userinfo':r'https?://[^\s/@:]+:[^\s/@]+@','signed_query':r'(?i)(?:X-Amz-Signature|X-Amz-Security-Token|X-Goog-Signature|[?&]token)=[^\s&"\\]{16,}'}
def strings(v):
 if isinstance(v,str):yield v
 elif isinstance(v,list):
  for x in v:yield from strings(x)
 elif isinstance(v,dict):
  for x in v.values():yield from strings(x)
candidates=[]
for name,b in files.items():
 text=b.decode(errors='replace')
 if name.endswith('.json'):
  try:text+='\n'+'\n'.join(strings(json.loads(text)))
  except ValueError:pass
 for category,pat in patterns.items():
  if re.search(pat,text):candidates.append({'path':name,'category':category})
assert not candidates,candidates
scan={'secret_candidates':candidates,'value_output':False,'includes_failures':True,'mutant_trees_excluded':True}
files['scan.json']=json.dumps(scan,indent=2).encode()
manifest={k:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for k,b in files.items()};files['SHA256SUMS.json']=json.dumps(manifest,indent=2).encode()
archive=root/'docs/acceptance/evidence/v2-final-contract-independent-verify.tar.gz'
import io
with tarfile.open(archive,'w:gz') as tf:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo('ros-v2-independent-verify/'+name);info.size=len(b);tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as tf:
 for m in tf.getmembers():
  name=m.name.split('/',1)[1];b=tf.extractfile(m).read()
  if name in manifest:assert manifest[name]['bytes']==len(b) and manifest[name]['sha256']==hashlib.sha256(b).hexdigest()
print(json.dumps({'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'payloads':len(manifest),'scan':scan},indent=2))
