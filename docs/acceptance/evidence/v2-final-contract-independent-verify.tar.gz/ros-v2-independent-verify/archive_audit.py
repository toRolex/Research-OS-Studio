from pathlib import Path,PurePosixPath
import tarfile,json,re,hashlib
from decimal import Decimal
ROOT=Path.cwd(); OUT=Path('/tmp/ros-v2-independent-verify'); archive=ROOT/'docs/acceptance/evidence/v2-final-contract-fixes.tar.gz'
assert archive.stat().st_size==2489643
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='f2657476febf3689258397dc35d924b0e32ba5b4ca505d946374438d056b2df1'
with tarfile.open(archive) as t:
 members=t.getmembers()
 assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
 B={m.name.removeprefix('ros-v2-final-contract/'):t.extractfile(m).read() for m in members}
manifest=json.loads(B['evidence/SHA256SUMS.json'])
assert len(B)==456 and len(manifest)==455
assert set(B)==set(manifest)|{'evidence/SHA256SUMS.json'}
for k,v in manifest.items():assert len(B[k])==v['bytes'] and hashlib.sha256(B[k]).hexdigest()==v['sha256'],k
source=[k for k in B if k.startswith('source/skills/')]
assert len(source)==272
for k in source:assert B[k]==(ROOT/k.removeprefix('source/')).read_bytes(),k
patterns={
 'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'provider_key':r'\b(?:sk-[A-Za-z0-9]{24,}|ghp_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,}|AKIA[A-Z0-9]{16})',
 'bearer':r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}',
 'url_userinfo':r'https?://[^\s/@:]+:[^\s/@]+@',
 'signed_query':r'(?i)(?:X-Amz-Signature|X-Amz-Security-Token|X-Goog-Signature|[?&]token)=[^\s&"\\]{16,}'
}
def strings(v):
 if isinstance(v,str):yield v
 elif isinstance(v,list):
  for item in v:yield from strings(item)
 elif isinstance(v,dict):
  for item in v.values():yield from strings(item)
def records(k):return [json.loads(l) for l in B[k].decode().splitlines() if l.strip()]
candidates=[]
for k,b in B.items():
 text=b.decode(errors='replace'); decoded=[]
 if k.endswith(('.json','.jsonl')):
  try:
   values=records(k) if k.endswith('.jsonl') else [json.loads(text)]
   decoded=[s for v in values for s in strings(v)]
  except ValueError:pass
 text+='\n'+'\n'.join(decoded)
 for name,pat in patterns.items():
  if re.search(pat,text):candidates.append({'path':k,'category':name})
assert not candidates,candidates
summ={}; indexed=[]
for case in ('expired-retest','valid-retest'):
 session='evidence/'+case+'.session.jsonl';events=records(session)
 for child_session in B:
  if child_session.startswith(case+'/sessions/') and child_session.endswith('.jsonl'):events+=records(child_session)
 calls=[];answers={};models=[]
 for e in events:
  if e.get('type') in ('model_change','thinking_level_change'):models.append({key:e[key] for key in ('type','provider','modelId','thinkingLevel') if key in e})
  m=e.get('message',{})
  if m.get('role')=='toolResult':answers[m.get('toolCallId')]=m
  for c in m.get('content',[]):
   if c.get('type')=='toolCall':calls.append(c)
 jobs=[c for c in calls if c['name']=='bash' and re.search(r'uv run python meter\.py (?:fail|success)',c['arguments']['command'].split('<<',1)[0])]
 assert len(jobs)==(0 if case.startswith('expired') else 2)
 before=json.loads(B['evidence/'+case+'.before.json']); after=json.loads(B['evidence/'+case+'.after.json'])
 for p in ('plan.md','method.py','evaluator.py','meter.py','results.csv','compute-policy.md','.agents/research-os-models.md','findings.md'):assert before[p]==after[p]
 if case.startswith('expired'):
  assert before['research-log.md']==after['research-log.md'] and before==after
  assert not any(k.startswith(case+'/results/') for k in B)
 children=[]
 for k in B:
  if k.startswith(case+'/sessions/') and k.endswith('.jsonl'):
   es=records(k);identity=[{key:e[key] for key in ('type','provider','modelId','thinkingLevel') if key in e} for e in es if e.get('type') in ('model_change','thinking_level_change')]
   messages=[e['message'] for e in es if e.get('message',{}).get('role')=='assistant' and e['message'].get('stopReason')=='stop']
   text=''.join(c.get('text','') for c in messages[-1]['content'] if c.get('type')=='text')
   if 'review' in k:assert text in B[case+'/IMPROVEMENT_LOG.md'].decode()
   children.append({'session':k,'identity':identity})
 summ[case]={'observed_parent_and_child_identities':models,'tool_calls':len(calls),'jobs':len(jobs),'children':children,'frozen_unchanged':True}
 for c in calls:
  if c['name']=='bash' and any(s in c['arguments']['command'] for s in ('meter.py fail','meter.py success','--session','date -u')):
   result=answers.get(c['id'],{});indexed.append({'case':case,'call':c,'result':result})
# Parent and all 3 children actual identities, no inferred models from prompts.
assert len(summ['valid-retest']['children'])==3
for child in summ['valid-retest']['children']:
 expected='glm-5.3-flash' if 'implementer' in child['session'] else 'gpt-6.1-sol'
 effort='high' if 'implementer' in child['session'] else 'medium'
 assert any(v.get('modelId')==expected for v in child['identity'])
 assert any(v.get('thinkingLevel')==effort for v in child['identity'])
meters=[json.loads(B['valid-retest/results/'+a+'.json.meter.json']) for a in ('a1','a2')]
assert [m['exit_code'] for m in meters]==[7,0]
assert all(Decimal(str(m['cpu_core_hour']))<=Decimal('.001') for m in meters)
cpu=sum(Decimal(str(m['cpu_core_hour'])) for m in meters);assert cpu<Decimal('.004')
rows=json.loads(B['valid-retest/results/a2.json']);assert rows['n']==5 and rows['mae']==0
log=B['valid-retest/research-log.md'].decode(); assert 'a1' in log and 'a2' in log and str(meters[0]['cpu_core_hour']) in log and str(meters[1]['cpu_core_hour']) in log
assert not any(k.startswith('valid-retest/results/a3') for k in B)
assert any('3MB' in b.decode(errors='replace') or '3 MB' in b.decode(errors='replace') for k,b in B.items() if k=='valid-retest/IMPROVEMENT_LOG.md')
summary={'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'regular_files':len(B),'payload_matches':len(manifest),'source_current_matches':len(source),'secret_candidates':candidates,'cases':summ,'meter_exit_codes':[m['exit_code'] for m in meters],'cpu_total_decimal':str(cpu),'attempt_count':2,'third_artifact_absent':True,'canonical_responses_exact':True}
(OUT/'archive-audit.json').write_text(json.dumps(summary,indent=2));(OUT/'selected-primary-calls.json').write_text(json.dumps(indexed,ensure_ascii=False,indent=2))
print(json.dumps(summary,indent=2))
