from pathlib import Path
import subprocess,json,shutil
ROOT=Path.cwd(); OUT=Path('/tmp/ros-v2-independent-verify'); W=OUT/'mutant'
if W.exists(): raise SystemExit('refuse overwrite')
W.mkdir()
tracked=subprocess.check_output(['git','ls-files'],text=True).splitlines()
for rel in tracked:
 src,dst=ROOT/rel,W/rel
 if not src.is_file(): continue
 dst.parent.mkdir(parents=True,exist_ok=True)
 if src.suffix in ('.md','.py','.yaml'):shutil.copyfile(src,dst)
 else:dst.touch()
subprocess.run(['git','init','-q'],cwd=W,check=True);subprocess.run(['git','add','-A'],cwd=W,check=True)
S='skills/general/research-os/SKILL.md';P='skills/general/research-os/playbooks/improvement.md';Y='skills/general/research-os/agents/openai.yaml';C='skills/general/setup-research-os/templates/compute-policy.md'
cases=[('relative_missing',P,'', '\n必须读 `./references/INDEPENDENT-NONEXISTENT.md`。\n'),('relative_parent_missing',P,'','\n必须读 `../references/INDEPENDENT-NONEXISTENT.md`。\n'),('old_router_per_reference','README.md','','\n现在请使用 /ask-research-os。\n'),('duplicate_flag_true_false',S,'disable-model-invocation: true','disable-model-invocation: true\ndisable-model-invocation: false'),('duplicate_flag_false_true',S,'disable-model-invocation: true','disable-model-invocation: false\ndisable-model-invocation: true'),('empty_currency',C,'currency: 未指定','currency:'),('bad_iso_calendar',C,'valid_until: 未指定','valid_until: 2031-02-29T12:00:00Z'),('bad_iso_offset',C,'valid_until: 未指定','valid_until: 2030-01-01T00:00:00+01:99'),('bad_iso_no_zone',C,'valid_until: 未指定','valid_until: 2030-01-01T00:00:00'),('duplicate_scalar_cost',C,'','\n- cost_limit: 0\n'),('duplicate_scalar_expiry',C,'','\n- valid_until: 未指定\n'),('duplicate_allow',Y,'allow_implicit_invocation: false','allow_implicit_invocation: false\n  allow_implicit_invocation: true')]
results=[]
def run(name):
 r=subprocess.run(['uv','run','--no-project','python','scripts/check-skills.py'],cwd=W,text=True,capture_output=True)
 (OUT/(name+'.txt')).write_text(r.stdout+r.stderr)
 return r.returncode
assert run('independent-positive-control')==0
for name,rel,old,new in cases:
 p=W/rel;original=p.read_text();assert not old or old in original
 p.write_text(original.replace(old,new,1) if old else original+new)
 rc=run(name);p.write_text(original)
 assert rc!=0,name
 results.append({'case':name,'fixed_exit':rc})
# Independent red control: checker before review fixes accepts the six original counterexamples.
oldchecker=subprocess.check_output(['git','show','76af6a3:scripts/check-skills.py'],text=True)
checker=W/'scripts/check-skills.py';fixed=checker.read_text();checker.write_text(oldchecker)
for name,rel,old,new in [cases[i] for i in (0,2,3,5,6,9)]:
 p=W/rel;original=p.read_text();p.write_text(original.replace(old,new,1) if old else original+new)
 rc=run('pre-fix-'+name);p.write_text(original)
 assert rc==0,(name,rc)
 for row in results:
  if row['case']==name:row['pre_fix_exit']=rc
checker.write_text(fixed)
assert run('restored-positive-control')==0
(OUT/'independent-mutations.json').write_text(json.dumps({'cases':results,'positive_controls_exit':0},indent=2))
print(json.dumps(results,indent=2))
