from pathlib import Path
import runpy,json
N=runpy.run_path('scripts/check-skills.py');root=Path.cwd();rel='skills/general/research-os/playbooks/improvement.md'
results=[]
for target in ('./references/batch-authorization.md','../references/batch-authorization.md','../../research-os/references/batch-authorization.md'):
 exists=(root/rel).parent.joinpath(target).is_file();errors=N['backtick_cascade_problems'](rel,'读 `'+target+'`。',root,N['tracked']);results.append({'target':target,'actual_source_relative_exists':exists,'checker_errors':errors})
Path('/tmp/ros-v2-independent-verify/relative-base-before.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
assert results[0]['checker_errors'],'wrong-base same-name target silently accepted'
