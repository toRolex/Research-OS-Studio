import subprocess,json,time
from pathlib import Path
O=Path('/tmp/ros-v2-independent-verify');events=[]
def gh(args,timeout=25):
 try:
  r=subprocess.run(['gh',*args],capture_output=True,text=True,timeout=timeout)
  event={'args':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 except subprocess.TimeoutExpired as e:event={'args':args,'exit':'timeout','stdout':(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else e.stdout,'stderr':(e.stderr or b'').decode() if isinstance(e.stderr,bytes) else e.stderr}
 events.append(event);(O/'github-resume.json').write_text(json.dumps(events,ensure_ascii=False,indent=2));return event
# Exactly one budget preflight; use REST because one existing endpoint per issue.
p=gh(['api','rate_limit','--jq','{core:.resources.core,graphql:.resources.graphql}'])
if p['exit']!=0:print('budget preflight failed; no writes attempted');raise SystemExit(0)
budget=json.loads(p['stdout']);assert budget['core']['remaining']>=8
print(json.dumps(budget))
# Recover the original body verbatim, labelled historical; bounded total 3 write attempts for the two summary tickets.
original=Path('/tmp/ros-v2-release-issues/final-context.md').read_text()
body='## GitHub EOF 后恢复发送（历史总结原文）\n\n以下为先前 EOF 未发成功的 final-context 原文，保留当时 commit/68 tests，非当前合后 tip。当前合后复验：1e67d82 merge9091baf；六项review补强与74 tests全绿，新增三宿主轻验另记，不抹历史失败。未push，路径仅本机；#37/#46不关闭，tag/push/PR仍未执行。\n\n'+original
bodypath=O/'recovered-final-context.md';bodypath.write_text(body)
for number in (37,46):
 r=gh(['api',f'repos/toRolex/Research-OS-Studio/issues/{number}/comments?per_page=30','--jq','.[].body'])
 if r['exit']!=0:print('read failed; stop without blind duplicate write');raise SystemExit(0)
 if original in r['stdout']:print(f'#{number} original already delivered');continue
 # budgeted summary attempt cap is shared across both issues.
 prior=sum(e['args'][0]=='api' and '--method' in e['args'] for e in events)
 if prior>=3:break
 response=gh(['api',f'repos/toRolex/Research-OS-Studio/issues/{number}/comments','--method','POST','-F',f'body=@{bodypath}','--jq','{id,html_url}'])
 if response['exit']!=0:print('write failed/ambiguous; stop, preserve raw error (no duplicate retry)');break
 print(response['stdout'])
