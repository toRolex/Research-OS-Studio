## GitHub EOF 后恢复发送（历史总结原文）

以下为先前 EOF 未发成功的 final-context 原文，保留当时 commit/68 tests，非当前合后 tip。当前合后复验：1e67d82 merge9091baf；六项review补强与74 tests全绿，新增三宿主轻验另记，不抹历史失败。未push，路径仅本机；#37/#46不关闭，tag/push/PR仍未执行。

## 最终release-review候选context（保持#37/#46 OPEN）

本地integration最终提交 **`eadfe77ed16ae0bb5dd4cabf1c01a1fa54a47ec1`**；merge `5efd2daffc68612def5e4660defb68db5a7780e3`（`af43cc8 --no-ff fa9065226`），TDD doc/checker小fix `ecdddab`。**未push**：以下路径/commit只在本机，GitHub尚不能读原始包，不冒充在线证据。未tag/PR，不改main/全局。

汇总 `docs/v2-release-acceptance.md`；独立 `docs/acceptance/v2-release-{ac-review,host-regression,gate-combinations,security-static}.md`；因果notes `.agents/notes/v2-merge-remediation-release-implementation-notes.md`。四固定旧报告/包保留全部科研REVISE/WARN、审计FAIL和原越界；#41–45已逐AC评论并关闭，票面剩余AC无。

当前tip真实回归不是从零重复科研长输出：
- 三宿主各39/270文件，810源/安装/current同hash、38explicit/setup唯一allow字段真核。14具体playbook各真实输入→叶/门；默认工具直接/级联/自然串行、sticky/newtask、只读冲突/材料不匹配/custom/歧义、可逆write→亲自read、setup旧物/不可用停。45CLI记录=43完整真实终态+1pickup timeout+1误slash空调用，失败与唯一有界纠正全留。父51tool亲读ML4716行canonical/原批准反馈/CSV/current稿/build2/7PNG/PDF，UV Decimal核50.625/90/39.375。
- 跨票8场+ML同session澄清全exit0/stop：missing、累计failed、unknown保留预留、两pickup真实五件消费/过期、ML拒终止后第4build/外发、talk严重claim停、获准短候选实际write→read。当前真实轻组合+未受diff影响旧14授权全矩阵/科研完整产物合证，诚实标执行tip5efd2da；后doc变产品skills树不变。
- 最后实际UV tip eaa76f0：checker39/U38M1、tests23+scripts45=**68全绿**，diff check过。两真实旧stop句TDD红绿已修，无新runtime/validator。
- 新45MiB整改包898payload、gate576payload、host927payload SHA+bytes全match；完整无值凭据scan真secret0，无需清洗。gate包SHA `2291c39cbe506db6fa90c11e684e5047d9300ebd813d35496d5942e6cbb3efc1` /12,544,022bytes；host包SHA `d80e120694d7623533e253798550a43d8b61b6eea78592a5df388a2063a4cadc` /15,807,902bytes，均在docs/acceptance/evidence。

**#46原AC1–5按有限代表范围已达标；精确未满足AC6：未打v2.0.0 tag（本轮用户明确禁止）。** 可提交最终release review候选，不宣称已发布或所有宿主未来永远安全。过程局限：Codex direct首裸Python，重跑无Python但review-rules输出截断未续读，不能声称该场全部叶resources完整；Claude末把有效反例描述成gap有质量局限。若review要求补单场资源纪律，精确补项为同fixture完整read review-rules+UV/no-write终态，不是学术PASS/全部科研raw重演/真人投影。#42空probe、#44被测fresh像素digest偏差亦已披露。

本次停止，不tag/push/PR、不关闭#37/#46；留最终review决策。
