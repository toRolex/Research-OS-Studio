from pathlib import Path
import hashlib,json,re,shutil,tarfile,datetime
R=Path('/tmp/ros-v2-merged-host-smoke');ROOT=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.integration-research-os-v2');ST=Path('/tmp/ros-v2-merged-host-smoke-archive')/'ros-v2-merged-host-smoke'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
ST.mkdir(parents=True,exist_ok=True)
for name in ('evidence','scripts'):shutil.copytree(R/name,ST/name,dirs_exist_ok=True)
for name in ('report.md','implementation-notes.md'):shutil.copy2(R/name,ST/name)
shutil.copytree(ROOT/'skills',ST/'source/skills',dirs_exist_ok=True)
for h in ('pi','claude','codex'):
 src=R/'projects'/h;dst=ST/'projects'/h;dst.mkdir(parents=True,exist_ok=True)
 for f in src.glob('*'):
  if f.is_file():shutil.copy2(f,dst/f.name)
 (dst/'.agents').mkdir(exist_ok=True);shutil.copy2(src/'.agents/research-os-models.md',dst/'.agents/research-os-models.md')
 (dst/'results').mkdir(exist_ok=True)
patterns={
 'private-key':r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
 'github-token':r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
 'provider-key':r'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}\b',
 'aws-key':r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'bearer':r'(?i)\bBearer\s+[A-Za-z0-9._~-]{16,}',
 'url-userinfo':r'https?://[^\s/<"]+:[^\s/@"]+@',
 'signed-query':r'(?i)[?&](?:access_token|api_key|token|signature|sig|x-amz-signature)=[A-Za-z0-9_%.-]{16,}',
}
compiled={k:re.compile(v) for k,v in patterns.items()};candidates=[];decoded_count=0
for p in sorted(ST.rglob('*')):
 if not p.is_file():continue
 try:text=p.read_text()
 except UnicodeDecodeError:continue
 bodies=[('raw',text)]
 if p.suffix in ('.json','.jsonl') or p.name=='stdout.txt':
  vals=[]
  def walk(v):
   if isinstance(v,str):vals.append(v)
   elif isinstance(v,dict):
    for x in v.values():walk(x)
   elif isinstance(v,list):
    for x in v:walk(x)
  if p.suffix=='.json':
   try:walk(json.loads(text))
   except ValueError:pass
  else:
   for line in text.splitlines():
    try:walk(json.loads(line))
    except ValueError:pass
  decoded_count+=len(vals);bodies.extend(('json-decoded',s) for s in vals)
 for mode,body in bodies:
  for kind,pat in compiled.items():
   for m in pat.finditer(body):candidates.append({'file':str(p.relative_to(ST)),'mode':mode,'kind':kind,'line':body[:m.start()].count('\n')+1})
scan={'patterns':list(patterns),'payload_and_json_decoded':True,'decoded_string_count':decoded_count,'candidate_count':len(candidates),'candidates_locations_only':candidates,'secret_values_not_printed':True};dump(ST/'evidence/security-scan.json',scan);dump(R/'evidence/security-scan.json',scan)
if candidates:print(json.dumps(scan));raise SystemExit('sensitive candidates require manual review; not archived')
manifest={str(p.relative_to(ST)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(ST.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};dump(ST/'evidence/SHA256SUMS.json',manifest);shutil.copy2(ST/'evidence/SHA256SUMS.json',R/'evidence/SHA256SUMS.json')
out=Path('/tmp/ros-v2-merged-host-smoke.tar.gz')
with tarfile.open(out,'w:gz') as tar:tar.add(ST,arcname=ST.name)
errors=[]
with tarfile.open(out,'r:gz') as tar:
 for rel,meta in manifest.items():
  data=tar.extractfile(ST.name+'/'+rel).read()
  if len(data)!=meta['bytes'] or hashlib.sha256(data).hexdigest()!=meta['sha256']:errors.append(rel)
result={'archive':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'payload_count':len(manifest),'hash_mismatches':errors,'scan_candidate_count':len(candidates),'source_skill_files':sum(p.is_file() for p in (ST/'source/skills').rglob('*')),'installed_copy_excluded':True,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};dump(R/'archive-result.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
