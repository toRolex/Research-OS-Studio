from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path('/tmp/ros-v2-merged-host-smoke');ROOT=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.integration-research-os-v2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
def strings(v):
 if isinstance(v,str):yield v
 elif isinstance(v,dict):
  for x in v.values():yield from strings(x)
 elif isinstance(v,list):
  for x in v:yield from strings(x)
def decode(path):
 out=[]
 for n,line in enumerate(path.read_text().splitlines(),1):
  try:v=json.loads(line)
  except ValueError:continue
  out.extend((n,s) for s in strings(v))
 return out
manifest=json.loads((R/'evidence/installation-manifest.json').read_text());install={}
for h,rows in manifest.items():
 bad=[]
 for x in rows:
  src=ROOT/x['source'];dest=R/'projects'/h/x['installed']
  if sha(src)!=x['source_sha256'] or sha(dest)!=x['source_sha256']:bad.append(x['source'])
 install[h]={'files':len(rows),'skills':len({Path(x['installed']).parts[-2] for x in rows if x['installed'].endswith('/SKILL.md')}),'mismatches':bad}
coverage={};checklist={};children={};identities={}
resources=['research-os/SKILL.md','research-os/playbooks/improvement.md','research-improvement/SKILL.md','research-improvement/references/loop-methods.md','research-improvement/references/composition-map.md','research-improvement/templates/improvement-log.md','research-os/references/batch-authorization.md']
for h,label in [('pi','pi'),('claude','claude'),('codex','codex'),('claude','claude/targeted-retry')]:
 e=R/'evidence'/label;p=R/'projects'/h;root=p/({'pi':'.pi/skills','claude':'.claude/skills','codex':'.agents/skills'}[h]);native=e/'session.jsonl' if h=='pi' else next((e/'host-sessions').glob('*.jsonl'))
 decoded=decode(native);norm=[(n,re.sub(r'(?m)^\s*\d+\t','',s)) for n,s in decoded];rows=[]
 for rel in resources+['.agents/research-os-models.md','research-log.md','compute-policy.md','CLAIMS.md','method.py','evaluator.py','meter.py','results.csv','current.diff','findings.md','plan.md']:
  f=root/rel if rel in resources else p/rel;src=f.read_text().strip();body=src
  if rel=='research-os/SKILL.md':body=re.sub(r'^---\n.*?\n---\n','',src,flags=re.S).strip()
  hits=[{'native_line':n,'mode':'full-body' if body in s else 'full-source'} for n,s in norm if src in s or body in s]
  rows.append({'file':rel,'source_sha256':sha(f),'complete_return_hits':hits})
 coverage[label]=rows
 before=json.loads((e/'before.json').read_text());after=json.loads((e/'after.json').read_text());assert before==after
 assist=(e/'assistant.md').read_text().split('\n\n--- MESSAGE ---\n\n');play=(root/'research-os/playbooks/improvement.md').read_text().split('## 步骤\n')[1].split('## 完成')[0].strip().splitlines();first=next((s for s in assist if '1. ' in s and 'loop-authorization 门' in s),'')
 first_without_status=re.sub(r'(?m)^(\d+\.) \[(?:pending|in-progress|completed|blocked)\] ',r'\1 ',first)
 checklist[label]=[{'step':line[:2],'exact_sentence_in_first_message':line in first_without_status} for line in play if re.match(r'^\d\. ',line)]
 if h=='pi':vs=[json.loads(s) for s in native.read_text().splitlines()];identities[label]=[v for v in vs if v.get('type') in ['session','model_change','thinking_level_change']]
 elif h=='claude':
  vs=[json.loads(s) for s in native.read_text().splitlines()];models=sorted({v.get('message',{}).get('model') for v in vs if v.get('message',{}).get('model')});efforts=sorted({v['effort'] for v in vs if 'effort' in v});identities[label]={'models':models,'efforts':efforts,'native_session':native.name}
 else:
  vs=[json.loads(s) for s in native.read_text().splitlines()];identities[label]=[{'type':v['type'],'payload':{k:v['payload'][k] for k in ['id','model','model_provider','effort','originator','cli_version'] if k in v['payload']}} for v in vs if v.get('type') in ['session_meta','turn_context']]
 child=e/'reviewer/session.jsonl'
 if child.exists():
  vs=[json.loads(s) for s in child.read_text().splitlines()];calls=[c for v in vs for c in v.get('message',{}).get('content',[]) if c.get('type')=='toolCall'];messages=[''.join(c.get('text','') for c in v.get('message',{}).get('content',[]) if c.get('type')=='text') for v in vs if v.get('message',{}).get('role')=='assistant'];final=next((s for s in reversed(messages) if s.strip()),'');(e/'reviewer/assistant.md').write_text(final)
  raw='\n'.join(s for _,s in decode(child));read_files=[c.get('arguments',{}).get('path') for c in calls if c.get('name')=='read']
  children[label]={'identity':[v for v in vs if v.get('type') in ['session','model_change','thinking_level_change']],'tool_names':[c.get('name') for c in calls],'read_files':read_files,'all_returns_complete':all(Path(f).read_text().strip() in raw for f in read_files),'final_chars':len(final),'verbatim_final_in_parent':final in (e/'assistant.md').read_text(),'verbatim_after_blockquote_normalization':final in re.sub(r'(?m)^> ?','',(e/'assistant.md').read_text())}
 else:children[label]={'independent_review':'not performed','startup_failure_preserved':True}
g=Path.home()/'.agents/pstack-models.md';gb=json.loads((R/'evidence/global-before.json').read_text());ga={'sha256':sha(g),'mtime_ns':g.stat().st_mtime_ns};dump(R/'evidence/global-after.json',ga)
summary={'installation':install,'coverage':coverage,'first_checklist':checklist,'children':children,'identity':identities,'global_unchanged':gb==ga,'skills_source_unchanged':json.loads((R/'evidence/source-before.json').read_text())=={str(f.relative_to(ROOT/'skills')):sha(f) for f in (ROOT/'skills').rglob('*') if f.is_file()},'repo_status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'tip_final':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()};dump(R/'evidence/mechanical-summary.json',summary)
print(json.dumps({'installation':install,'missing_full_coverage':{k:[r['file'] for r in rows if not r['complete_return_hits']] for k,rows in coverage.items()},'checklist':checklist,'children':{k:{x:v for x,v in child.items() if x!='identity' and x!='read_files'} for k,child in children.items()},'global_unchanged':gb==ga,'skills_source_unchanged':summary['skills_source_unchanged'],'repo_status':summary['repo_status'],'tip_final':summary['tip_final']},ensure_ascii=False,indent=2))
