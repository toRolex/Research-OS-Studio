from pathlib import Path
import json,hashlib
R=Path('/tmp/ros-v2-merged-host-smoke')
for host,label in [('pi','pi'),('claude','claude'),('codex','codex'),('claude','claude/targeted-retry')]:
 e=R/'evidence'/label;events=[];assist=[];tools=[];identities=[]
 for n,line in enumerate((e/'stdout.jsonl').read_text().splitlines(),1):
  try:v=json.loads(line)
  except ValueError:continue
  t=v.get('type')
  if host=='pi':
   if t=='message_end':
    m=v.get('message',{})
    if m.get('role')=='assistant':
     identities.append({k:m[k] for k in ('provider','model','stopReason') if k in m})
     for c in m.get('content',[]):
      if c.get('type')=='text':assist.append(c.get('text',''))
   if t=='tool_execution_start':tools.append({'line':n,'name':v.get('toolName'),'args':v.get('args')})
  elif host=='claude':
   if t=='system' and v.get('subtype')=='init':identities.append(v)
   if t=='assistant':
    m=v.get('message',{});identities.append({'model':m.get('model'),'session_id':v.get('session_id')})
    for c in m.get('content',[]):
     if c.get('type')=='text':assist.append(c.get('text',''))
     if c.get('type')=='tool_use':tools.append({'line':n,'name':c.get('name'),'args':c.get('input')})
   if t=='result':events.append(v)
  else:
   if t=='thread.started':identities.append(v)
   if t=='item.completed':
    item=v.get('item',{})
    if item.get('type')=='agent_message':assist.append(item.get('text',''))
    if item.get('type')=='command_execution':tools.append({'line':n,'name':'command_execution','args':item.get('command'),'exit_code':item.get('exit_code'),'output':item.get('aggregated_output')})
   if t=='turn.completed':events.append(v)
 (e/'assistant.md').write_text('\n\n--- MESSAGE ---\n\n'.join(assist))
 (e/'tool-index.json').write_text(json.dumps(tools,ensure_ascii=False,indent=2))
 (e/'identity-index.json').write_text(json.dumps(identities,ensure_ascii=False,indent=2))
 (e/'terminal-index.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
 before=json.loads((e/'before.json').read_text());after=json.loads((e/'after.json').read_text());diff={'changed':[k for k in before.keys()&after.keys() if before[k]!=after[k]],'added':list(after.keys()-before.keys()),'removed':list(before.keys()-after.keys())}
 (e/'snapshot-diff.json').write_text(json.dumps(diff,indent=2))
 print(label,'tools',len(tools),'assistant chars',sum(map(len,assist)),'diff',diff)
 print('tool summary',json.dumps([{'line':x['line'],'name':x['name'],'args':str(x['args'])[:600]} for x in tools],ensure_ascii=False))
 print('identity',json.dumps(identities[:1]+identities[-1:],ensure_ascii=False)[:2500])
