from pathlib import Path
R=Path('/tmp/ros-v2-merged-host-smoke');e=R/'evidence/claude';r=e/'targeted-retry';r.mkdir(exist_ok=True)
prompt=(e/'prompt.md').read_text().replace(str(e/'reviewer'),str(r/'reviewer'))
prompt+='''
唯一针对性重试，首失败轨迹保留不追认。本次必须修复原真实缺口：
1. 首次步骤清单第4与第5全文原句不得省略号、省路径，不摘要；对照刚读playbook逐字核。除native入口展开外也用Read实际完整读入口SKILL.md，排除自动加载覆盖不清。
2. fresh reviewer输入只能上述11个primary的完整路径（含compute-policy、research-log、角色表），原findings/current.diff与固定问题标准。禁止“固定背景事实”里替reviewer写本批已过期/不能执行/结果为空等父预判，必须由reviewer自己读取原文判定。角色身份核实只派project reviewer精确model+thinking，不能只在话中挂角色标签。
3. 未派implementer/analyst/writer/prover就明确未执行；禁止“由orchestrator按表身份承担”。本宿主只有orchestrator职责（读取核实与日志交付），不切模型代其他阶段。
4. 停止优先：过期、0科研写域，随后轮/fresh额度耗尽，不把分数未达标列成首要掩盖授权门；保持真实UTC字符串，不混2026-10-01。
同原限制：只这个新session、默认工具、最大1 fresh（新证据目录内），child<=120sec、全360sec、证据30MB；0job/0科研写，禁止后续重试、第二child、旧session/fork/resume。research-log confirmation_basis原首prompt不需改，expiry继续绑定2020。保留失败证据只追加新证据，不能删改旧轨迹。最终<=2500汉字+首次完整清单，review原回应逐字保留，不长科研输出。
'''
(r/'prompt.md').write_text(prompt)
