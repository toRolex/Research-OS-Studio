from pathlib import Path
import json,subprocess,time,os,signal,hashlib,concurrent.futures,shutil,datetime
R=Path('/tmp/ros-v2-merged-host-smoke')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
def snap(p):return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
def run(host, retry=False):
 p=R/'projects'/host;e=R/'evidence'/host
 if retry:e=e/'targeted-retry';e.mkdir(exist_ok=True)
 req=json.loads((R/'evidence'/host/'request.json').read_text());prompt=(e/'prompt.md').read_text();session_id=req['session_id']
 if retry:import uuid;session_id=str(uuid.uuid4())
 if host=='pi':cmd=['pi','--no-extensions','--no-context-files','--approve','--model','cliproxy/gpt-6.1-sol','--thinking','medium','--session',str(e/'session.jsonl'),'--mode','json','-p',prompt]
 elif host=='claude':cmd=['claude','--print','--verbose','--output-format','stream-json','--permission-mode','bypassPermissions','--model','glm-5.3-flash','--effort','high','--session-id',session_id,prompt]
 else:cmd=['codex','exec','-C',str(p),'--skip-git-repo-check','-m','deepseek-v4.1-flash','-c','model_reasoning_effort="high"','-s','workspace-write','--json',prompt]
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
 # Standalone tested hosts are not herdr children; do not falsely inherit this runner's identity sidecars.
 removed=[]
 for k in list(env):
  if k.startswith('PI_HERDR_') or k in ('PI_SESSION_FILE','PI_SESSION_ID','PI_MODEL','PI_PROVIDER','PI_REASONING_LEVEL'):
   removed.append(k);env.pop(k)
 dump(e/'environment-policy.json',{'removed_parent_identity_names':removed,'PYTHONDONTWRITEBYTECODE':'1','credentials_values':'not captured'})
 dump(e/'command.json',{'argv':cmd,'cwd':str(p),'requested_model':req['model'],'requested_thinking':req['thinking'],'session_id_requested':session_id,'new_session':True,'resume':False,'fork':False,'default_tools':True})
 dump(e/'before.json',snap(p));start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (e/'stdout.jsonl').open('w') as out,(e/'stderr.txt').open('w') as err:
  proc=subprocess.Popen(cmd,cwd=p,env=env,stdout=out,stderr=err,start_new_session=True)
  dump(e/'running.json',{'pid':proc.pid,'started_at':started})
  try:code=proc.wait(timeout=360)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   code='timeout'
 dump(e/'result.json',{'host':host,'exit':code,'process_returncode':proc.returncode,'seconds':time.monotonic()-start,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()});dump(e/'after.json',snap(p))
 # Copy only this actual native session (no global history).
 if host=='claude':
  matched=list((Path.home()/'.claude/projects').rglob(session_id+'.jsonl'));files=[]
  for src in matched:
   dst=e/'host-sessions'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copy2(src,dst);files.append({'original':str(src),'copy':str(dst),'sha256':sha(src)})
  dump(e/'native-session-copies.json',files)
 elif host=='codex':
  thread=None
  for line in (e/'stdout.jsonl').read_text().splitlines():
   try:v=json.loads(line)
   except ValueError:continue
   if v.get('type')=='thread.started':thread=v.get('thread_id')
  files=[]
  if thread:
   for src in (Path.home()/'.codex/sessions').rglob('*'+thread+'*.jsonl'):
    dst=e/'host-sessions'/src.name;dst.parent.mkdir(exist_ok=True);shutil.copy2(src,dst);files.append({'original':str(src),'copy':str(dst),'sha256':sha(src)})
  dump(e/'native-session-copies.json',files)
 print(host,code,flush=True)
 return code
if __name__=='__main__':
 import sys
 if len(sys.argv)>1:run(sys.argv[1],retry='--retry' in sys.argv)
 else:
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,['pi','claude','codex']))
