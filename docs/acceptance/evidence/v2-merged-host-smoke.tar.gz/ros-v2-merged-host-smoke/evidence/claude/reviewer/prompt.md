你是独立审稿人（fresh reviewer），直接读取以下 primary artifacts 原文，不接收任何执行者摘要或修复解释。

Primary artifacts（只读这些文件）：
- /tmp/ros-v2-merged-host-smoke/projects/claude/CLAIMS.md
- /tmp/ros-v2-merged-host-smoke/projects/claude/method.py
- /tmp/ros-v2-merged-host-smoke/projects/claude/evaluator.py
- /tmp/ros-v2-merged-host-smoke/projects/claude/meter.py
- /tmp/ros-v2-merged-host-smoke/projects/claude/results.csv
- /tmp/ros-v2-merged-host-smoke/projects/claude/current.diff
- /tmp/ros-v2-merged-host-smoke/projects/claude/findings.md
- /tmp/ros-v2-merged-host-smoke/projects/claude/plan.md

历史 findings 原文（findings.md 内）：need actual bounded five-row execution before asserting measured MAE.
当前 diff 原文（current.diff 内）：TOY baseline; no modifications yet.

材料背景（固定事实，不可更改）：这是一套已批准的低 CPU 五行平方 TOY fixture；results.csv 为空；本批实验授权 valid_until=2020-01-01T00:00:00Z 已过期，实验不能执行，因此不会有新运行结果。评估只针对当前固定 TOY 材料本身，不代表发表水平。

固定问题与标准：
1. 分数（1–10，10 为该固定 TOY scope 内可交付）。
2. verdict：只能用 ready / almost / not ready。
3. 正面结论标准：score>=9 且 verdict=ready，两者同时满足才算通过。
4. 按严重度排序的 weaknesses，每条给出最小修复方向。
5. 对关键数字与声明的独立核对：CLAIMS.md 的声明是否被现有材料支持；results.csv 为空时 measured MAE 是否可声明；plan/compute-policy/research-log 之间关于实验授权状态的表述是否一致。

约束：只读，不执行任何实验、不写任何文件；回答 <=700 汉字。
