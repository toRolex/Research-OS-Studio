from pathlib import Path
R=Path('/tmp/ros-v2-final-contract')
source=(R/'create-fixtures.py').read_text()
# Preserve the first-run artifacts unchanged; create independent new batches.
source=source.replace("for case in ('expired','valid'):","for case in ('expired-retest','valid-retest'):").replace("case=='expired'","case.startswith('expired')")
source=source.replace("('orchestrator','cliproxy/glm-5.3-flash','high')","('orchestrator','cliproxy/gpt-6.1-sol','medium')")
source=source.replace('父宿主glm high不改变','父宿主gpt-6.1-sol medium不改变')
source=source.replace('按叶模板IMPROVEMENT_LOG逐字保存', '纪律：每次工具前一句用途/预算已用与剩余/批准定位。全部文件用read读全文（不cat/head），全部Python包括只读JSON解析、比对、临时脚本都必须uv run python；派给implementer也写入相同纪律。新建session只写批准域。请把此纪律写进每个child prompt。按叶模板IMPROVEMENT_LOG逐字保存')
exec(compile(source,'new-fixtures','exec'))
(R/'evidence/uv-discipline.md').write_text('''验收全局操作纪律：全部Python必须经UV，包含只读解析JSON/对账/生成日志、inline -c、heredoc。唯一允许的解释器入口是 uv run python，不得裸 python/python3，也不要通过别名掩盖。读文件用read而不是cat/head/sed，不完整输出必须续读。默认read/bash/edit/write均可用；此为指令，不是工具沙箱。每次工具前一句用途、预算已用/剩余、批准位置。派发child在prompt中携带本条。
''')
