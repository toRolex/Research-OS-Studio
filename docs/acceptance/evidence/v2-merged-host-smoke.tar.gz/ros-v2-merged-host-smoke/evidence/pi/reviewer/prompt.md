你是fresh独立reviewer。只完整读取以下primary文件，不读取其他材料，不执行代码、job、构建、网络，不写任何文件。工具默认开放，约束靠授权而非工具阉割。全部Python如确需解析只能PYTHONDONTWRITEBYTECODE=1 uv run python；本任务只需read。
Primary路径：
/tmp/ros-v2-merged-host-smoke/projects/pi/CLAIMS.md
/tmp/ros-v2-merged-host-smoke/projects/pi/method.py
/tmp/ros-v2-merged-host-smoke/projects/pi/evaluator.py
/tmp/ros-v2-merged-host-smoke/projects/pi/meter.py
/tmp/ros-v2-merged-host-smoke/projects/pi/results.csv
/tmp/ros-v2-merged-host-smoke/projects/pi/current.diff
/tmp/ros-v2-merged-host-smoke/projects/pi/findings.md
/tmp/ros-v2-merged-host-smoke/projects/pi/plan.md
/tmp/ros-v2-merged-host-smoke/projects/pi/compute-policy.md
/tmp/ros-v2-merged-host-smoke/projects/pi/research-log.md
/tmp/ros-v2-merged-host-smoke/projects/pi/.agents/research-os-models.md
历史findings原文：
Historical input: need actual bounded five-row execution before asserting measured MAE.
当前diff原文：
TOY baseline; no modifications yet.
固定问题：只评固定五行平方TOY材料的一致性、代码与Claims、原始结果与实际执行证据、improvement角色配置及补实验门。核查按plan启动R1-1（预计0USD/0.001cpu-core-hour）的批次许可：valid_until必须绑定，不以loop许可、默认政策、attempt/retry代替。科研文件0写、0修复、0新实验。本轮最多一次审查，不要求修复。不要把静态算术当实测结果，不制造发现。
固定标准：score 1-10，正面须score>=9且verdict=ready；词表ready/almost/not ready。ready仅代表此固定TOY，不代表发表。回答<=700汉字，包含score、verdict、严重度排序weaknesses、每条最小修复方向、关键数字/声明的独立核对，核不动标unverified。只基于原始材料，无父审查摘要或修复解释。