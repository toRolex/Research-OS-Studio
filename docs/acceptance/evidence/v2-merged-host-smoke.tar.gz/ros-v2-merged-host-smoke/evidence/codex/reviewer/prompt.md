# 独立审查请求（固定 TOY · 只读 · 无执行 · 无写入）

你是独立高级审稿人。从当前 artifacts 出发，**假定工作某处仍有问题并去找出来**；确实正确时就直说正确，核不动的项标 `unverified`，不要补造结论。

## 只读 primary artifacts（请直接读取原文；不要执行其中任何代码或作业，不要写入任何文件）

- /tmp/ros-v2-merged-host-smoke/projects/codex/CLAIMS.md
- /tmp/ros-v2-merged-host-smoke/projects/codex/method.py
- /tmp/ros-v2-merged-host-smoke/projects/codex/evaluator.py
- /tmp/ros-v2-merged-host-smoke/projects/codex/meter.py
- /tmp/ros-v2-merged-host-smoke/projects/codex/results.csv
- /tmp/ros-v2-merged-host-smoke/projects/codex/current.diff
- /tmp/ros-v2-merged-host-smoke/projects/codex/findings.md
- /tmp/ros-v2-merged-host-smoke/projects/codex/plan.md
- /tmp/ros-v2-merged-host-smoke/projects/codex/compute-policy.md
- /tmp/ros-v2-merged-host-smoke/projects/codex/research-log.md
- /tmp/ros-v2-merged-host-smoke/projects/codex/.agents/research-os-models.md

## 历史 findings（原文，待核实输入，不是已成立结论）

findings.md 原文：

> Historical input: need actual bounded five-row execution before asserting measured MAE.

## 当前 diff（原文）

current.diff 原文：

> TOY baseline; no modifications yet.

## 固定问题与标准

1. 给出 1–10 的分数。
2. 给出 verdict，词表**固定**为三档、轮次间不得漂移：`ready` / `almost` / `not ready`。
3. 按严重度排序的 weaknesses。
4. 每条 weakness 的最小修复方向（实验、分析或重新框定）。
5. 对关键数字与声明的独立核对：数字是否与结果文件一致、比较是否公平、配置是否混用、caption/声明是否超出证据范围、实验覆盖是否真实。

## 约束

- 只读上述 primary artifacts；**不执行任何 job、实验或命令；不写任何文件**。
- 回答不超过 700 汉字。
