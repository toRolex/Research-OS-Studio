# 合后三宿主轻验因果记录

- 用户禁止改仓库；所有临时脚本、证据、notes仅 /tmp/ros-v2-merged-host-smoke。
- 完整读两份acceptance、旧release run.py与final create/retest fixture脚本；仅复制expired-retest五行平方toy，不搬旧长稿、旧results或旧session作为新行为。
- 当前HEAD1e67d82；全39skill复制扁平宿主项目，逐文件SHA将前后直接和当前源核。
- 三host独立fresh父session，默认工具开放；pi仅隔离extensions/context噪音。子reviewer也默认工具开放，以prompt只读而非工具阉割。
- 项目role表按本次实际父host配置orchestrator，reviewer gpt-6.1-sol medium。Claude用精确glm而不是haiku别名以避免把映射请求当实际模型；真实以session核。
- 本批new身份与confirmation_basis指本轮prompt，expiry保留2020；不把复制旧授权自动续命。prompt实验0新授权只是更保守边界；主要测试真实expired门。
- fresh reviewer最多1/host、120sec；所有证据在项目外唯一批准evidence域；科研项目0写，机械session不误作0全磁盘变化。
- python全UV，保留首运行失败；至多全任务唯一针对性retry。

## Deviations

- pre-implement默认仓库notes路径与用户0仓库改动冲突，notes留/tmp，不写.agents/notes。
- 初探索两个source路径定位失败、一次旧claude不存在read路径失败，非真实host session；如实记此处，未计模型执行。
