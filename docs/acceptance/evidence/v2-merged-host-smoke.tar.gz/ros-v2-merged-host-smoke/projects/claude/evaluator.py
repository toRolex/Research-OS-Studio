# Frozen toy experiment fixture, not Research OS code.
import json, sys
from pathlib import Path
from method import main
mode, out = sys.argv[1:]
if mode == 'fail':
    result = {'toy': True, 'status': 'failed', 'reason': 'intentional diagnostic failure', 'n': 0}
    with Path(out).open('x') as f: json.dump(result, f)
    print(json.dumps(result))
    raise SystemExit(7)
rows = [(x, x*x, main(x)) for x in (-2,-1,0,1,2)]
result = {'toy': True, 'status': 'completed', 'n': 5, 'rows': rows, 'mae': sum(abs(y-p) for x,y,p in rows)/len(rows)}
with Path(out).open('x') as f: json.dump(result, f)
print(json.dumps(result))
