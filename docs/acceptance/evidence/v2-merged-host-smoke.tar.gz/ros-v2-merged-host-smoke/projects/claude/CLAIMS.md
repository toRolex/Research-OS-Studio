# Explicit TOY draft
The method predicts x squared exactly on the five integers -2,-1,0,1,2. New execution evidence is not yet available.
No claim about other datasets or novelty.
