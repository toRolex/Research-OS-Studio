Historical input: need actual bounded five-row execution before asserting measured MAE.
