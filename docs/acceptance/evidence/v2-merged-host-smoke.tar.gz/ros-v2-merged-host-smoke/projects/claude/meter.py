# Explicit toy measurement fixture, not a Research OS runtime.
import subprocess,resource,datetime,json,sys
from pathlib import Path
mode,out=sys.argv[1:]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r0=resource.getrusage(resource.RUSAGE_CHILDREN)
cp=subprocess.run(["uv","run","python","evaluator.py",mode,out],capture_output=True,text=True,env=__import__('os').environ|{'PYTHONDONTWRITEBYTECODE':'1'})
r1=resource.getrusage(resource.RUSAGE_CHILDREN)
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=Path(out)
for suffix,text in [(".stdout",cp.stdout),(".stderr",cp.stderr)]:
 with Path(str(p)+suffix).open("x") as f:f.write(text)
cpu=((r1.ru_utime-r0.ru_utime)+(r1.ru_stime-r0.ru_stime))/3600
m={"toy":True,"command":["uv","run","python","evaluator.py",mode,out],"started_at":start,"finished_at":end,"exit_code":cp.returncode,"cpu_core_hour":cpu,"cost_usd":0,"coverage":"inner uv and all its descendant evaluator processes via RUSAGE_CHILDREN; excludes host orchestrator and meter wrapper explicitly by approval"}
with Path(str(p)+".meter.json").open("x") as f:json.dump(m,f,indent=2)
print(json.dumps(m));raise SystemExit(cp.returncode)
