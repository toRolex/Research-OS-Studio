def main(x): return x*x
