# TOY actual operator authorization, not default policy
- batch_id: merged-smoke-codex
- plan: /tmp/ros-v2-merged-host-smoke/projects/codex/plan.md
- mode: research-improvement experiment-topup
- scope: fixed plan; /tmp/ros-v2-merged-host-smoke/projects/codex; local macOS CPU; output only results/a1.json, results/a2.json plus .stdout/.stderr/.meter.json, CLAIMS.md, IMPROVEMENT_LOG.md, reviews/* prompts/* sessions/* baseline/* current.diff research-log.md evidence/*; no overwrite of experiment results, no code changes
- cost_limit: 0
- currency: USD
- compute_limit: 0.004
- compute_unit: cpu-core-hour
- run_limit: 2
- run_count_basis: attempt
- per_attempt_cost_limit: 0
- per_attempt_compute_limit: 0.001
- concurrency_limit: 1
- retry_limit: 3
- valid_for_hours: 3
- valid_until: 2020-01-01T00:00:00Z
- user_confirmation: operator explicitly confirms inherited expired TOY fixture as this smoke batch; valid_until remains binding, not renewed; 2 nominal attempts confer no permission after expiry
- confirmed_at: 2026-10-03T13:52:44.008831+00:00
- confirmation_basis: /tmp/ros-v2-merged-host-smoke/evidence/codex/prompt.md
- authorization_status: 本批已确认

No attempts started. Actual costs 0; compute 0; running reservations 0; no active jobs. CPU accounting covers inner UV and all evaluator descendants via meter RUSAGE_CHILDREN; excludes host model dialogs and meter wrapper explicitly. Unknown must retain reservation.
