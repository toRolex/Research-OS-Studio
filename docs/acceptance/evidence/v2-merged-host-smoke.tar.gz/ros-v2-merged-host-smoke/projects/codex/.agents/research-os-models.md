# Operator-confirmed project role table for this bounded smoke only
orchestrator: cliproxy/deepseek-v4.1-flash | high
reviewer: cliproxy/gpt-6.1-sol | medium
implementer: cliproxy/glm-5.3-flash | high
analyst: cliproxy/gpt-6.1-sol | medium
writer: cliproxy/glm-5.3-flash | high
prover: cliproxy/gpt-6.1-sol | medium
literature: cliproxy/glm-5.3-flash | high
ideator: cliproxy/glm-5.3-flash | high
