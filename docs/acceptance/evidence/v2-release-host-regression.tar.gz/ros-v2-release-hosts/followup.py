from run import run,R,E,glob,dump
import json,concurrent.futures,shutil

def ident(host,case):
 d=E/case/host
 if host=='pi':return str(d/'session.jsonl')
 for l in (d/'stdout.jsonl').read_text().splitlines():
  try:x=json.loads(l)
  except:continue
  if host=='claude' and x.get('type')=='system' and x.get('session_id'):return x['session_id']
  if host=='codex' and x.get('type')=='thread.started':return x['thread_id']
 raise RuntimeError(host)
def one(host):
 sid=ident(host,'experiment-plan')
 run(host,'sticky','继续上面的实验计划任务，不是new task，只补待提供材料清单，预算仍未知、无写域，不改到bridge，不启动。保持原路线原步骤。',resume=sid)
 run(host,'new-task','new task 我该从哪开始？现在已有TOY审稿意见fixtures/toy-reviews.md及fixtures/false-proof.md，未来想回复审稿，但当前只要推荐不要执行。旧任务状态不整理，不调用任务工具，route-only。',resume=sid)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(one,['pi','claude','codex']))
# Separate current-tip installed toy with actual old setup state, never concurrent with other projects.
p=R/'setup-rerun-project';shutil.copytree(R/'projects/pi',p,dirs_exist_ok=True)
old=R/'projects/pi/fixtures/setup-old'
for f in ['AGENTS.md','.agents/research-os-models.md']:
 (p/f).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/f,p/f)
shutil.copytree(old/'research',p/'research',dirs_exist_ok=True)
run('pi','setup-rerun','setup-research-os 重跑刚完成真实旧79轮toy的项目配置，当前root已有AGENTS/.agents/research-os-models.md/research完整7件。请真实Explore、当前清单，沿用八角色 cliproxy/glm-5.3-flash | off、当前研究工作区和日志；未再次批准写域，只展示拟变更/一致性，已一致则零写。不得用旧目录清单冒充本轮可用性。',project=p)
run('pi','route-full-default','research-os 我该从哪开始？只有方向，未来写ML论文并跑实验。现在只要推荐不要执行，route-only。',full=True)
dump(E/'global-after-followup.json',glob())
