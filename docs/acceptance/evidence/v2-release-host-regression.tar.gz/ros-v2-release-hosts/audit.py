from pathlib import Path
import json,re,hashlib
R=Path('/tmp/ros-v2-release-hosts');E=R/'evidence'
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
index=[]
for out in sorted(E.glob('*/*/result.json')):
 d=out.parent; host=d.name; case=d.parent.name; texts=[]; tools=[]; ended=False; models=[]
 for n,line in enumerate((d/'stdout.jsonl').read_text().splitlines(),1):
  try:x=json.loads(line)
  except:continue
  if host=='pi':
   if x.get('type')=='agent_end':ended=True
   if x.get('type')=='message_end':
    m=x.get('message',{});models.append({k:m[k] for k in ['provider','model','stopReason'] if k in m})
    if m.get('role')=='assistant':
     for c in m.get('content',[]):
      if c.get('type')=='text':texts.append(c.get('text',''))
      elif c.get('type')=='toolCall':tools.append({'line':n,'name':c.get('name'),'arguments':c.get('arguments')})
  elif host=='claude':
   if x.get('type')=='result':ended=True
   if x.get('type')=='assistant':
    m=x.get('message',{});models.append({'model':m.get('model')})
    for c in m.get('content',[]):
     if c.get('type')=='text':texts.append(c.get('text',''))
     elif c.get('type')=='tool_use':tools.append({'line':n,'name':c.get('name'),'arguments':c.get('input')})
  else:
   if x.get('type')=='turn.completed':ended=True
   if x.get('type')=='item.completed':
    m=x.get('item',{});t=m.get('type')
    if t=='agent_message':texts.append(m.get('text',''))
    elif t in ['command_execution','mcp_tool_call','file_change','collab_tool_call']:tools.append({'line':n,'name':t,'arguments':m})
 text='\n\n'.join(texts);(d/'assistant.md').write_text(text);dump(d/'tools.json',tools)
 def normalize(t):return re.sub(r'\[(?:completed|in-progress|pending|blocked)\]\s*','',t.replace('**',''))
 norm=normalize(text)
 before=json.loads((d/'before.json').read_text());after=json.loads((d/'after.json').read_text());changed=[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]
 pbcase={'artifact-check':'paper-writing-ml','reversible':'custom','mismatch':'paper-writing-general','sticky':'experiment-plan','new-task':'route-only','route-only-retry':'route-only','route-full-default':'route-only','new-task-retry':'route-only','new-task-command-retry':'route-only','ambiguity':'custom','pickup-retry':'pickup','mismatch-snapshot-retry':'paper-writing-general','experiment-plan-checklist-retry':'experiment-plan'}.get(case,case)
 pb=R/'source/skills/general/research-os/playbooks'/f'{pbcase}.md'; verbatim=[]
 if pb.exists():
  body=pb.read_text();section=body.split('## 步骤\n',1)[-1].split('\n## ',1)[0]
  for line in section.splitlines():
   if re.match(r'^(\d+\. |   - )',line):verbatim.append({'line':line,'present_exact':line in norm})
 checklist_blocks=[t for t in texts if verbatim and verbatim[0]['line'] in normalize(t)]
 first_checklist=next(iter(checklist_blocks),'')
 first_complete=bool(verbatim) and all(v['line'] in normalize(first_checklist) for v in verbatim)
 any_block_complete=bool(verbatim) and any(all(v['line'] in normalize(t) for v in verbatim) for t in checklist_blocks)
 result=json.loads(out.read_text());record={'host':host,'case':case,'result':result,'ended':ended,'models':models,'tool_count':len(tools),'tool_names':sorted({t['name'] for t in tools}),'changed':changed,'global_unchanged':(d/'global-before.json').read_text()==(d/'global-after.json').read_text(),'verbatim':verbatim,'all_verbatim':bool(verbatim) and all(v['present_exact'] for v in verbatim),'first_checklist_complete':first_complete,'single_checklist_block_complete':any_block_complete,'trace':str((d/'stdout.jsonl').relative_to(R))}
 dump(d/'audit.json',record);index.append(record)
dump(E/'trace-index.json',index)
for r in index:print(r['host'],r['case'],r['result']['exit'],r['ended'],r['tool_count'],r['all_verbatim'],'changes',len(r['changed']))
