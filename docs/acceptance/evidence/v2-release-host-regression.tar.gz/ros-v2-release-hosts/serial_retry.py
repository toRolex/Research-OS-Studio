from run import run,texts
run('codex','experiment-plan-checklist-retry',texts['experiment-plan']+' 针对已有入口完成条件唯一重跑：首次对话todolist必须一次完整逐字保留该playbook所有步骤编号、原句、子列表；不是把原句分散多个消息最后substring拼齐，不用压缩摘要。请真实读原playbook再亲自逐項对照。安装tip由验收侧hash已核，不需反复git/probe或读所有无关fixture；本轮只读规划、叶和适用模板，零新实验零文件写。')
