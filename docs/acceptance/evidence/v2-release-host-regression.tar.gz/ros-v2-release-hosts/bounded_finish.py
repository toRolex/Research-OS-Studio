from run import run,texts
import concurrent.futures
jobs=[('pickup-retry','research-os 新会话续接，实际fixtures/pickup-expired/round-1/五件套+compute-policy.md/research-log.md是旧真实交接，只读当前next n=0义务。本批valid_until=2020已过期，消费五件与政策日志和安装pickup/proof四叶及适用resources后核实时钟，停止不写round2、不续命。安装tip已由验收侧逐文件hash验证，无需反复git/probe，也不要完整重解析旧raw长审查：它们属于已固定旧证据，非本次新fresh；不能冒充新review。只做门组合当前代表，300秒有界。'),('mismatch-snapshot-retry',texts['mismatch']+' 本次只补单独无其他写会话的前后快照。原路由和无伪造证据保留，无需反复git自证。')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(lambda x:run('pi',*x),jobs))
