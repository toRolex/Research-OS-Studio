from pathlib import Path
import json,tarfile,hashlib,re,os
R=Path('/tmp/ros-v2-release-hosts');E=R/'evidence';repo=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.integration-research-os-v2');A=R/'archive'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for p in E.rglob('*'):
 if p.is_file():files[str(p.relative_to(R))]=p
for p in R.glob('*.py'):files[p.name]=p
# One current installed tree is byte-identical across all three, each host manifest retained.
for p in (R/'projects/pi/.pi/skills').rglob('*'):
 if p.is_file():files[str(p.relative_to(R))]=p
# Minimal original primary fixtures, all large old assets accessible in immutable inherited archive.
for p in (R/'projects/pi/fixtures').rglob('*'):
 if p.is_file() and p.suffix in ['.md','.csv','.py','.txt'] and p.stat().st_size<100000 and '.git' not in p.parts and not any(x in p.parts for x in ['ml-final','proof','pickup-expired','talk']):files[str(p.relative_to(R))]=p
for p in [R/'projects/pi/outputs/inventory.md']:
 if p.exists():files[str(p.relative_to(R))]=p
patterns={'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','github_token':r'(?:ghp_|github_pat_)[A-Za-z0-9_]{20,}','api_secret':r'\bsk-[A-Za-z0-9_-]{24,}','aws_access':r'\bAKIA[A-Z0-9]{16}\b','bearer_value':r'Bearer\s+[A-Za-z0-9._~+/-]{20,}','url_credentials':r'https?://[^\s/"<>]+:[^\s/@"<>]+@'}
findings=[]
for rel,p in files.items():
 try:s=p.read_text()
 except:continue
 for kind,pat in patterns.items():
  for m in re.finditer(pat,s):findings.append({'file':rel,'kind':kind,'line':s[:m.start()].count('\n')+1})
(E/'sensitive-scan.json').write_text(json.dumps({'scan_scope':'new archive exact selected files; candidates only no secret values','candidate_count':len(findings),'candidates':findings},indent=2));files['evidence/sensitive-scan.json']=E/'sensitive-scan.json'
if findings:raise SystemExit('sensitive candidates require manual review')
m={rel:{'sha256':sha(p),'bytes':p.stat().st_size} for rel,p in files.items()};(E/'SHA256SUMS.json').write_text(json.dumps(m,indent=2));files['evidence/SHA256SUMS.json']=E/'SHA256SUMS.json'
output=repo/'docs/acceptance/evidence/v2-release-host-regression.tar.gz'
with tarfile.open(output,'w:gz') as tar:
 for rel,p in sorted(files.items()):tar.add(p,arcname='ros-v2-release-hosts/'+rel,recursive=False)
print(json.dumps({'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size,'files':len(files)},indent=2))
with tarfile.open(output,'r:gz') as tar:
 errors=[]
 for rel,v in m.items():
  d=tar.extractfile('ros-v2-release-hosts/'+rel).read()
  if hashlib.sha256(d).hexdigest()!=v['sha256']:errors.append(rel)
print('verified archive mismatches',len(errors))
