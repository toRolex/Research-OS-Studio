from pathlib import Path
import json,re
E=Path('/tmp/ros-v2-release-hosts/evidence')
for p in sorted(E.glob('*/*/audit.json')):
 x=json.loads(p.read_text());print('\n',x['case'],x['host'])
 ts=json.loads((p.parent/'tools.json').read_text());s=(p.parent/'assistant.md').read_text()
 for t in ts:
  a=t['arguments'];cmd=a.get('command') if a else None
  if cmd: print('CMD',t['line'],cmd)
 print('END',s[-1800:])
