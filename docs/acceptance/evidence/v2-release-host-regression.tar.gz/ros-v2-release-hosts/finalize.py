from pathlib import Path
import json,hashlib,subprocess,shutil,re
R=Path('/tmp/ros-v2-release-hosts');E=R/'evidence';repo=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.integration-research-os-v2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
manifest=json.loads((E/'installation-manifest.json').read_text());rows=[]
for h,ls in manifest.items():
 for item in ls:
  if 'installed' not in item:continue
  p=R/'projects'/h/item['installed'];src=repo/item['source'];rows.append({'host':h,'path':item['installed'],'before_sha256':item['installed_sha256'],'after_sha256':sha(p),'current_repo_sha256':sha(src),'equal':item['installed_sha256']==sha(p)==sha(src)})
dump(E/'installed-current-tip-final-hashes.json',rows)
# Claude full persistent sessions, matching actual host init session UUID only.
cs=E/'host-sessions';cs.mkdir(exist_ok=True);copied=[];seen=set()
for p in E.glob('*/claude/stdout.jsonl'):
 for line in p.read_text().splitlines():
  try:x=json.loads(line)
  except:continue
  if x.get('type')=='system' and x.get('session_id'):
   sid=x['session_id']
   if sid in seen:continue
   seen.add(sid)
   for s in (Path.home()/'.claude/projects').glob(f'*/{sid}.jsonl'):
    t=cs/f'{sid}.jsonl';shutil.copy2(s,t);copied.append({'session_id':sid,'path':str(t.relative_to(R)),'sha256':sha(t)})
dump(E/'claude-session-index.json',copied)
# Cite old immutable archives without copying 100MiB.
old=[]
for p in sorted((repo/'docs/acceptance/evidence').glob('v2-accept-*.tar.gz')):old.append({'path':str(p.relative_to(repo)),'sha256':sha(p),'bytes':p.stat().st_size})
dump(E/'inherited-archives.json',old)
shutil.copy2('/tmp/ros-v2-release-issues/46.json',E/'input-46.json');shutil.copy2('/tmp/ros-v2-release-issues/37.json',E/'input-37.json');shutil.copy2('/tmp/research-os-v2-notes/shared-contract-approved.md',E/'input-approved.md')
# Freeze all project files including install roots/config; .git is not evidence.
for h in ['pi','claude','codex']:
 p=R/'projects'/h;dump(E/f'{h}-final-allfiles.json',{str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file() and '.git' not in f.parts})
# Administrative global invariant including mtime.
g=Path.home()/'.agents/pstack-models.md';dump(E/'global-final.json',{'sha256':sha(g),'mtime_ns':g.stat().st_mtime_ns})
print('installed mismatches',sum(not x['equal'] for x in rows),'files',len(rows),'claude sessions',len(copied))
