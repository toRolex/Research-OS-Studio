from run import run
import concurrent.futures
p='research-os 我该从哪开始？以后想写ML论文并跑实验，现在只有方向且只要推荐不要执行。这是一次针对入口既有完成条件的独立重跑：请遵守当前route-only原文，不把步骤压缩，不把未读/截断/读命令错误说成已读全文；先实核正确路径，按首选的关键行为读对应安装SKILL完整内容并检查工具返回。不要一次shell拼错三个叶造成假覆盖，不请求额外网络/fresh预算。'
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda h:run(h,'route-only-retry',p),['claude','codex']))
