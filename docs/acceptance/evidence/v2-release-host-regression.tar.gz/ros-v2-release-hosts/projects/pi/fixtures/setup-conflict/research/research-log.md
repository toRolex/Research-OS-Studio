# Existing toy research log

fixture baseline bytes; no real experiments; unknown costs stay unknown.
