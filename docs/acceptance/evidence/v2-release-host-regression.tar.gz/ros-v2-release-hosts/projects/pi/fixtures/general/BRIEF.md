# Explicit TOY fixture: general
Toy numerical-method diagnostic: compare naive summation with existing Python math.fsum on explicit cancellation sequences; no novelty claim and no general accuracy guarantee. Framing confirmed: a reproducible toy numerical diagnostic documenting the measured cancellation errors in three fixed sequences.
Raw inputs: results.csv, fixture_source.py, ENVIRONMENT.txt in this directory. These are executed synthetic/toy materials, not real-world research or fake paper data. No venue specified, venue-neutral article template only. Source materials remain read-only.
