# INTERNAL TOY review, not external peer review
Paper claim: for all real x, x²>0.
Concern: x=0 refutes the strict inequality.
