# Explicit TOY, not an external paper
Fixed proposition: for every real x, x²>0.
Author argument: x²≥0, hence x²>0.
