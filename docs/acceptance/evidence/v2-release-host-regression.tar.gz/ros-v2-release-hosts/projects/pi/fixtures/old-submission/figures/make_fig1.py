#!/usr/bin/env python3
"""Generate Figure 1 data for the toy numerical diagnostic (general fixture).

Reads the raw fixture results (READ-ONLY input) and writes the PGFPlots data
table used by fig1_errors.tex. No computation beyond verbatim transcription of
the recorded columns; all six error values are transcribed as-is.

Usage: uv run --no-project python make_fig1.py
Input:  /tmp/ros-v2-deliverables/project/fixtures/general/results.csv  (read-only)
Output: fig1_data.dat  (columns: n, sum_err, fsum_err)
"""
import csv
from pathlib import Path

SRC = Path("/tmp/ros-v2-deliverables/project/fixtures/general/results.csv")
OUT = Path(__file__).resolve().parent / "fig1_data.dat"

rows = list(csv.DictReader(SRC.open()))
assert len(rows) == 3, f"expected 3 fixture rows, got {len(rows)}"

lines = ["n sum_err fsum_err"]
for r in rows:
    # verbatim transcription: columns naive_abs_error / fsum_abs_error
    lines.append(f"{r['small_terms']} {r['naive_abs_error']} {r['fsum_abs_error']}")
OUT.write_text("\n".join(lines) + "\n")
print(f"wrote {OUT} with {len(rows)} data rows")
print("\n".join(lines))
