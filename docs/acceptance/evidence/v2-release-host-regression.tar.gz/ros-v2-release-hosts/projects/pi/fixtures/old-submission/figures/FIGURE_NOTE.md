# 图表说明（figure note）— Fig 1 与 Table 1

## 范围
- 模式：composed（paper-writing/general）；图 1 幅 + 表 1 张；写入 `papers/general/`。
- 读取材料：`fixtures/general/results.csv`、`fixture_source.py`、`ENVIRONMENT.txt`；输出 `figures/`。
- 类型：实测数据图（零值退化）+ 比较表；无示意图。

## 来源与对应
- 数据：`fixtures/general/results.csv` 行 2–4（只读）。列映射：`small_terms`→x 轴 n；`naive_abs_error`→built-in `sum()` 系列；`fsum_abs_error`→`math.fsum` 系列；`exact`→参考值 n（仅 Table 1）。
- 单位：小项计数（unitless counts）；确定性单次运行，无重复试验、无 n>1。
- 变换：零（make_fig1.py 仅逐字转抄三行两列误差值；断言 3 行）。总行数 3，采用 3，排除 0。
- 方法身份：`fixture_source.py` line 11 `sum(vals)` / `math.fsum(vals)`；CSV 表头 `naive` 仅为列名，Table 1 脚注说明映射。

## 产物与复现
- `figures/make_fig1.py`（数据转抄脚本，uv run --no-project python make_fig1.py，退出码 0）→ `figures/fig1_data.dat`。
- `figures/fig1_errors.tex`（可编辑 PGFPlots 图源；渲染发生在主稿 pdflatex 编译内，TeX Live 2026 pgfplots/booktabs 经 kpsewhich 确认存在，无安装）。
- Table 1：主稿内 booktabs tabular，数值逐字取自 results.csv。

## 图注（主稿内最终版见 fig1_errors.tex / paper.tex）
自包含：序列定义、记录环境 Python 3.14.4、六个误差全为精确 0.0、0–1 轴仅为显示范围非观测界、toy 边界声明。

## 检查与停止
- 数据对应：make_fig1.py 输出与 results.csv 行 2–4 逐值核对一致（上方运行输出可见）。
- 实际执行：数据生成成功；渲染待主稿编译（未单独占编译预算），结果在编译步骤记录。
- 导出图目检：待主稿 PDF 生成后执行（pdftotext/渲染检查），未目检前不标注完成。
- 审查：仅作者自查；独立审查由后续 audit fresh 覆盖。
- 停止：图表候选完成（渲染+目检项挂起至编译步骤）。
