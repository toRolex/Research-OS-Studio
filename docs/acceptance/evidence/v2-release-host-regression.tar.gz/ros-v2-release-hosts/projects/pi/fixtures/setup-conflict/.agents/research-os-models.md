# 项目级 Research OS 角色表（integer-sum-toy，仅本项目生效）
# 全部角色经用户逐个确认，来源为本 session `pi --list-models` 清单。

orchestrator: cliproxy/glm-5.3-flash | off
literature: cliproxy/glm-5.3-flash | off
ideator: cliproxy/glm-5.3-flash | off
implementer: cliproxy/glm-5.3-flash | off
analyst: cliproxy/glm-5.3-flash | off
prover: cliproxy/glm-5.3-flash | off
writer: cliproxy/glm-5.3-flash | off
reviewer: cliproxy/glm-5.3-flash | off
