本轮保持“写作”目标，不把它改成证明任务，也不伪造 ML 材料。先只读触发的 ML 写作 playbook 并核实安装路径；不创建任务文件、不联网、不运行实验或编译。

本次工具范围：本地读取与路径核验。剩余预算：主会话限 300 秒；fresh / build / GET / 新实验均为 0，未获写域授权。


当前进入 **paper-writing / ml 的材料适用性核验**；它是否适用，取决于实际材料，而不只取决于“机器学习论文”这个标签。

以下逐字保留 playbook 的步骤、编号及子列表，仅附状态。首次已逐项对照原文，无遗漏：

1. 读 `skills/writing-cycle/ml-paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。补实验不在本次授权内。
   - 状态：in-progress；证据：已读取 `research-os/playbooks/paper-writing-ml.md`，下一动作读取叶正文。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/ml-paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。
   - 状态：pending。
3. ML 专属纪律读全文：
   - `skills/writing-cycle/ml-paper-writing/references/experiment-reporting.md`
   - `skills/writing-cycle/ml-paper-writing/references/reviewer-expectations.md`
   - 用户指定 venue 时读 `skills/writing-cycle/ml-paper-writing/references/venue-checklists.md`
   - 状态：pending。
4. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`
   - 状态：pending。
5. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。
   - 状态：pending。

本次工具范围：核实扁平安装的叶文件与 fixture 的实际位置，然后只读叶全文。剩余预算：仍仅本轮主会话 300 秒总上限内；fresh / build / GET / 新实验为 0，无写域授权。


已核实：`ml-paper-writing`、通用 `paper-writing` 叶及 `fixtures/false-proof.md` 均实际存在，安装是扁平布局。

本次工具范围：只读 ML 叶全文和原始 fixture，判断材料适用性；不作证明或独立审查。剩余预算：本轮 300 秒总上限内；fresh / build / GET / 新实验均 0，写入未授权。


材料已核实为 **显式 TOY 的普通数学材料**：只有固定命题和作者论证，没有 ML 研究材料。因而 ML 变体不适用；不会把训练、seeds、CSV 或结果补造出来。

这是依据你明确要求“在实际材料适用的写作叶授权门停”所作的写作变体纠正，**不是切换到 proof，也不是认定写作完成**。ML 清单第 1 项标 `blocked`（输入不适用、授权未确认），第 2–5 项保持 `pending`，不继续执行 ML 工作流。

本次工具范围：只读通用写作 playbook 全文，确定实际适用路线的清单。剩余预算：本轮 300 秒总上限内；fresh / build / GET / 新实验为 0，无写域授权。


当前路线纠正为 **paper-writing / general**，目标仍为写作。以下清单逐字保留原文；首次已逐项对照 playbook，编号、原句与子列表无遗漏：

1. 读 `skills/writing-cycle/paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。
   - 状态：in-progress；证据：`research-os/playbooks/paper-writing-general.md`；原材料 `fixtures/false-proof.md`。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。
   - 状态：pending。
3. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`
   - 状态：pending。
4. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。
   - 状态：pending。

本次工具范围：只读实际适用的 `paper-writing/SKILL.md` 全文，不启动下游能力。剩余预算：本轮 300 秒总上限内；fresh / build / GET / 新实验均 0，无写域授权。


已到达实际适用写作叶的授权门：`paper-writing/SKILL.md#1-授权门`。尚无写域、稿件格式、语言、输出位置等确认，不会进入规划、起草或审查。

本次最后的工具范围：只读叶正文点名的 `references/composition-map.md`，核实组合及审查边界；不执行其中能力。剩余预算：本轮 300 秒总上限内；fresh / build / GET / 新实验均 0，写入未授权。读取后在授权门停止。


**已按要求停在实际适用的写作叶授权门，未把证明路线当作写作完成。**

### 路线与材料核验
- **当前路线：`paper-writing / general`**。执行目标仍是写作。
- `fixtures/false-proof.md` 全文明确标为 **TOY**，内容只有普通数学命题与作者论证，不是 ML 实验材料。
- 未伪造模型训练、seeds、CSV 或实验结果，也未将原论证当成已验证结论。
- 已实际读取 ML 与 general 两份触发 playbook、对应写作叶全文，以及 general 的 `references/composition-map.md`；所用文件实际存在，无已发现的路径缺口。

### 授权门核对
停止位置：`.pi/skills/paper-writing/SKILL.md#1-授权门`  
门类型：`workflow-authorization`，`before=draft-write`。

| 项目 | 当前状态 |
|---|---|
| 输入范围 | 仅已读的 `fixtures/false-proof.md`，原材料只读 |
| venue、页数、模板 | 未指定，不设默认值 |
| 稿件语言、格式、输出位置、构建入口 | 未确认 |
| 交付口径 | 尚未批准；未宣称已交付 `draft` 或 `submission-candidate` |
| 允许写域 | 未批准；只在对话输出 |
| 修订轮数与资源 | 未确认，不套用默认两轮 |
| 独立 reviewer | fresh 预算为 0，未执行 |
| style-ref | 未指定、未读取 |
| 外部服务及付费调用 | 未授权，未执行 |

### 对话 todolist 状态更新
先前逐字清单继续保留：
- **ML 清单**：第 1 项 `blocked`（材料不适用、授权未确认）；第 2–5 项 `pending`，停止继续执行。
- **general 清单**：
  - 第 1 项 `blocked`：叶全文已读，但授权门未通过，不能标完成。
  - 第 2 项 `completed`：composition map 全文已读，仅核实组合边界，未执行能力。
  - 第 3、4 项 `pending`：未级联下游叶、未交付稿件或审查报告。

**本轮未写任何文件，未联网、外发、安装、运行新实验、编译、删除或覆盖；未启动 proof，也未作 fresh review。** 原文读取和当前适用性判断不冒充新独立审查。按本轮验收要求在门处停止，不重新长跑科研流程。