开始前先声明本动作范围与剩余预算：

- **动作范围（本次工具调用）**：只读已安装原 tip 的入口 `SKILL.md`、命中路线 playbook、该 playbook 点名的叶子与当前适用模板/参考；核对路径是否真实存在。**不做**：BEGIN 新实验、编译、联网、外发、安装、git 操作、probe、写任何文件、改全局/main/原项目。
- **预算**：模型对话本轮一次主会话，300 秒；fresh/build/GET/新实验预算均为 0。安装 tip 的 hash 由验收侧负责，本轮不复核，不反复 git/probe，不读无关 fixture。
- **约束**：读取触发 playbook 全文后，把其步骤编号/原句/子列表**一次性完整逐字**作为对话 todolist 展示，只附状态/证据；未批准写域时只在对话输出，不建任务文件；无 subagent 工具则自然串行读取叶与模板，不缩减叶合同。

先确认实际安装根与命中路线文件是否存在。

路径已核实：安装根 `.../.agents/skills` 存在，`research-os/playbooks/experiment-plan.md` 与 `research-os/references/` 真实存在。

按「设计实验、写实验计划」触发词，命中路线 = **experiment-plan**（只读约束 no，但用户明确只读+无写域）。现在读该 playbook 全文，以及它点名的资源与对应叶子全文。

入口与 `experiment-plan.md` 全文已读。步骤 1 点名叶子 `skills/validation-cycle/experiment-plan/SKILL.md`：扁平安装映射为 `<安装根>/experiment-plan/SKILL.md`。现在读该叶全文及其点名的 references/templates，并读 `references/batch-authorization.md`。

叶子全文已读。它点名 `references/block-checks.md` 与 `templates/experiment-plan.md`；playbook 步骤 3 点名 `references/batch-authorization.md`。现在读这三份适用资源全文。

叶子点名的资源已读完。再补读入口级联明确要求「要读全文」的 `references/PRODUCT-MAP.md`，并轻量核实工作区是否存在角色表/算力政策/研究日志（与步骤 3、4 直接相关，不扩散到无关 fixture）。

工作区无 `compute-policy.md`、无 `research-log.md`、无 `.agents/research-os-models.md`（步骤 3/4 与模型表相关缺口）。存在 `fixtures/`，仅列目录名判断是否有 TOY 原材料，不读无关 fixture。

`fixtures/toy-reviews.md` 与任务「TOY」直接相关，读它（128 字节）；`false-proof.md` 与本任务无关，跳过。其余上游交付 fixture（general/ml/systems/talk 等）本轮不读。

已完成本轮全部只读动作。下面是**一次性完整**的对话 todolist（逐字保留 playbook 及步骤 1 内嵌的叶合同，只附状态/证据），随后是经叶流程得到的 TOY 待确认计划。

---

## 0. 路线与实核

- **当前路线：experiment-plan**（触发词「设计实验」；已有研究问题，要的是有界计划而非开跑）。只读约束：本批由用户显式限定为只读、零写域。
- **宿主映射：Codex，无 `spawn_agent`** → 按入口「无该工具时由编排者串行执行」，本轮由编排者串行读取叶与模板，不缩减叶合同。
- **路径实核（真实存在）**：安装根 `/tmp/ros-v2-release-hosts/projects/codex/.agents/skills`；`research-os/SKILL.md`、`research-os/playbooks/experiment-plan.md`、`research-os/references/batch-authorization.md`、`experiment-plan/SKILL.md`、`experiment-plan/references/block-checks.md`、`experiment-plan/templates/experiment-plan.md` 均实读。
- **模型表缺口**：工作区**无** `.agents/research-os-models.md` → 回退到当前 session 实际可用模型，**明示回退，不编造 slug**。同上下文自审不等于 fresh 独立审查。

---

## 1. Todolist（触发 playbook `playbooks/experiment-plan.md` 逐字）

> 原文（`# experiment-plan` 及 `## 适用`）：

用户要把已有研究问题收成有界实验计划。本路线只规划，不跑实验。

**## 适用**

已有问题、Proposal 或稳定方法，用户要的是计划而不是执行。材料只够写计划时走这里；用户要的是「跑完并分析」时回到入口重匹配 experiment-bridge。

> 原文（`## 步骤`，步骤编号/原句/子列表逐字）：

1. 读 `skills/validation-cycle/experiment-plan/SKILL.md` 全文，并读它点名的 references 与 templates。计划内容、阶段和产出以该正文为准。不在这里重写科研流程。
2. 只读本次相关材料。未知项标缺口，不补预算数字。
3. 计划达到「可供执行授权」前，按 [批次授权](../references/batch-authorization.md) 列出本批字段，请用户确认。确认的是这一批，不是工作区默认 `compute-policy.md`。
4. 用户确认本批后，把确认原文、时刻和全部字段写入工作区 `research-log.md` 的新段落。authorization_status 写「本批已确认」。默认政策额度保持 0，不抄进这条授权。
5. 只把计划和 tracker 写到用户允许的路径。已有计划文件先展示差异。删除或覆盖既有实验结果时停，等另一次明确批准。
6. 交付计划后停止。本路线不启动实验，不把本批确认交给 bridge 自动开跑。

> 原文（`## 停止`）：

计划未达到可授权时，交付标了缺口的草稿并停止，研究日志不写运行许可。用户拒绝本批确认时，保留已有材料，不写 authorization_status。

**状态/证据**
1. `completed` | 证据：`experiment-plan/SKILL.md` 全文已读；其点名的 `experiment-plan/references/block-checks.md`、`experiment-plan/templates/experiment-plan.md` 全文已读。
2. `completed` | 证据：只读用户 prompt（TOY 任务）；目录核实工作区无 `compute-policy.md`、无 `research-log.md`；无数据/无 evaluator。未知项全部标缺口，未补任何预算数字。
3. `blocked`（计划为 BLOCKED 草稿，未达「可供执行授权」）| 证据：`research-os/references/batch-authorization.md` 全文已读；本批字段在下方 §4 全部列为待确认/未知。
4. `blocked`（待用户先确认本批 + 无写域批准）| 证据：本批零文件写，未创建/未改动 `research-log.md`。
5. `completed`（对话草稿，未落盘）| 证据：无写域批准，无既有计划文件，不创建 `EXPERIMENT_PLAN.md`/`EXPERIMENT_TRACKER.md`。
6. `completed` | 证据：本消息交付后即停，不启动实验、不交 bridge。

### 步骤 1 内嵌的叶合同（`experiment-plan/SKILL.md` Workflow，逐字，不缩减）

**完成条件的两条分支**：下列每阶段的要求逐项满足，或逐项标为缺口并注明受影响 block、所需材料及待决策人。存在关键缺口时，以 **BLOCKED 草稿**完成规划，后续字段只填可确定部分；预算未知就保留未知，不为了满足“完整”而编造数值。只有全部关键项确定、彼此一致且必须实验符合硬上限时，才能标为“可供执行授权”。两者均不表示已授权执行。

**### Phase 0: Load the Proposal Context**

Read the relevant user-supplied proposal, review summary and refinement report if present. Locate them through the project's existing navigation, not a required directory layout. Without these files, derive the same information from the user's prompt:

- **Problem Anchor** and hypothesis: mechanism, expected direction and conditions under which it could be falsified
- **Dominant contribution**, optional supporting contribution
- **Critical reviewer concerns**
- **Data / compute / timeline constraints** and existing environment capabilities
- **Which frontier primitive is central, if any**

Distinguish observed project facts, user-provided constraints and proposed assumptions. Missing tools, unavailable data, uncertain dataset rights or unknown evaluator behavior are gaps, not facts to invent. Ask only the decisions needed to make the plan determinate; otherwise mark the affected blocks blocked.

**完成条件**：研究问题、输入来源、约束与缺口逐项列明；每个假设可识别为已给定或待确认。

**### Phase 1: Freeze the Claims and Evaluation Surface**

Before proposing experiments, write:

- **Primary claim**: the main mechanism-level contribution
- **Supporting claim**: optional, only if it directly strengthens the main story
- **Anti-claim to rule out**: e.g. gains only from more parameters, a larger search space, or a decorative modern component
- **Minimum convincing evidence**: what would make each claim believable to a strong reviewer?

Keep within MAX_PRIMARY_CLAIMS unless multiple claims are inseparable. Specify the falsifying observation as well as the expected improvement.

Define two disjoint boundaries for future execution:

1. **Candidate scope** — exact existing files or proposed implementation locations and permitted components/hyperparameter ranges. Label proposed paths as not yet created. Include allowed output locations; a broad project directory is not a substitute for a specific edit scope.
2. **Fixed evaluation surface** — dataset version and split, ground-truth source, preprocessing, evaluation code/protocol, metric formula/direction/units/aggregation, selection rule, seeds or pairing, and comparison budget. Candidate code may produce predictions, not redefine labels, evaluator, denominator or success threshold. Hidden tests remain with their owner; request a public protocol rather than reading private answers. If there is no ground truth, name the justified alternative (e.g. blinded human rubric), its limitations and required authorization.

Before calling the plan ready for execution authorization, bind the actual project location, data/protocol identifiers, existing way to set each seed or run parameter within candidate scope, and proposed evidence destinations. Unavailable bindings are blockers, not invented executable commands.

Where the project lacks actual access separation, say that this is a planned responsibility boundary, not enforced isolation. Evaluator defects require stopping the affected comparison and user approval of a new protocol; all systems must be re-evaluated under that protocol, retaining old results as non-comparable.

**完成条件**：每个 Claim 有支持和反驳条件；候选可改范围与固定评价面不重叠，缺失项阻止该计划被称为可执行。

**### Phase 2: Build the Experimental Storyline**

Use a compact set of blocks (within MAX_CORE_BLOCKS); delete those not needed:

1. **Main anchor result** — does the method solve the actual bottleneck?
2. **Novelty isolation** — does the dominant contribution itself matter?
3. **Simplicity / elegance check** — can a bigger or more fragmented version be avoided?
4. **Frontier necessity check** — if an LLM / VLM / Diffusion / RL-era component is central, is it the right tool?
5. **Failure analysis or qualitative diagnosis** — what does the method still miss?

For each block choose **Main paper** (essential), **Appendix** (non-blocking) or **Cut** (not worth the budget). Without a paper target, use core evidence / supplementary evidence / cut with the same meaning. Prefer one strong baseline family over many weak baselines (within MAX_BASELINE_FAMILIES). If a stronger modern baseline exists, use it rather than padding the list; mark an unverified baseline claim as such.

Make the **discriminating experiment** explicit: list competing explanations and their different predictions. Prefer the cheapest comparison that can change the decision. Match data, tuning opportunity and compute as appropriate; if budgets differ, separate the efficiency and unconstrained-quality claims. A comparison that cannot distinguish the explanations cannot establish the mechanism.

**完成条件**：每个保留 block 指向 Claim、竞争解释与可区分的观察；主证据、补充证据和删去项及理由齐全。

**### Phase 3: Specify Each Experiment Block**

For every kept block, fully specify:

- **Claim tested** and **why this block exists**
- **Dataset / split / task**
- **Compared systems**: strongest baselines, ablations and variants only
- **Metrics**: decisive metric first, secondary metrics second
- **Setup details**: backbone, frozen vs trainable parts, key hyperparameters, training budget, seeds
- **Success criterion**: pre-specified effect size and uncertainty requirement, not merely the best point estimate
- **Failure interpretation**: what a negative result means and what it does not mean
- **Table / figure target**: where the evidence should appear (a report is sufficient)

Special rules:

- Simplicity check 与 frontier necessity check 的比较对象见 [block checks](references/block-checks.md)。保留了对应 block 时按该文件填写；非 frontier 方法跳过 frontier block。
- Pre-specify sampling unit, repeated seeds (start from DEFAULT_SEEDS when stochastic variance matters and budget allows), paired comparisons and uncertainty reporting when relevant. Keep tuning on development data and reserve final evaluation; label post-hoc analyses exploratory. Account for selection and multiple comparisons instead of presenting the best seed as confirmatory evidence.
- Separate **valid negative** (valid evidence rules out the pre-specified meaningful gain or meets an explicit falsification rule), **inconclusive** (uncertainty still permits competing conclusions), **invalid** (protocol/data leakage/evaluator defect), and **operational failure** (crash/OOM/timeout). Missing a success threshold alone does not establish a negative; pre-specify how uncertainty and effect size distinguish negative from inconclusive. A valid negative limits the tested Claim; operational failure is not scientific falsification. Preserve all attempts, not only winners; missing metrics remain missing, never zero-valued success.
- For **each criterion (including baseline validity and budget compliance)**, identify the planned primary evidence: run IDs, actual or proposed raw-result location, metric/column or log section, comparison and decision rule. Record existing evidence separately with its source; future evidence stays **not collected**. File existence and model agreement do not establish that the criterion holds.

**完成条件**：每个 block 的所有字段与逐 criterion evidence 对应完整；正、负、不确定、无效及运行失败的含义可区分。

**### Phase 4: Turn the Plan Into an Execution Order**

Specify future milestones; do not execute them:

1. **Sanity stage** — data pipeline and metric correctness; include a quick overfit or toy split only if it fits the authorized scope. If it would alter fixed data or training settings, use sufficient existing protocol checks instead, or block pending a separately approved sanity design. Label any dedicated sanity attempt and exclude it from confirmatory results.
2. **Baseline stage** — reproduce the strongest baseline(s) unchanged before candidate optimization
3. **Main method stage** — final method on the primary setting
4. **Decision stage** — decisive ablations for novelty, simplicity and frontier necessity
5. **Polish stage** — robustness, qualitative figures, appendix extras

For each milestone estimate compute, turnaround time, stop/go gate, risk and mitigation. **Baseline-first**: candidate runs require a valid baseline on the same evaluation surface, with original configuration and raw evidence retained. An earlier baseline may be reused only when its protocol and evidence are actually comparable; a literature number alone is insufficient. Baseline failure blocks main runs rather than encouraging optimization against an unreliable reference.

Separate **must-run** from **nice-to-have**. State per-run and total hard limits:

- run count (including seeds, sanity and retries), wall time including startup/evaluation, CPU/GPU time, memory/storage, data preparation, human effort, monetary cost and remote/API use as applicable; explicit zero or not-applicable is preferable to an unbounded blank.
- Show arithmetic and distinguish estimates from user-approved ceilings.
- Define resource accounting: occupied vs active GPU time, CPU cores × hours, whether existing data/cache counts toward storage, and cleanup time inside the wall-time cap.
- Count failed attempts against the budget; unused headroom authorizes neither retries nor new variants.
- Record who may stop a future job and what authorization is required, without stopping any job now.

If the minimum discriminating suite exceeds a ceiling, reduce optional work or present a smaller hypothesis with user approval; do not quietly increase budget or remove the decisive control. Gate on missing resources, invalid baseline, exhausted budget or protocol changes; new decisions go to the user, not an automatic loop.

**完成条件**：baseline-first 依赖、每阶段 gate、总预算算式与硬上限清楚；所有必须实验能纳入上限，否则明确不可执行及需用户决定之处。

**### Phase 5: Write the Outputs and Stop**

Read [计划与 tracker 模板](templates/experiment-plan.md) now. Fill every applicable section; explain any omitted block. Preserve natural-format evidence paths instead of wrapping them in a central schema. Follow the user's language preference; code, paths and metric names retain their original form.

Present the full draft in the conversation, or write only the authorized destinations under the write rules above ([调用与授权](#调用与授权)). The tracker is a human-readable list of proposed runs, not a scheduler; initial status is **NOT RUN** or **BLOCKED**, and planned evidence is not a result. Future execution may record successful, negative, invalid, crashed and timed-out attempts there without deleting history.

Finish with:

- Must-run blocks and first three **proposed** runs (not launch commands executed)
- Highest-risk assumption, unresolved decisions and whether the plan is complete enough for execution authorization
- Actual output paths, or “仅对话草稿，未落盘”
- “未启动实验、未配置环境；执行需用户另行授权”

**完成条件**：逐 Claim、逐 criterion 与全部 run 对照过计划和 tracker，预算一致；每个缺口可定位；输出后停止，不进入执行、自动改进或写作。

### 逐项对照原文补漏

已把上面的 todolist 与磁盘原文 `playbooks/experiment-plan.md`、`experiment-plan/SKILL.md` 逐条对照：步骤编号 1–6 连续无缺；`## 适用`、`## 停止` 原句在列；叶的 Phase 0–5、两条完成条件分支、Special rules 子列表、Phase 5 finish 子列表均逐字保留，无压缩。**未发现漏句。** 残留不确定性：叶阶段未纳入 playbook 步骤本体、仅作为步骤 1 的内嵌合同附上（这是 retelling 结构选择，不删原文）。

---

## 2. 交付物：TOY 求和正确性实验计划（BLOCKED 草稿，仅对话，未落盘）

> 依据 `experiment-plan/templates/experiment-plan.md` 填写；所有缺口就地标注。**本计划不表示已授权执行。**

**Problem / Hypothesis**：对**同一本地整数序列**，比较内建 `sum(seq)` 与显式 `for` 循环累加两种求和在**正确性**上是否等价。预期方向：在冻结输入域 D 上二者产生相同整数总和（或对不合规输入抛同类错误）；可被反驳的条件 = 存在 D 中一个序列使两者结果不同，或一个报错另一个不报。
**Method Thesis**：用冻结输入域 + 独立期望值（oracle），判定 `sum` 与 `for` 的正确性等价，并把「主线等价性」与「边界/错误类」分开记录。
**Date**：2026-10-03
**Inputs**：用户 prompt（TOY 任务描述）；工作区无 proposal / review / refinement 文件、无 `research-log.md`。已知事实 = 任务：整数序列、两法比较、看正确性；待确认假设 = 输入域、oracle、evaluator、预算（见缺口表）。
**Planning status**：**blocked draft —— 缺数据域定义、evaluator、批准预算**（两者均不表示已授权执行）
**Output scope**：仅对话草稿，未落盘（本批零写域）

### Claim Map

| Claim | Why It Matters | Anti-claim / Falsifying Observation | Minimum Convincing Evidence | Linked Blocks |
|-------|----------------|-----------------------------------|-----------------------------|---------------|
| C1：在冻结域 D 上，`sum(seq)` 与 `for` 累加对每个输入给出相同整数总和（或同类错误） | TOY 核心问题——两种求和是否可互换而不改变正确性 | 「等价只源于某 Python 版本 / 只因输入恰好是非空纯 int」；反驳 = 任一 D 中序列结果不同 | D 全部枚举 + 独立 oracle + 0 处不一致 + 边界类显式记录 | B1, B2 |

### Fixed Evaluation and Candidate Scope（缺口已标注）

- **Candidate files/components and allowed hyperparameter ranges**：提议 `toy_sum/sum_vs_for.py`（**未创建**），允许组件：纯标准库；`sum(seq)` 与 `for` 累加两实现。具体路径/evaluator 脚本名**待确认（缺口 G1）**。
- **Allowed future result locations**：**待确认（缺口 G2，无写域）**。
- **Fixed dataset version / splits / preprocessing / ground-truth source**：输入域 D（序列如何生成、长度范围、取值、是否含空/单元素）**未定义（缺口 G3）**；oracle 来源**未定（缺口 G4）**。
- **Fixed evaluator / metric definition, direction, units, aggregation**：提议指标 = 不一致计数（direction：越低越好，0 为通过）；但 evaluator 归属与协议**未知（缺口 G5）**。
- **Fixed selection rule, seeds/pairing, comparison budget**：确定性 TOY → 建议无随机 seed，除 D 含随机生成；对比预算**未知（缺口 G6）**。
- **Evaluation owner, candidate implementer and actual access separation (or not enforced)**：单一 TOY，**非强制隔离**；仅计划性责任边界。
- **Protocol defect/change handling and required approval**：发现 evaluator 缺陷须停该对比，用户批准新协议，全部重评并保留旧结果标记不可比。

### Paper Storyline（非论文项目 → 核心/补充证据）

- **Main paper must prove → 核心证据**：B1 主线等价性。
- **Appendix can support → 补充证据**：B2 边界与错误类。
- **Experiments intentionally cut and why**：性能/耗时对比——本任务只问正确性，**Cut**。
- **Frontier primitive central / absent and why**：**absent**（非 frontier 方法）→ 按叶规则跳过 frontier necessity block。

### Experiment Blocks

> 叶规则提示：Skipping frontier block 因非 frontier；Simplicity check 的比较对象见 `block-checks.md`（对照被有意拒绝的过度版本，且保持可比的调优/评价）。

#### B1: 主线等价性（内建 `sum` vs 显式 `for`）

- **Claim tested**：C1。**Why this block exists**：这是唯一能改变「是否等价」判定的 cheapest discriminating comparison。
- **Competing explanations and discriminating predictions**：①二者数学等价 → 全部一致；②`for` 起点/累加语义与 `sum` 默认 start 不同 → 空或非 int 情形分歧；③浮点/非 int 输入 → 结果或类型差异。三者预测可区分。
- **Dataset / split / task**：域 D **待确认（G3）**。
- **Compared systems / strong baselines / ablations**：baseline = 显式 `for` 累加（参考实现，保持不动）；candidate = 内建 `sum`。可达 MAX_BASELINE_FAMILIES=3，但此处只 1 族。
- **Metrics (decisive then secondary)**：决定性 = 逐输入不一致计数（0 通过）；次要 = 错误类是否一致、结果类型是否一致。
- **Setup details**：Python（版本 **待确认 G7**）；无训练；无 seed（除非 D 随机）；超参 = `sum` 的 start 参数取值 **待确认（G8）**。
- **Success criterion**：D 全枚举下 0 处不一致，且边界错误类一致；非「最佳点估计」。
- **Failure interpretation**：valid negative = 存在 D 中反例、稳定可复现；inconclusive = D 未覆盖相关类；invalid = oracle/evaluator 缺陷或数据泄漏；operational failure = 脚本崩溃/环境问题，**非**科学反驳。
- **Table / figure target**：对话内 CSV/表格报告即可。
- **Priority**：**MUST-RUN**

#### B2: 边界与错误类（Simplicity/边界）

- **Claim tested**：C1 在边界类（空序列、单元素、含 bool/浮点/非数值、迭代器 vs 列表）的表现。
- **Why this block exists**：主线之外最可能分歧处；对应 Simplicity check（对照「能否用更简单单法避免碎片化」）。
- **Competing explanations and discriminating predictions**：见 B1 ②③。
- **Dataset / split / task**：边界样例集 **待确认（G9）**。
- **Compared systems**：同 B1。
- **Metrics**：边界不一致计数 + 错误类匹配。
- **Setup details**：同上。
- **Success criterion**：每条边界预定义期望（含「应报同类错误」）。
- **Failure interpretation**：四态同 B1。
- **Table / figure target**：对话内附录表。
- **Priority**：**MUST-RUN**（边界小，成本低）

### Criterion Evidence Map（planned locations are explicitly proposed, not existing evidence）

| Criterion | Claim / Block | Run IDs and Comparison | Required Primary Evidence / Location / Field | Decision Rule | Existing Evidence or Not Collected / Gap |
|-----------|---------------|------------------------|--------------------------------------------|---------------|------------------------------------------------|
| K1 主线等价 | C1 / B1 | R002 vs R001 | proposed `toy_sum/results.csv`：`mismatch_count` | == 0 | not collected（G2/G5） |
| K2 错误类一致 | C1 / B1,B2 | R002/R003 边界 | proposed `toy_sum/results.csv`：`error_class_equal` | 全 True | not collected（G5/G9） |
| K3 baseline 有效性 | — / B1 | R001 | proposed `toy_sum/raw/for_baseline.txt` | 在 D 上可复现、无改动 | not collected（G4） |
| K4 预算合规 | 全部 | R001–R00n | proposed `research-log.md` 本批段落 | 消耗 ≤ 本批上限 | not collected（G6，本批 0） |

### Run Order and Milestones（仅规定未来顺序，不执行）

| Milestone | Goal | Runs | Decision Gate | Cost / Turnaround | Risk / Mitigation |
|-----------|------|------|---------------|-------------------|-------------------|
| M0 | sanity：确认 D 与 oracle 正确 | R000 | D 与指标的合法性先于 M1 | 未知（G6） | oracle 错 → 阻塞 |
| M1 | baseline：显式 `for` 累加原样复现 | R001 | 同评价面上有有效 baseline 才进 M2 | 未知 | baseline 失败则阻塞主线 |
| M2 | main method：内建 `sum` | R002 | K1/K2 判定 | 未知 | 版本差异 → 固定版本 |
| M3 | decision：边界消融 | R003+ | 边界类判定 | 未知 | 定义漂移 → 冻结 D |
| M4 | optional polish | — | 非必须 | — | — |

### Compute and Data Budget

- **Resource assumptions vs user-approved limits（分离）**：均为 **0 / 未知**——本批无批准预算（`compute-policy.md` 不存在，默认范围未指定 = 费用/算力/运行数 0，有效期 0 小时）。
- **Total estimated**：**未知**，不补数（playbook 步骤 2）。
- **Run count, seeds, retries**：待定；失败 attempt 计入预算。
- **Per-run / total wall-time**：未知。
- **Memory / storage caps**：未知；无既有 data/cache 计入。
- **Data preparation needs and access/license gaps**：G3。
- **Human evaluation**：N/A（自动 oracle）。
- **Monetary ceiling and remote/paid API**：**0**（本地 TOY，无外发）。
- **Biggest bottleneck**：D 与 oracle 的定义（G3/G4）。
- **Stop conditions / future job-stop authority**：缺授权、过期、范围变更、越界即停于作业前；停止权限待用户指定。
- **Must-run feasibility**：MUST-RUN（B1/B2）体量小，**但当前因 G1–G9 未闭合而不可执行**；optional 项已省略。

### Statistical and Validity Plan

- **Sampling unit / pairing / seeds / uncertainty**：确定性比对，无统计不确定性；如 D 为随机生成，则重新引入 seed 与重复（待 G6）。
- **Tuning vs held-out**：无调优；无 post-hoc 分析。
- **Evidence retention**：保留全部 attempt，含负/无效/崩溃/超时，不删历史。
- **What negative evidence limits**：反例只能限制 C1 到 D 的某子域，不外推。

### Risks and Mitigations

- **[风险] `sum` 默认 start=0 与 `for` 起点不同** → 固定并记录 start（G8）。
- **[风险] 非 int（bool/float）输入语义差异** → B2 显式覆盖。
- **[风险] Python 版本差异** → 固定并记录解释器版本（G7）。
- **[风险] 迭代器一次性/生成器** → D 明确输入类型。
- **[Unresolved decision] G1–G9 待用户决定，影响 B1/B2 与 K1–K4。**

### Final Checklist

- [x] Main 对比（B1）覆盖 C1
- [ ] Novelty 隔离控制——TOY 无 novelty，视为不适用（理由已述）
- [x] Simplicity 已由 B2 边界块防守
- [x] Frontier 明确未声称 → 跳过
- [x] Nice-to-have（M4）与 must-run 分离
- [x] 每 criterion 有 primary evidence 位置与 decision rule
- [x] Candidate scope 与 fixed evaluation surface 不重叠（路径均标「未创建/待确认」）
- [x] Sanity 与有效 baseline 先于 candidate
- [ ] Tracker/硬上限/负向解释/blocker 一致——**因预算未知，无法置 True**

---

## 3. Experiment Tracker（planned，never completed evidence）

| Run ID | Milestone | Purpose / Criterion | System / Variant | Split / Seed | Metrics | Priority | Status | Planned Raw Evidence / Notes |
|--------|-----------|---------------------|------------------|--------------|---------|----------|--------|------------------------------|
| R000 | M0 | sanity / K3 | D 与 oracle 校验 | D（待定） | 一致性 | MUST | BLOCKED | proposed `toy_sum/raw/sanity.txt` |
| R001 | M1 | baseline / K3 | `for` 累加（原样） | D（待定） | 总和 | MUST | NOT RUN | proposed `toy_sum/raw/for_baseline.txt` |
| R002 | M2 | main / K1 | 内建 `sum` | 同 R001 | mismatch_count=0 | MUST | NOT RUN | proposed `toy_sum/results.csv` |
| R003 | M3 | 边界 / K2 | 边界样例集 | 同 R001 | error_class_equal | MUST | NOT RUN | proposed `toy_sum/results.csv` |

> 所有行均为 planned；planned evidence ≠ 结果。

## 4. Batch Authorization 字段（步骤 3，全部待确认，不补默认数）

按 `references/batch-authorization.md`，本批字段现状：

- **scope**：计划/写域/环境 = **未指定 → 本批不能执行**。
- **cost_limit / currency**：未知。
- **compute_limit / compute_unit**：未知（单位仅 `cpu-core-hour` 或 `gpu-device-hour`）。
- **run_limit / run_count_basis**：未知（experiment-plan 侧为 `planned-run`）。
- **per_attempt_cost_limit / per_attempt_compute_limit**：未知。
- **concurrency_limit**：未知（要启动须 ≥1）。
- **retry_limit**：未知。
- **valid_for_hours / valid_until**：未知（须有限、带时区 ISO8601）。
- **batch_id / plan / mode / user_confirmation / confirmed_at / confirmation_basis / authorization_status**：未确认；**不写** `research-log.md`（步骤 4 待用户确认本批且授予写域）。
- **禁止**：unlimited/负数/NaN/无单位；`not-applicable` 须写明理由。

## 5. Handoff

- **Must-run blocks**：B1、B2。
- **First three proposed runs**（非已执行命令）：R000（sanity）、R001（baseline）、R002（main）。
- **Highest-risk assumption**：存在一个well-defined 有限输入域 D 与独立 oracle 足以判定等价性；这是 C1 成立的前提（G3/G4）。
- **Unresolved decisions**：G1–G9 + 本批全部授权字段 + 模型表回退确认。
- **计划是否达到可授权**：**否 —— BLOCKED 草稿**（缺数据域、evaluator、批准预算）。
- **Actual output paths**：**仅对话草稿，未落盘**。
- **Outstanding blockers**：无写域、未批准本批、模型表缺失。

**未启动实验、未配置环境；执行需用户另行授权。** 本路线只规划，交付此草稿即停止，不进入执行、自动改进或写作。