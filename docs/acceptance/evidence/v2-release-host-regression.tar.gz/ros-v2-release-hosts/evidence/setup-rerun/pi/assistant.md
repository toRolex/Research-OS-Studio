本轮只做真实只读 Explore、宿主当前模型清单与配置一致性核对；不启动科研流程、不写任何文件，也不把旧审查算作本轮独立 review。你已明确指定沿用八角色 `cliproxy/glm-5.3-flash | off`、当前工作区及日志，我会先核实其本轮可用性。

本次工具范围：读取实际安装入口的 playbook，确认项目路径、文件类型和现有文件清单；全局文件仅核对存在性与修改时间。预算：主会话一次、300 秒上限；fresh/build/GET/新实验均为 0，不联网、不安装、不编译。


已实核：`/tmp/ros-v2-release-hosts/setup-rerun-project` 与 `/private/tmp/...` 是同一项目位置；实际安装入口可读，所引用的四份模板和冲突规则均存在。当前根目录没有 `CLAUDE.md` 或根 `README.md`；有 `AGENTS.md`、角色表及 `research/` 五份文档，合计七件配置文件。

以下为从本轮实际入口读取的**对话 todolist**。保留原步骤编号、原句及子列表，仅附状态/证据；首次对照已补齐两个无编号确认门，没有虚构步骤 3 或 7。

## 1. Explore

只读检查当前项目：

- 确认项目根目录，读取适用的项目指令和 README。
- 检查根目录 `CLAUDE.md`、`AGENTS.md`，以及已有 `## Research OS` 区块。
- 查找 `.agents/research-os-models.md`、工作区里的 `compute-policy.md`、`README.md`、`project.md`、`findings.md`、`research-log.md`。已有非空工作区优先沿用，例如 `research/`、`notes/`、`docs/research/`。
- 记录这些文件是否存在，以及角色表、政策、研究日志的当前字节。全局 `~/.agents/pstack-models.md` 只记录路径和修改时间，用来事后核对它没变。
- 区分文件、目录、符号链接与不可读对象。指令文件链接指向项目外、链接失效或访问被拒时，停止该写入。

完成条件：能列出项目根、已有导航、角色表、政策、日志、指令文件候选，以及未知项。此时没有任何写入。

**状态/证据：进行中；路径及七件文件已发现，内容与字节待读取。全局文件仅 stat，mtime=1791006579。**

## 2. 列出可用模型

向当前宿主查询本 session 真正可用的模型。Pi 用 `pi --list-models`，读出 provider、model id，以及该行 thinking 是 yes 还是 no。其他宿主用它自己的模型列表命令；命令失败或结果不含模型 id 时，说明清单未知并停止，不编造 slug。

每条候选记成 `provider/model-id`。thinking 为 no 的模型只允许 `off`。thinking 为 yes 的模型只在 `off`、`minimal`、`low`、`medium`、`high`、`xhigh`、`max` 中选择该模型实际支持的档位；清单没写具体档位时，向用户标出“档位未在清单中分开列出”，由用户选定其中一档。

完成条件：后续推荐的每个模型都能在这次命令输出里逐字找到。

**状态/证据：待执行本轮 `pi --list-models`；未采用旧清单。**

## 确认模型

八个角色固定为 orchestrator、literature、ideator、implementer、analyst、prover、writer、reviewer。一次只确认一个角色，推荐放在前面：一个清单内的 `provider/model-id`，加一个该模型支持的 thinking。

Gate: model-confirm | before=role-table-write | approval=explicit-user | source=SKILL.md#确认模型

用户给出的 slug 不在本轮清单中时，停下并重新询问。未确认的模型不进入草稿，也不写入文件。八个角色都确认后，才展示整份角色表：每行 `角色: provider/model-id | thinking`，不多行、不缺行。

完成条件：八个角色各自有一条用户确认过的、且模型属于本轮清单的角色行。

**状态/证据：用户已明确要求八角色沿用 `cliproxy/glm-5.3-flash | off`，尚待本轮清单验证；不重新发起逐角色配置，也不据此取得写入授权。**

## 4. Present

简述哪些文件复用、哪些缺失、哪些需要决定。推荐可见的 `research/`；已有工作区沿用。材料留在原处。

默认政策按 [compute-policy.md](templates/compute-policy.md) 整文件起草。它的额度是 0，范围和有效期是未指定。向用户说明：默认政策不是本批运行许可，不能据此启动实验或付费调用。

完成条件：用户已看到事实、建议和预计写入范围。

**状态/证据：待内容核对；本轮授权写入范围为空，默认政策不是运行许可。**

## 5. Ask

一次只问一个尚未决定的问题：

1. 工作区有歧义时，问沿用哪一个。没有工作区时，问是否采用 `research/`。同名文件不能当目录。
2. 项目名称或说明无法从材料确定时，只问缺失项，或允许跳过。
3. 指令文件优先已有 `CLAUDE.md`，否则已有 `AGENTS.md`。两者都有时只改前者。都没有时询问创建哪一个，也允许暂不创建。
4. 内容冲突按 [冲突与重复执行规则](references/conflicts.md) 逐项选择。角色表和政策文件若与确认稿不同，选择保留现状或整文件替换，不做半文件拼接。

完成条件：每个拟写入项的路径和冲突处理已确定。用户拒绝时零写入并停止。

**状态/证据：工作区和日志由用户指定沿用；候选指令文件为已有 `AGENTS.md`。本轮不请求扩展写域，有差异只展示。**

## 6. Draft

读取 [基础文档种子](templates/workspace.md)、[角色表形状](templates/research-os-models.md)、[默认算力政策](templates/compute-policy.md) 和 [研究日志字段](templates/research-log.md)。只用所需部分。

向用户展示完整草稿：

- `.agents/research-os-models.md` 的全文，八行都是已确认模型。
- 工作区 `compute-policy.md` 的全文。用户没有另给一批真实授权时，使用默认模板原文。
- 缺失的导航、项目说明、findings、研究日志。日志只在文件不存在时创建。
- 指令文件中拟写入的 `## Research OS` 区块，以及保留不动的其余内容。

导航只链接已经存在或本批会创建的文件。

完成条件：每一处拟写入内容都已展示，没有隐藏文件。

**状态/证据：待读取全部叶资源；仅展示一致性或拟变更，不产生任务文件。**

## 确认写入

Gate: write-confirm | before=workspace-write | approval=explicit-user | source=SKILL.md#确认写入

询问是否按这份完整草稿写入。沉默、推荐答案、单个路径选择和“已安装”都不算同意。用户改草稿后，重新展示受影响全文再确认。用户拒绝则零写入。

若确认稿与目标文件字节相同，报告“无需写入”并停止。

完成条件：当前全文获得明确写入同意，或已停止。

**状态/证据：写入未批准；达到此门即停止写入路径。一致则报告“无需写入”。**

## 8. Write

写入前重新读取全部目的文件。内容与 Draft 所见不一致、新建路径已经出现，或指令文件候选的优先级变了，就停止整批，回到 Ask。

按获批全文写入：

- 角色表和政策文件整文件替换。确认稿与现状字节相同时跳过。不在文件末尾追加第二套角色或第二套额度。
- 只创建缺失的导航、项目说明、findings、研究日志。研究日志已存在时不打开它来改写。
- `## Research OS` 区块原位更新一次；没有时追加一次。其他区块逐字保留。

不创建、不修改 `~/.agents/pstack-models.md`。遇到写入错误立即停止，报告已成功和未完成的文件。

完成条件：获批内容已写入且没有额外文件；或失败已报告并停止。

**状态/证据：禁入；本轮没有获批写域，不调用 write/edit。**

## 9. Verify

重新读取每个获批文件，对照确认稿的字节、角色行数、政策字段和链接目标。核对：

- `.agents/research-os-models.md` 恰好八个角色，每个模型都属于写入前那份清单。
- `compute-policy.md` 仍写明不是运行授权。
- 既有 `research-log.md` 的字节与 Explore 时相同。
- `~/.agents/pstack-models.md` 的修改时间与 Explore 时相同；本来不存在则仍然不存在。
- Research OS 区块只有一份，没有多余空目录或研究产物。

完成条件：全部获批变更已逐项核对，结果和局限已告诉用户。

**状态/证据：只做只读一致性及未变核对，不声称完成写后验证或新独立 review。**

## 10. Stop

告知角色表、政策和工作区导航的实际路径。重复运行只补缺失项；角色表和政策在用户确认新全文后整文件替换。到此停止，不启动研究流程。

**状态/证据：待报告后停止。**

下一次工具范围：完整读取七件现存配置、当前适用的冲突规则和四份模板、安装锁文件；执行本轮模型列表、只读类型/链接/字节摘要检查。不会读取全局模型表内容，不读原项目或运行旧 79 轮流程。剩余预算：仍仅当前一次主会话，300 秒总上限；fresh/build/GET/新实验均为 0。


本轮 `pi --list-models` 已成功返回真实清单，包含：

```text
provider  model          context  max-out  thinking  images
cliproxy  glm-5.3-flash  1.0M     131.1K   yes       yes
```

**档位未在清单中分开列出**；沿用你本轮明确选定的 `off`，不声称已经做过调用测试。八角色现存行与该选择一致：

```text
orchestrator: cliproxy/glm-5.3-flash | off
literature: cliproxy/glm-5.3-flash | off
ideator: cliproxy/glm-5.3-flash | off
implementer: cliproxy/glm-5.3-flash | off
analyst: cliproxy/glm-5.3-flash | off
prover: cliproxy/glm-5.3-flash | off
writer: cliproxy/glm-5.3-flash | off
reviewer: cliproxy/glm-5.3-flash | off
```

当前检查未发现需写入项：七件配置齐全；已有 `AGENTS.md` 的 Research OS 区块与模板替换实际路径后的内容一致；政策显示零额度、未指定范围/有效期且明确不是运行授权；既有日志全文保留。`fixtures/` 中的其他工作区不替代你指定的根 `research/`，也不使用其中清单证明模型可用性。

对话 todolist 状态附记：
- **1. Explore**：七件全文和类型已读，均为普通文件；根 `CLAUDE.md`/`README.md` 不存在，导航使用 `research/README.md`。
- **2. 列出可用模型**：本轮命令成功，目标 id 逐字存在。
- **确认模型**：沿用本轮显式选择，仅作一致性核对，不开启角色表写入。
- **4. Present / 5. Ask / 6. Draft**：叶资源全文已读；现存文件复用，没有缺失种子，拟变更集为空。
- **确认写入**：没有批准写域；无需写入，不索取新授权。
- **8. Write**：跳过，零写入。
- **9. Verify**：接下来仅补最终只读字节、链接和安装来源核对。
- **10. Stop**：核对后停止，不进入研究流程。

下一次工具范围：对七件配置作只读字节复核，核对导航链接及单一指令区块；仅对安装锁所指本地源作 Git 只读 commit/内容比对，以核实你给出的 tip（不更新索引、不操作分支、不 fetch），全局表仍只 stat。已用约 2 分钟，300 秒上限约余 3 分钟；fresh/build/GET/新实验仍全部为 0。


## 结论：配置一致，无需写入

已完成本轮真实只读 Explore、**当前 `pi --list-models` 清单查询**和一致性核对。拟变更集为空，**零创建、零修改、零覆盖**。

项目根：`/private/tmp/ros-v2-release-hosts/setup-rerun-project`，与指定 `/tmp/...` 入口一致。

| 核对项 | 本轮证据与结果 |
|---|---|
| 安装来源 | 本地安装源 HEAD 为 `5efd2daffc68612def5e4660defb68db5a7780e3`；已安装 `setup-research-os` 全部 **8 个文件**与该 commit 逐字节一致，引用资源无路径缺口 |
| 当前模型可用性 | 本轮宿主命令列出 `cliproxy/glm-5.3-flash`，`thinking=yes`；清单未分列具体档位，沿用你明确指定的 `off` |
| 八角色 | 恰好 8 行，全部为 `cliproxy/glm-5.3-flash \| off`，无缺行或不匹配行 |
| 默认政策 | `research/compute-policy.md` 与当前安装模板逐字节一致；零额度、范围和有效期未指定，明确**不是运行授权** |
| 工作区与导航 | 沿用根 `research/`；导航链接均指向实际存在且可读的文件，无需补种子 |
| Agent 指令 | 使用已有 `AGENTS.md`；只有一个 `## Research OS` 区块，与模板代入实际路径后逐字节一致，其余内容保留 |
| 既有七件配置 | 初始与最终 SHA-256 全部一致 |
| 研究日志 | `research/research-log.md` 保持 610 字节；SHA-256 两次均为 `c520aff085ed12baf91f24180327073efb95460d834eb7c35cdb80d05eb0d0ba` |
| 全局模型表 | 未读取内容；前后 mtime 均为 `1791006579`，未修改 |

**对话 todolist 最终状态：**只读一致性核对完成；写入确认门未获授权，`8. Write` 未进入；`10. Stop` 已到达。不生成任务文件或重复 setup 日志。

实际配置路径：
- 角色表：`.agents/research-os-models.md`
- 政策：`research/compute-policy.md`
- 导航：`research/README.md`
- 日志：`research/research-log.md`
- 指令：`AGENTS.md`

本轮约 178 秒、仅当前主会话；fresh/build/GET/新实验消耗均为 **0**。未使用 Python、联网、安装、编译或发起模型调用测试；未重跑旧 79 轮科研流程，也未将旧审查或本次自查视为新独立 review。到此停止。