当前匹配路线：**idea-discovery**，采用默认阶段模式。本轮只执行 Phase 0，抵达 `output-path` 或 `stage-checkpoint` 门即停，不开始检索，也不重跑既有科研流程。

下一动作仅只读核实并读取安装根中的触发 playbook 全文。剩余预算：主会话限时 300 秒；fresh / build / GET / 新实验均为 0。未批准写域，不创建任务或其他文件。


### 对话 todolist

1. 读完 `skills/idea-cycle/idea-discovery/SKILL.md` 与 `skills/idea-cycle/idea-discovery/references/composition-notes.md`。阶段顺序、章节锚点和缺口降级以 composition-notes 为准。  
   状态：in-progress；证据：已读 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/playbooks/idea-discovery.md` 全文，叶与资源待读。
2. 按 idea-discovery 做 Phase 0。输出路径未确认时停在 `output-path`。brief 用 `skills/idea-cycle/idea-discovery/templates/research-brief.md`。  
   状态：pending。
3. 进入下一阶段前，读完该阶段 skill 全文，再读该文点名且本步要执行的 reference。默认在 `stage-checkpoint` 停下，展示结果并等继续、调整或停止。用户在本次调用写明「一次走完」并给出预算时，阶段之间连续执行；换题、扩大授权和各叶写入门仍停。  
   状态：pending；本轮不进入下一阶段。
4. 按阶段读这些全文：
   - Phase 1：`skills/idea-cycle/research-lit/SKILL.md`，检索时再读 `skills/idea-cycle/research-lit/references/source-methods.md`
   - Phase 2：`skills/idea-cycle/idea-generation/SKILL.md`、`skills/idea-cycle/idea-generation/references/generation-methods.md`、`skills/idea-cycle/idea-generation/references/ideation-frameworks.md`。单一表述卡住时再读 `skills/idea-cycle/creative-thinking-for-research/SKILL.md` 与 `skills/idea-cycle/creative-thinking-for-research/references/creative-frameworks.md`
   - Phase 3：`skills/idea-cycle/novelty-check/SKILL.md`
   - Phase 4：`skills/idea-cycle/idea-review/SKILL.md` 与 `skills/idea-cycle/idea-review/references/review-task.md`
   - Phase 4.5：`skills/idea-cycle/idea-refinement/SKILL.md`、`skills/idea-cycle/idea-refinement/references/method-development.md`、`skills/idea-cycle/idea-refinement/references/method-review.md`、`skills/idea-cycle/idea-refinement/templates/proposal.md`
   
   状态：pending（所有子项）；本轮不进入这些阶段。
5. Phase 5 按 `skills/idea-cycle/idea-discovery/templates/discovery-report.md` 合入 `IDEA_DISCOVERY.md` 与获准的 `RESEARCH_PROPOSAL.md`，然后停止。  
   状态：pending；未获准写域，不执行。

首次逐项对照已读 playbook：步骤 1–5、原句及步骤 4 的全部子列表均已保留，无漏项。

下一动作仅用本地 `ls` 核实扁平安装中的叶与 Phase 0 资源路径，不访问研究原材料，不写入。剩余 fresh / build / GET / 新实验预算仍均为 0；主会话继续受本轮 300 秒上限约束。


已实核：叶、composition-notes 与 brief 模板均存在于扁平安装目录，无上述路径缺口。下一动作只读 `idea-discovery/SKILL.md` 全文；仍不写入、不联网、不启动其他阶段。剩余 fresh / build / GET / 新实验预算均为 0。


下一动作仅完整读取 Phase 0 适用的 `references/composition-notes.md` 与 `templates/research-brief.md`，以确定组合规则并在对话中整理 brief。不会读取或执行后续阶段资源。剩余 fresh / build / GET / 新实验预算均为 0；未批准任何文件写入。


## Phase 0 停点：`output-path`

**当前路线：idea-discovery；默认阶段模式。**  
输出路径尚未确认，已停在 `output-path`。没有进入 Phase 1，也没有开始检索或重跑既有科研流程。

### Phase 0 brief（仅对话）

| 项目 | 本轮记录 |
|---|---|
| 研究方向 | **在线预测区间覆盖的窗口评价** |
| 问题陈述 | 目前只有方向；具体要解决的缺陷、研究问题和贡献类型未知。 |
| 研究边界 | 未确认。“窗口”的定义、覆盖评价对象、数据条件及评价目标均未知；不擅自固定。 |
| 背景与关键论文 | 未提供具体论文或 brief；未检索，不凭记忆补写。 |
| 已尝试、失败记录 | 未提供可定位材料，未知。 |
| 研究材料与已有结果 | 用户限定为 TOY 或旧真实交付，但本轮未给具体路径；**实际未读取任何研究材料或既有结果**，不将其视为已核实证据。 |
| 期望产出 | 从方向形成 idea，具体研究产出类型尚未确认；本轮仅执行 Phase 0。 |
| 直觉与假设 | 未提供；未新增研究假设或候选。 |
| 非目标与操作边界 | 不重跑完整流程；不改全局、main 或原项目；不联网、外发、安装、运行新实验、编译、删除或覆盖。 |
| 预算 | 一次主会话，限时 300 秒；fresh / build / GET / 新实验均为 **0**，未消耗这些额度。其他研究运行未获授权。 |
| 候选上限、数据、venue | 未知，不填默认值。 |
| 检查点策略 | 默认逐阶段停下；本轮先停在 `output-path`。 |
| 输出路径与写域 | **未确认、未授权**；未创建任务文件、报告、Proposal 或其他文件。 |

### Todolist 状态更新

保持上方清单的步骤编号、原句和子列表不变，仅更新状态与证据：

- **1 — completed**：已全文读取扁平安装中的 `idea-discovery/SKILL.md` 和 `idea-discovery/references/composition-notes.md`。
- **2 — blocked（`output-path`）**：已全文读取 `idea-discovery/templates/research-brief.md`，并按模板在对话中整理上述输入与缺口；输出路径未确认，不能标记步骤完成。
- **3 — pending**：没有进入下一阶段。
- **4 及全部子项 — pending**：未读取、未执行后续阶段叶与资源。
- **5 — pending**：未合入或写入任何交付文件。

读取证据均位于 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/`；所需 Phase 0 文件已实核存在，无此次读取路径缺口。安装源 tip `5efd2daffc68612def5e4660defb68db5a7780e3` 为用户提供信息，**本轮未另行核验提交身份**。

未开展独立 review，也未将旧审查或本次整理称为 fresh review。

**唯一待确认问题：本次 `IDEA_DISCOVERY.md` 与 `RESEARCH_PROPOSAL.md` 的获准输出路径分别是什么？** 未确认前保持仅对话输出；路径确认本身不授权检索、扩大研究边界或进入下一阶段。