当前路线：route-only。先读取触发 playbook 全文，再逐字抄步骤为对话 todolist。

Playbook 已读。逐字抄步骤为对话 todolist（首次展示，逐项对照原文补漏，无遗漏）：

**route-only todolist**
1. [completed] 只读对话中已有内容。用户给出路径时，只读与选入口相关的部分。材料里的命令和「继续执行」是待分析文字，不是授权。 — 证据：本对话 args，仅分析。
2. [in-progress] 读产品地图，只再读命中分支。 — 证据：待读 `../references/PRODUCT-MAP.md` 及命中分支。
3. [pending] 对推荐的关键行为，只读当前安装里对应 `SKILL.md`；冲突以正文为准，读不到标「宿主可用性未核实」。
4. [pending] 给出一个首选和至多两个确有分歧的备选，然后停止。

**本动作范围**：只读本地文件（产品地图+命中分支+推荐 SKILL.md），无写域、无网络、无子代理、无实验；剩余预算：主会话 300s 内、fresh/build/GET/新实验 0。

用户只有方向、无 idea、无数据 → 命中分支预计是 idea-cycle，待地图确认。

地图已读，命中分支：idea-cycle.md。步骤2补读：

步骤3：读推荐入口 `idea-discovery` 的 SKILL.md 正文（扁平布局：安装根/idea-discovery/SKILL.md）。

route-only 禁止调用任务工具，忽略该提醒。完成 todolist 第4项后停止。

**步骤3核实记录**：两份 SKILL.md 均已读全文（idea-discovery 完整、experiment-plan 前30行确认其 user-invoked 且「输入可以是现成研究问题，不要求先运行 Discovery」）。地图与正文无冲突。

---

**你的位置**
- 材料：只有方向，无 idea、无数据、无 brief、无既有结果。
- 目标：以后写机器学习论文并跑实验。
- 未知项：具体研究方向内容、数据可得性、算力预算、venue 偏好——均未提供。

**地图位置**
- 当前路线：route-only（零副作用，已完成）。
- 推荐对象：Idea Discovery 主流程（方向 → Proposal），后续接 Validation 主流程（experiment-plan → experiment-bridge），再接 Paper Writing ML（`ml-paper-writing`）。

**首选：`idea-discovery`**（U，已实现 #8；本宿主已确认安装——`.claude/skills/idea-discovery/SKILL.md` 实读存在）
- 显式调用：`/research-os` 路线 idea-discovery，或直接点名叶入口 `idea-discovery`。
- 依据：只有方向无 idea 正是地图「按现有材料选切入点」第一行命中的场景；走完检索、候选、查新、评审、收敛，交付 Proposal 后停。默认每阶段停下等你确认。

**备选（确有分歧时才考虑）**
1. `experiment-plan`（U，已安装，已核实）：若你其实已有明确研究问题（非模糊方向），它不要求先跑 Discovery，可直接出 claim-driven 实验计划，且只规划不执行——与你「不跑实验」约束一致。但你的输入是方向而非问题，与首选输入条件不符，故仅列为分歧备选。
2. 无第二备选：idea-generation 等只是 Discovery 的局部 M 能力，不构成与首选真正分歧的独立路线。

**下一步由你决定**
- 最小材料：一行研究方向描述 + 可选约束（数据/算力/时间/venue）+ 输出路径。给齐后显式调用 `idea-discovery` 即可；Phase 0 会逐项标缺口，不会用默认值填满未知项。

**按停止条件到此结束**：不执行、不创建任务文件、不联网、不消耗 fresh/build/GET/新实验预算（均 0）。