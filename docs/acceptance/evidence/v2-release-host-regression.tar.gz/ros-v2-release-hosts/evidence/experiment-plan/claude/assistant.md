**路由匹配**：意图=「设计实验」+「只生成待确认计划、不开跑」→ 命中 `experiment-plan`（有界计划，非执行）。

**本批预算声明**（每步工具前复述）：主会话 1 次、约 300s；fresh/build/GET/新实验=0；只读读取+对话输出，无写域。

**动作 1（只读核实安装根与 tip）**：实核 `/tmp/ros-v2-release-hosts/projects/claude/.claude/skills` 与 tip `5efd2daf`。

安装根已实核（`experiment-plan` 等 skill 目录存在，扁平布局）。非 git 仓库，tip 需从文件核实。**动作 2（只读）**：查 tip 标识 + 读 playbook 全文。

**路径缺口实核结果**：安装目录存在且布局完整（扁平：`<安装根>/<skill-name>/SKILL.md`），但 ① 非 git 仓库、② 全项目 grep 无 `5efd2daf…` → tip hash 无法在文件中核实，记为未核实项，不阻塞只读流程。

**动作 3（只读）**：读 playbook 全文 + 叶 SKILL.md 全文。

Playbook 与叶合同已读全。步骤 1 要求读叶点名的 references 与 templates，步骤 3 点名 `references/batch-authorization.md`。**动作 4（只读）**：读三个资源全文。

全部叶合同与资源已读毕。路径缺口：playbook 步骤 1 写的 `skills/validation-cycle/experiment-plan/SKILL.md` 在本安装为扁平布局，实际映射并实读 `<安装根>/experiment-plan/SKILL.md`（144 行全文）+ `templates/experiment-plan.md` + `references/block-checks.md`；tip hash `5efd2daf…` 在文件中未找到（非 git 仓库、grep 无命中）→ **未核实项，不冒充已核**。

## 对话 todolist（playbook 步骤逐字，仅附状态/证据）

1. 读 `skills/validation-cycle/experiment-plan/SKILL.md` 全文，并读它点名的 references 与 templates。计划内容、阶段和产出以该正文为准。不在这里重写科研流程。 — **completed**（扁平映射实读全文；证据：experiment-plan/SKILL.md、templates/experiment-plan.md、references/block-checks.md；路径缺口已记）
2. 只读本次相关材料。未知项标缺口，不补预算数字。 — **completed**（材料=用户 prompt 的 TOY 描述；无既有数据/evaluator 文件 → 全部标缺口）
3. 计划达到「可供执行授权」前，按 [批次授权](../references/batch-authorization.md) 列出本批字段，请用户确认。确认的是这一批，不是工作区默认 `compute-policy.md`。 — **in-progress**（字段见下，待确认）
4. 用户确认本批后，把确认原文、时刻和全部字段写入工作区 `research-log.md` 的新段落。authorization_status 写「本批已确认」。默认政策额度保持 0，不抄进这条授权。 — **blocked**（未批准写域，不落盘）
5. 只把计划和 tracker 写到用户允许的路径。已有计划文件先展示差异。删除或覆盖既有实验结果时停，等另一次明确批准。 — **blocked**（同上，仅对话输出）
6. 交付计划后停止。本路线不启动实验，不把本批确认交给 bridge 自动开跑。 — **pending**（本轮交付后即停）

## BLOCKED 草稿：Experiment Plan（待补全，不可执行）

**Problem/Hypothesis**：TOY — 同一本地整数序列上，`sum(seq)` 与手写 for 累加的结果一致性。**Method Thesis**：两实现对精确整数归约语义等价，结果逐例相等。**Date**：2026-10-03。**Inputs**：仅用户 prompt；无既有文件。**Planning status**：**blocked draft — 不表示已授权执行**。**Output scope**：仅对话草稿，未落盘。

**Claim Map**

| Claim | Why | Anti-claim / 证伪观察 | 最小说服证据 | Blocks |
|---|---|---|---|---|
| C1（主）：`sum()` 与 for 累加对同一序列结果相等 | TOY 正确性基线 | 差异源于 for 实现 bug（漏元素/索引错）而非语义；证伪=任一序列两结果不等 | 全部测试序列上逐例相等 + 独立参照核验 | B1, B2 |

**Fixed Evaluation & Candidate Scope**（缺口多）：
- 候选范围：**缺口** — 无批准写域；未来实现路径全部 proposed、不存在。
- 数据：**缺口** — 「本地整数序列」来源/长度/取值域（是否含空、单元素、负数、大整数）未指定。
- evaluator/判据：**缺口** — 一致性判据（精确 `==`）未由用户固定；**无 ground truth**，需命名替代参照（建议：手工小序列表 + 独立第三次实现作 oracle）→ 待用户决定。
- 访问隔离：无实际隔离，仅为计划责任边界。

**Storyline / Blocks**：
- **B1 主结果（MUST）**：多组边界+随机序列，两实现逐例比对。判别实验：竞争解释 (a) for 实现 bug vs (b) 语义差异——(a) 预测失配与索引模式相关、修实现后消失；(b) 预测独立重写仍复现。
- **B2 简单性检查（supplementary）**：for 循环相对 `sum()` 是否必要——正是题面，保留为补充。
- B3/B4/B5：Cut（TOY 无 novelty/frontier 主张；非 frontier，frontier block 按叶规则跳过）。

**Criterion Evidence Map**

| Criterion | Claim/Block | 所需主证据 | Decision Rule | 现有证据 |
|---|---|---|---|---|
| K1 一致性 | C1/B1 | 两实现同序列输出（proposed 位置，不存在） | 全例相等→支持；任一不等→触发判别分析 | **not collected** |
| K2 oracle 有效性 | C1/B1 | 参照定义经用户确认 | 参照未定→计划不可执行 | **缺口** |

**Run Order**：M0 sanity（手工小序列如 `[1,2,3]→6` 双实现核对，MUST）→ M1 参照固定（oracle 确认，gate M2）→ M2 主比对（MUST）→ M3/M4 Cut。**Baseline-first**：无有效参照前不跑 M2。

**Compute Budget**：本批授权=0，**不补数字**；所有上限=未知，待用户填。

**本批授权字段（步骤 3，全部待确认）**：scope（含未来写域与环境）❓；cost_limit/currency ❓；compute_limit/compute_unit ❓；run_limit/run_count_basis ❓；per_attempt 上限 ❓；concurrency_limit ❓；retry_limit ❓；valid_for_hours/valid_until ❓；batch_id ❓；mode=experiment-plan；user_confirmation/confirmed_at/confirmation_basis 待用户原话；authorization_status=**未确认**。确认后字段才写入 `research-log.md`（需另行批准写域）。

**Handoff**：Must-run = B1（M0+M1+M2）；最高风险假设 = 「参照 oracle 可定义且经用户固定」；前三个 proposed runs = R001 sanity 手工小序列、R002 oracle 参照核验、R003 边界序列（空/单元素/负数/大整数）比对。**输出：仅对话草稿，未落盘。未启动实验、未配置环境；执行需用户另行授权。** 到门即停——等待本批字段确认。