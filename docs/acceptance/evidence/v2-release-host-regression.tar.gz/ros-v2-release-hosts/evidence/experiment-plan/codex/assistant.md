我先确认路线与读取范围，再按串行方式核对安装根与 playbook 原文。

**本动作范围**：只读列目录，核实 `research-os` 安装根与 playbook/叶/资源实际路径；**剩余预算**：主会话 300s 内、fresh/build/GET/新实验预算均 0（只读不消耗）。

**本动作范围**：串行只读入口 `SKILL.md`、命中 playbook `experiment-plan.md`、叶 skill `experiment-plan/SKILL.md` 及其资源，并探测项目级模型表/算力政策；**剩余预算**：只读，300s 主会话内，无写域。

**本动作范围**：只读叶点名的 `references/block-checks.md`、`templates/experiment-plan.md`，playbook 点名的 `references/batch-authorization.md`，并只读探测工作区根、`research-log.md` 与既有 TOY 材料；**剩余预算**：只读，300s 内。

**本动作范围**：只读列举 `fixtures/`（既有 TOY 材料与旧交付结果）与只读核实 git tip `5efd2daf…`；**剩余预算**：只读，300s 内。

**本动作范围**：只读核实安装源 tip 载体（父目录、`skills-lock.json`）并搜索 TOY 的 sum/for 相关既有材料；**剩余预算**：只读，300s 内。

**本动作范围**：只读核实安装源 tip（`source/.git`）与既有 TOY 交付的授权/日志格式；**剩余预算**：只读，300s 内。

**本动作范围**：只读补读入口级联示例点名的 `references/PRODUCT-MAP.md`，并核实 playbook 步骤 1 所述 `skills/validation-cycle/experiment-plan/SKILL.md` 是否存在于任一布局（路径缺口实核）；**剩余预算**：只读，300s 内。

**本动作范围**：只读核实源 tip 布局 `source/skills/validation-cycle/experiment-plan/SKILL.md` 存在，并与扁平安装叶一致性比对（确认安装未偏离 tip）；**剩余预算**：只读，300s 内。

# Research OS 编排结果（当前 tip 组合验收 · `experiment-plan` 路线）

## 一、路由与约束确认

- **当前路线：`experiment-plan`**。触发词「设计实验」命中路由表该行；用户意图是「有界计划而不是开跑」，与路线适用条件一致。
- **本轮约束叠加**：只读、无批准写域 → **仅对话输出**；不实现、不启动、不联网/外发/安装、不运行新实验、不编译、不删/覆盖。计划实体写入与 tracker 落盘均**不执行**。
- **宿主映射**：Codex；**当前会话无子代理工具**（functions 组仅 exec/写入/查看等，无 spawn_agent），故由编排者**串行**读取叶与资源，不缩减叶合同。
- **安装源 tip 实核**：`source/.git` HEAD = `5efd2daffc68612def5e4660defb68db5a7780e3`（分支 `integration/research-os-v2`，与请求 tip 逐字符一致）。
- **入口安装根实核**：`/tmp/ros-v2-release-hosts/projects/codex/.agents/skills`（扁平布局）；`research-os/` 与 `experiment-plan/` 均存在。
- **路径缺口实核**：
  - playbook 步骤 1 写的 `skills/validation-cycle/experiment-plan/SKILL.md` 在扁平安装根**不存在**（`ls` 报 `No such file or directory`），但在源 tip 树**存在**（`git ls-tree` 命中 `skills/validation-cycle/experiment-plan/SKILL.md`）；按级联规则映射到 `<安装根>/experiment-plan/SKILL.md`。
  - **一致性核对**：`diff -rq source/skills/validation-cycle/experiment-plan` 与安装叶 → **IDENTICAL**（安装未偏离 tip）。
  - 源 tip 树另有 `skills/general/research-os/…`，扁平映射为 `<安装根>/research-os/…`，已实核。
- **模型表**：`.agents/research-os-models.md` **缺失** → 按 SKILL.md「模型」节回退到当前 session 实际可用模型与 thinking，**不编造 slug**（明示回退）。同上下文自审**不**冒充 fresh 独立审查。
- **算力**：工作区根 `compute-policy.md` **缺失**（仅 `fixtures/*` 内有样例）→ 默认政策范围未指定，费用/算力/运行数/**预算均为 0，有效期 0 小时**。旧交付 `fixtures/bridge-expired/research-log.md` 是**过期批次**（`valid_until: 2020-01-01`），不得挪用。
- **读取预算消耗**：全部为只读 `exec_command`（cat/ls/diff/git read），**300s 主会话内**；fresh/build/GET/新实验预算 **0**，未触发任何写、编译、实验、联网。

---

## 二、级联清单（playbook `experiment-plan` 步骤·逐字 + 状态/证据）

> 说明：以下编号、原句、子列表**逐字抄自** `research-os/playbooks/experiment-plan.md`，仅附状态与证据定位，不压缩。

**## 步骤**

**1.** 读 `skills/validation-cycle/experiment-plan/SKILL.md` 全文，并读它点名的 references 与 templates。计划内容、阶段和产出以该正文为准。不在这里重写科研流程。

- 状态：**completed**
- 证据：叶全文已读（`experiment-plan/SKILL.md`，源路径已实核且与安装一致）；点名资源已读：`experiment-plan/references/block-checks.md`、`experiment-plan/templates/experiment-plan.md`。

**2.** 只读本次相关材料。未知项标缺口，不补预算数字。

- 状态：**completed**（只读；未知项见第六节，均标「缺口」，未补数字）
- 证据：`fixtures/toy-reviews.md`、`fixtures/bridge-expired/{EXPERIMENT_PLAN.md,candidate.py,evaluator.py,data.csv,compute-policy.md,research-log.md}`、`fixtures/proof/round-1/*`（toy 命题/审查/修复既有结果）、`fixtures/general|ml|systems/*`（旧交付样例）、`skills-lock.json`；工作区根无 `research-log.md`/`compute-policy.md`（MISSING）。

**3.** 计划达到「可供执行授权」前，按 [批次授权](../references/batch-authorization.md) 列出本批字段，请用户确认。确认的是这一批，不是工作区默认 `compute-policy.md`。

- 状态：**blocked（条件未触发）**
- 证据：`research-os/references/batch-authorization.md` 已读全文；本次计划**未达「可供执行授权」**（数据/评估器/预算/正确性定义均缺），按 `## 停止` 不进入本批字段确认。所需字段清单（scopo…见 batch-authorization）作为**待补参考**列出，非确认请求。

**4.** 用户确认本批后，把确认原文、时刻和全部字段写入工作区 `research-log.md` 的新段落。authorization_status 写「本批已确认」。默认政策额度保持 0，不抄进这条授权。

- 状态：**not started（blocked）**
- 证据：无用户本批确认，且无写域 → 未写 `research-log.md`（工作区根本无此文件）。旧 `fixtures/*/research-log.md` 为过期样例，不作为本批授权。

**5.** 只把计划和 tracker 写到用户允许的路径。已有计划文件先展示差异。删除或覆盖既有实验结果时停，等另一次明确批准。

- 状态：**completed（以「仅对话、零写入」满足）**
- 证据：无允许路径 → 未创建/未覆盖任何文件；工作区根无 `EXPERIMENT_PLAN.md`/`EXPERIMENT_TRACKER.md`（find 仅命中 `fixtures/bridge-expired/EXPERIMENT_PLAN.md` 旧样例，未触碰）。

**6.** 交付计划后停止。本路线不启动实验，不把本批确认交给 bridge 自动开跑。

- 状态：**completed**
- 证据：本回复交付 BLOCKED 草稿后停止；未启动实验、未进入 bridge。

**## 停止**

计划未达到可授权时，交付标了缺口的草稿并停止，研究日志不写运行许可。用户拒绝本批确认时，保留已有材料，不写 authorization_status。

- 状态：**completed（命中「计划未达到可授权」分支）**
- 证据：交付本 BLOCKED 草稿并停止；未写研究日志运行许可；未写 authorization_status。

---

## 三、首次补漏对照（逐字比对原文后）

- 步骤 1–6 编号与句子、`## 停止` 两句：**已逐字比对 `experiment-plan.md`，无遗漏、无改写**。
- 顺带核对了入口 SKILL.md「级联」节点名的 Markdown 链接示例清单：本路线实际点名资源仅叶 references/templates 与 `references/batch-authorization.md`，均已读全文；`references/PRODUCT-MAP.md` 亦为确认路线与服务对象而读全（**非**本路线步骤资源）。
- 结论：**清单齐备，无补漏项**。

---

## 四、叶 workflow 执行证据（`experiment-plan/SKILL.md` 全文已读）

- **Gate：`output-path | before=plan-write | approval=explicit-user`** → 无写域/未授权，**不落盘**，改走「默认在对话返回草稿」。
- **Planning constants**：MAX_PRIMARY_CLAIMS=2、MAX_CORE_BLOCKS=5、MAX_BASELINE_FAMILIES=3、DEFAULT_SEEDS=3（本次为确定性 toy，seeds 见第五节说明）。
- **Phase 0**（读 Proposal 上下文）：无提案/评审/refinement 材料，从用户 prompt 派生 → **已列明问题、输入、约束、缺口**。
- **Phase 1**（冻结 Claims 与评价面）：已起草 Claim Map 与两个不重叠边界；**候选可改范围 vs 固定评价面绑定不足 → 判为 blocker**。
- **Phase 2**（实验故事线）：保留 2 个 block；simplicity check 走 `block-checks.md`；frontier necessity **按规则跳过**（非 frontier 方法）。
- **Phase 3**（逐 block 规格 + 逐 criterion evidence）：字段已填可确定部分，其余标缺口；`references/block-checks.md` 已读全文。
- **Phase 4**（执行顺序）：产出 M0–M4 里程碑与 baseline-first 依赖；预算算式因缺上限 → **不可执行**。
- **Phase 5**（写产出并停止）：已读 `templates/experiment-plan.md` 全文，按其章节在对话内填充；未写 `experiment-plan`/tracker 文件。

---

## 五、交付：BLOCKED 草稿计划（仅对话，未落盘）

> 模板依 `templates/experiment-plan.md`；逐条标注「缺口 / 待决策人」。
> 图例：`[缺口]` = 需要用户提供或批准；`[已给定]` = 用户 prompt 或只读实核。

```
# Experiment Plan — TOY：sum vs for 正确性等价

**Problem / Hypothesis**：对同一冻结的本地整数序列 S，`sum(S)` 实现与手写 for 累加实现在
输出数值上是否等价（正确性）。机制：两者都做算术求和；预期方向：在明示取值域内逐例相等；
可反驳条件：存在 s∈S 或边界用例使两者输出不等、或其中之一抛错/给出不同值。
**[已给定问题；机制与取值域部分待确认]**

**Method Thesis**：一个最小正确性等价 toy——对同一冻结整数序列的两个求和实现，
以固定参考 oracle 判定输出一致性。
**Date**：2026-10-03
**Inputs**：用户 prompt（TOY，本轮只读）；只读参考材料：fixtures/bridge-expired（旧 TOY 矩阵交付：plan/candidate/evaluator/data/log）、
fixtures/toy-reviews.md（INTERNAL TOY review）、fixtures/proof/*（toy 求和命题既有审查结果）。
**已知事实 vs 假设**：已知=这是 TOY、无数据/评估器/批准预算；假设=「同一本地整数序列」指单一冻结输入。
**Planning status**：blocked draft — 不表示执行已授权，也不表示可执行。
**Output scope**：conversation only（无写域）。
```

### Claim Map

| Claim | Why It Matters | Anti-claim / Falsifying Observation | Minimum Convincing Evidence | Linked Blocks |
|---|---|---|---|---|
| C1（primary）：S 上 `sum` 与 `for` 输出**数值等价** | toy 的核心正确性命题 | 存在任一 s 使两者输出不等 | 冻结 S 上逐例输出与固定 oracle 相等并留存 | B1 |
| C2（supporting）：等价结论对**边界/退化**输入成立（空序列=空和 0、单元素、全负、含 0、长度边界、整型溢出边界） | 防止只在平凡输入上成立 | 某退化输入下两者不等或抛错 | 边界子集逐例相等并留存 | B2 |

- **[缺口]**：「正确性」是「两实现彼此相等」还是「与独立 oracle 相等」未定 → 待决策人=用户。

### Fixed Evaluation and Candidate Scope

- 候选文件/组件与允许超参（existing vs proposed）：**[proposed，未创建]** `candidates/sum_impl.py`（内置 `sum`）与 `candidates/for_impl.py`（`for` 累加）；**均为提议路径，未授权**。
- 允许的未来结果位置：**[缺口]** 未指定写域。
- 固定数据集版本/划分/预处理/真值来源：**[缺口]** 未提供整数序列 S 及其生成规则；**真值 oracle 未指定**（候选闭式 n(n+1)/2？Python 内置？外部权威值？）。
- 固定评估器/指标定义、方向、单位、聚合：**[缺口]** 未定义（逐例相等 / MAE / 其它）。
- 固定选择规则、seeds/配对、比较预算：确定性程序，**seeds = N/A（不适用，需显式声明）**；比较预算 **[缺口]**。
- 评估所有者、候选实现者与访问隔离：**计划职责边界，非强制隔离**（项目内无实际访问分离）。
- 协议缺陷/变更处理：评估器缺陷需**停止受影响比较**并对齐新协议，旧结果保留为不可比。

### Paper Storyline（本 toy 用 core/supplementary 语义）

- Main（core）必证：C1 等价成立。
- Appendix（supplementary）可支持：C2 边界鲁棒性。
- 有意删去及理由：额外求和策略（`math.fsum`/`reduce`/numpy）——**simplicity check**：toy 只需两实现最小对照，超建项裁剪（见 `block-checks.md`「Simplicity check」）。
- Frontier primitive：**无/明确不主张** → **frontier necessity check 跳过**（`block-checks.md` 规则）。

### Experiment Blocks

#### B1: 正常序列等价（Main）
- Claim tested：C1
- Why：核心正确性对照
- 竞争解释与可区分预测：两实现差异只在边界出现（预测 B1 全等、B2 才可能不等）vs 处处等价
- Dataset/split/task：**[缺口]** 冻结整数序列 S 未提供
- Compared systems：`sum` 实现 vs `for` 实现（baseline family：**[缺口]** 参考 oracle 未定）
- Metrics：决定性=逐例输出相等；次要=**[缺口]**
- Setup（backbone/冻结/超参/预算/seeds）：纯本地整数程序；seeds N/A；预算 **[缺口]**
- Success criterion（效应量/不确定性/范围）：**[缺口]** 未预specify
- Failure interpretation：valid negative（某例不等 → 限制 C1）/ inconclusive / invalid（评估器缺陷）/ operational failure（崩溃）——**需预specify区分规则**
- Table/figure target：**[缺口]**（报告即足，无 paper 目标）
- Priority：**MUST-RUN**（若获授权）

#### B2: 边界/退化（Main）
- Claim tested：C1/C2
- Why：确认结论不被退化输入破坏
- 竞争解释与可区分预测：差异来自空序列/溢出等边界
- Dataset/split/task：**[缺口]** 边界子集需冻结
- Compared systems：同 B1
- Metrics：同 B1
- Setup：同 B1
- Success criterion：**[缺口]**
- Failure interpretation：同 B1
- Table/figure target：**[缺口]**
- Priority：**MUST-RUN**（若获授权）

### Criterion Evidence Map
（planned 位置为**提议**，非既有证据；文件存在不等于 criterion 成立。）

| Criterion | Claim / Block | Run IDs and Comparison | Required Primary Evidence / Location / Field | Decision Rule | Existing / Not Collected |
|---|---|---|---|---|---|
| K1 等价 | C1 / B1 | 提议 §（见 tracker） | 提议 results/*.json `prediction` 字段 | 逐例全等 | **not collected** |
| K2 边界 | C2 / B2 | 提议 § | 提议 results/boundary.json | 逐例全等 | **not collected** |
| K3 baseline 有效 | oracle | — | 提议 oracle 版本/来源记录 | oracle 自身可核 | **not collected（oracle 未定）** |
| K4 预算合规 | 全部 | — | 提议 research-log 授权段 | 实际 ≤ 授权 | **not collected（预算未知）** |

### Run Order and Milestones

| Milestone | Goal | Runs | Decision Gate | Cost / Turnaround | Risk / Mitigation |
|---|---|---|---|---|---|
| M0 | sanity | 数据管道/指标正确性 + toy split | 数据与指标有效才能进 M1 | **[缺口]** | sanity 设计未授权 → 按叶 Phase 4 改用既有协议检查或阻塞 |
| M1 | 未改动 baseline（参考 oracle） | 复现最强参考 | 有效可比原始证据才能进 M2 | **[缺口]** | baseline 失败则阻塞主运行 |
| M2 | main 等价比较 | B1 | — | **[缺口]** | — |
| M3 | 决定性消融（边界） | B2 | — | **[缺口]** | — |
| M4 | polish | N/A | — | 0 | 裁剪 |

- **baseline-first**：候选运行需同一评价面上有有效 baseline；**当前 oracle 未定 → M1 阻塞 → 整体不可执行**。

### Compute and Data Budget
- 资源假设 vs 实际批准上限（分列）：**[缺口]**；默认政策未配置 → **0**。
- 总估 GPU/CPU 小时与算式：**[缺口]**
- 总运行数、seeds、retries（失败attempt计入）：**[缺口]**
- 单/总 wall-time 上限（含启动与评估）：**[缺口]**
- 内存/存储上限：**[缺口]**
- 数据准备与访问/许可缺口：**[缺口]**（S 未提供）
- 人工评估：N/A（确定性）
- 费用上限与远程/付费 API：**0**（TOY，本地）
- 最大瓶颈：缺少冻结数据 + 缺 oracle
- 停止条件、未来作业停止权、未批准动作：见 batch-authorization「硬停」
- must-run 可行性：**不可行**（缺上限与 oracle）

### Statistical and Validity Plan
- 采样单位/配对/seeds/不确定性：确定性；seeds=**[N/A]**；如以多次重跑计抖动则不适用
- 调参 vs 留出：不涉及
- 证据留存（含失败/缺失/无效）：**保留全部 attempt，缺失指标保持缺失，不记 0**
- 负证据边界与未测项：不等 → valid negative 限制 C1；崩溃 → operational failure 非科学反驳

### Risks and Mitigations
- [风险] S 未提供（无数据）→ [缓解] 用户提供冻结序列及边界集合
- [风险] oracle 未定 → [缓解] 用户指定参考真值来源
- [风险] 「正确性」定义歧义 → [缓解] 用户冻结评估器/指标
- [风险] 预算未知（默认政策 0）→ [缓解] 若执行需另行本批授权，不由默认政策授权
- [未决决策，受影响 block，决策人]：以上四条，影响 B1/B2，决策人=用户

### Final Checklist
- [ ] Main/core 对照覆盖
- [ ] novelty 以可区分对照隔离 — **N/A（toy）**
- [ ] simplicity 已辩护或说明不适用 — 已说明（裁剪超建变体）
- [ ] frontier 贡献已辩护或明确不主张 — 明确不主张（跳过）
- [ ] nice-to-have 与 must-run 分离
- [ ] 每条 criterion 有主证据要求与判定规则
- [ ] 候选范围与固定评价面不重叠
- [ ] sanity 与有效 baseline 门控候选运行
- [ ] tracker 合计、硬上限、负向解释、阻塞一致

---

```
# Experiment Tracker（对话内分节，非独立文件）

| Run ID | Milestone | Purpose/Criterion | System/Variant | Split/Seed | Metrics | Priority | Status | Planned Raw Evidence/Notes |
|---|---|---|---|---|---|---|---|---|
| R001 | M0 | sanity / K? | pipeline+metric check | N/A | — | MUST | BLOCKED | 设计未授权 |
| R002 | M1 | baseline/oracle / K3 | 参考 oracle | N/A | 输出值 | MUST | BLOCKED | oracle 未定 |
| R003 | M2 | C1/B1 | sum vs for | S | 逐例相等 | MUST | NOT RUN | results/*.json |
| R004 | M3 | C2/B2 | sum vs for | 边界子集 | 逐例相等 | MUST | NOT RUN | results/boundary.json |

## Handoff
- Must-run blocks：B1、B2（均需先解阻塞）
- Highest-risk assumption：存在单一「本地整数序列」且两实现应逐例相等
- First three proposed runs：R001(sanity) → R002(参考 oracle) → R003(等价比较)
- Plan/tracker paths：仅对话草稿，未落盘
- Outstanding authorization/blockers：写域未批准；数据/oracle/评估器/预算四缺口
- 未启动实验、未配置环境。Stop here.
```

- **未启动实验、未配置环境；执行需用户另行授权。**

---

## 六、缺口总览与待决策项（供下一次确认）

1. **数据**：冻结整数序列 S 与边界集合——**未提供**。
2. **Evaluator**：「正确性」判定（两实现互等 vs 对 oracle）与指标——**未定义**。
3. **Oracle/真值来源**：闭式 `n(n+1)/2` vs 内置 `sum` vs 外部权威值——**未指定**。
4. **批准预算**：默认政策未配置（0），无本批授权；token/fresh/build/GET/新实验预算均 0——**未授权**。
5. **写域**：未批准 → 未创建 `EXPERIMENT_PLAN.md`/`EXPERIMENT_TRACKER.md`/`research-log.md`。

**停止声明**：按 `experiment-plan` 路线 `## 停止`——计划未达可授权，交付本 BLOCKED 草稿并停止；研究日志未写运行许可；未启动实验、未落盘、未联网/外发/安装、未编译；无 fresh 独立 review（旧 `fixtures/proof` 审查为既有结果，未冒充新审查）。