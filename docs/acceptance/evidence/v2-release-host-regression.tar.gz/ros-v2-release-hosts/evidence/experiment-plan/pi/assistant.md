当前路线：**experiment-plan**。本轮只读取已安装 playbook、叶 skill 与适用模板，在对话中生成 TOY 待确认计划；不写文件、不实现、不启动实验、不联网或委派。剩余预算：主会话本轮至多 300 秒（从现在起计）；fresh / build / GET / 新实验均为 0。

下一动作仅核实安装路径并读取 `experiment-plan` playbook。


### 对话 todolist（逐项对照 playbook 原文，6 项齐全，无子列表遗漏）

1. 读 `skills/validation-cycle/experiment-plan/SKILL.md` 全文，并读它点名的 references 与 templates。计划内容、阶段和产出以该正文为准。不在这里重写科研流程。  
   **状态：in-progress**；证据：已读 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/playbooks/experiment-plan.md`，下一步核实扁平安装叶路径。
2. 只读本次相关材料。未知项标缺口，不补预算数字。  
   **状态：pending**
3. 计划达到「可供执行授权」前，按 [批次授权](../references/batch-authorization.md) 列出本批字段，请用户确认。确认的是这一批，不是工作区默认 `compute-policy.md`。  
   **状态：pending**
4. 用户确认本批后，把确认原文、时刻和全部字段写入工作区 `research-log.md` 的新段落。authorization_status 写「本批已确认」。默认政策额度保持 0，不抄进这条授权。  
   **状态：blocked**；证据：用户未批准本批执行，且无写域。
5. 只把计划和 tracker 写到用户允许的路径。已有计划文件先展示差异。删除或覆盖既有实验结果时停，等另一次明确批准。  
   **状态：blocked**；证据：用户要求仅对话输出，不创建任务文件。
6. 交付计划后停止。本路线不启动实验，不把本批确认交给 bridge 自动开跑。  
   **状态：pending**

下一动作范围：只读叶正文与批次授权规则；不执行代码。剩余预算：主会话仍在本轮 300 秒上限内；fresh / build / GET / 新实验均为 0。


已核实叶文件实际存在于扁平安装路径 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/experiment-plan/SKILL.md`，正文已完整读取；批次授权规则也已完整读取。关键数据、固定 evaluator 与未来硬预算均缺失，因此只交付 **BLOCKED／待补全，不可执行** 草稿，不进入确认记账或落盘。

下一动作范围：只读该叶点名的 `references/block-checks.md` 和 `templates/experiment-plan.md`，不扫描原项目、不运行 Python 或 probe。剩余预算：主会话仍受本轮 300 秒上限约束（不虚报精确余秒）；fresh / build / GET / 新实验均为 0。


# TOY 实验计划与 Tracker

**状态：BLOCKED／待补全，不可执行。**  
仅规划同一本地整数序列上 `sum` 与 `for` 的正确性比较；不比较速度，不声称算法创新，不扩展为完整科研流程。

已完整读取并核实实际安装文件：

- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/playbooks/experiment-plan.md`
- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/experiment-plan/SKILL.md`
- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/experiment-plan/templates/experiment-plan.md`
- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/experiment-plan/references/block-checks.md`
- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/references/batch-authorization.md`

来源 tip `5efd2daffc68612def5e4660defb68db5a7780e3` 是**用户提供的来源标识，本轮未独立核验提交身份**。本轮串行读取，无子代理、无 fresh review；以下是规划，不是独立审查结论。

## 1. 问题、输入与假设

| 项目 | 内容与性质 |
|---|---|
| Problem / Hypothesis | 在同一个固定本地整数序列上，`sum` 与从零开始的 `for` 累加均得到独立确定的正确总和。**待确认假设**。 |
| Method Thesis | 用同输入、同 ground truth、固定 evaluator 的配对比较检验正确性，而不是只检查两种实现互相相等。 |
| Inputs | 本轮用户消息；没有提供数据、evaluator、既有结果或执行授权。 |
| Date | 本轮规划；未读取系统时钟，不填写伪造日期。 |
| Dominant contribution | TOY 正确性验证；无新方法或 supporting contribution。 |
| Critical concerns | 两者可能共同出错；输入可能被改变；类型、初值和 evaluator 定义可能不一致。 |
| 环境 | 实际 Python 版本、已有实现与运行入口未核实；未来若获准运行 Python，必须使用 `uv run python`。本轮没有运行 Python。 |
| Frontier primitive | 无；不使用 LLM / VLM / Diffusion / RL 实验组件。 |
| Output scope | **仅对话草稿，未落盘**；无代码、数据、evaluator 或结果写域。 |

**拟议类型范围，待用户确认：**Python 内置 `int` 的有限序列，排除 `bool`、浮点数、NumPy 定宽整数及自定义数值类型。若实际类型不同，必须重新明确协议，不能默认为同一实验。

## 2. Claim Map

| Claim | Why It Matters | Anti-claim / Falsifying Observation | Minimum Convincing Evidence | Linked Blocks |
|---|---|---|---|---|
| C1：两种实现对固定序列均返回正确总和 | 检验指定 TOY 输入上的正确性 | 反解释：两者相等只是共享错误或共享错误 oracle。反驳观察：任一有效输出与独立总和不同 | 固定序列身份、独立总和及其依据、有效 evaluator、两种实现的原始输出、输入未变证据 | B1 |

仅一个主要 claim。**即使通过，也只支持该固定序列；不能证明对所有整数序列正确。**

## 3. Fixed Evaluation and Candidate Scope

### 候选范围

- 比较对象：拟议的 Python 内置 `sum`；拟议的从整数 `0` 开始、逐元素累加的 `for`。
- 现有实现文件：**未提供**。
- 未来允许实现或修改的精确路径：**未指定，阻塞 R002/R003**。
- 超参数及优化：不设搜索；不允许看到最终结果后改变初值、输入、类型或选择规则。
- 未来原始结果位置：**未指定，阻塞全部 runs**。
- 本轮允许写域：无。上述候选未实现、路径未创建。

### 固定评价面

| 字段 | 拟议协议／缺口 |
|---|---|
| 数据版本与任务 | 一个用户提供的本地有限整数序列；实际内容、版本标识、长度、顺序及读取方式均缺失 |
| Split | 无训练集；固定序列作为 final evaluation。Sanity 使用另行确认的已知答案 fixture，不混入最终证据 |
| 预处理 | 拟议无转换、过滤、截断、排序或去重；读取后的值及顺序必须保持一致 |
| Ground truth | 用户提供独立确认的整数总和与可审计依据；不能用被测 `sum` 或 `for` 自己定义标签 |
| Evaluator | 实际 evaluator、版本与公共协议缺失；拟议检查输出类型、精确相等及输入完整性 |
| 决定性指标 | `correct(system) = 1` 当且仅当有效整数输出等于独立总和，否则为 `0`；方向越大越好，无单位 |
| 辅助指标 | `agreement = [sum_output == for_output]`；只能诊断，不能替代正确性 |
| 聚合 | 分别报告两个系统；C1 通过须两者均正确，不用平均值掩盖一方失败 |
| Pairing / seeds | 同一个固定输入配对；在拟议确定性协议下无随机 seed，重复运行不作为独立样本 |
| Selection | 两个系统预先固定，无调参、无挑选最佳结果 |
| Comparison budget | 拟议 3 个 planned runs，**不是获准运行数** |
| 责任边界 | 用户确认固定数据、oracle、协议及授权；未来实现者仅处理候选。实际访问隔离未核实，当前只是责任边界，不是已强制隔离 |
| 协议缺陷 | 停止受影响比较，请用户批准新协议；全部系统在新协议下重新评价，保留旧结果并标为不可直接比较 |

## 4. Paper Storyline／证据主线

- **Core evidence：**B1——两种实现分别对照独立总和，并保留同输入证据。
- **Supplementary evidence：**失败时基于已有原始输出分类，不追加运行、不改变序列。
- **Cut：**
  - 新颖性隔离：没有新机制 claim；正确性对照已包含在 B1。
  - Simplicity block：不主张简洁性收益，无需构建 overbuilt variant。
  - Frontier necessity block：无 frontier 方法。
  - 性能、随机序列、多类型、全域泛化与额外消融：超出本次问题及零执行预算。

## 5. Experiment Blocks

### B1：同序列、独立 oracle 的正确性比较 — MUST-RUN（未来拟议）

- **Claim tested：**C1。
- **Why：**两种实现互相相等不足以证明正确，必须分别对照独立答案。
- **竞争解释与区分预测：**
  - 两者正确：两输出均等于独立总和。
  - 共享错误：两者相等但均不等于独立总和。
  - 实现特异错误：仅一方不等于总和。
  - 协议无效：oracle 不可靠、输入变化或 evaluator 错误，不能判断 C1。
- **Dataset / split / task：**固定序列 final evaluation；数据缺失。Sanity fixture 单独标识并排除于最终结果。
- **Compared systems：**`sum` 作为不变 baseline；从零累加的 `for` 作为比较对象。没有额外 baseline family 或 ablation。
- **Metrics：**首先报告两个 `correct`；其次报告 `agreement` 与输入完整性。
- **Setup：**无 backbone、训练或可训练参数；拟议无调参、无随机 seed。Python 版本、现有实现、环境、写域和预算均待绑定。
- **Success criterion：**有效协议下两者均精确正确；容许误差为 0，不采用“接近”或最佳运行。单个确定性输入不报告群体置信区间，也不推断总体正确率。
- **Failure interpretation：**
  - **Valid negative：**有效协议、输入完整、oracle 已确认，且至少一个有效输出错误；否定 C1 在该序列上的断言。
  - **Inconclusive：**关键输出或 oracle 依据缺失，无法判定；不得当作正确或负结果。
  - **Invalid：**评价协议错误、输入不一致、结果来源不可信。
  - **Operational failure：**异常、崩溃、超时、内存失败；不是科学反驳。
  - Baseline 失败先阻塞候选运行；只报告已经取得的证据，不假称完成配对比较。
- **Table target：**未来报告中“系统—输入标识—预期总和—实际输出—正确性—有效性”表；实际位置待授权。

## 6. Criterion Evidence Map

以下都是**未来证据要求，尚未采集**。报告字段是逻辑定位，不是已存在文件或获准写入路径。

| Criterion | Claim / Block | Run IDs and Comparison | Required Primary Evidence / Field | Decision Rule | Existing Evidence / Gap |
|---|---|---|---|---|---|
| K1 数据与 oracle 有效 | C1 / B1 | R001；R002/R003 引用同协议 | 序列标识、长度、完整性记录、独立总和及来源依据 | 数据身份一致且 oracle 经用户确认 | 未采集；数据、oracle 缺失 |
| K2 evaluator 有效 | C1 / B1 | R001 | 已知正确／错误 fixture 的预期与实际判定、协议版本 | 正确答案被接受，错误答案被拒绝；不混入 final 结果 | 未采集；evaluator、fixture 缺失 |
| K3 baseline 有效且正确 | C1 / B1 | R002 vs oracle | 配置、原始输出、输入标识、类型、退出状态、`correct` | K1/K2 有效且 baseline 精确正确，方可放行 R003 | 未采集；实现与环境未绑定 |
| K4 候选正确／C1 成立 | C1 / B1 | R003 vs oracle；配对 R002 | 候选配置、原始输出、输入前后完整性、两个 `correct`、`agreement` | 两者均正确且协议有效 | 未采集；候选路径缺失 |
| K5 授权及预算合规 | 全部 runs | R001–R003，每个 attempt | 批次授权、预留、实际起止时间、退出码、费用／算力／存储记录 | 每次启动前及累计均不越界；缺失消耗不能当 0 | 未授权；未来上限与证据写域缺失 |

## 7. Run Order and Milestones

| Milestone | Goal | Runs | Decision Gate | Cost / Turnaround | Risk / Mitigation |
|---|---|---|---|---|---|
| M0 | Sanity：数据及 evaluator 协议有效 | R001 | 数据、oracle、fixture、evaluator 与授权全部就绪；否则停止 | 未估；硬限未批准 | evaluator 自证／用独立已知答案；此 run 不作 final 结果 |
| M1 | 不变 baseline | R002 | R001 有效；baseline 原始证据有效且正确后进入 M2 | 未估；硬限未批准 | baseline 无效或错误／停止，不围绕错误 baseline 优化 |
| M2 | 主比较对象 | R003 | 同评价面、同输入、授权仍有效 | 未估；硬限未批准 | 输入变化／完整性记录；无效则停止 |
| M3 | 决策 | 无新增 run | 仅依据 K1–K5 判定 C1 | 分析工时待定 | 误把相等当正确／分别对照 oracle |
| M4 | Polish | Cut，无 run | 不扩展本次范围 | 不安排 | 防止新增变体、性能测试或自动循环 |

**Must-run：**R001–R003。**Nice-to-have：**无；额外工作全部删去。

## 8. Compute and Data Budget

- **当前获准范围：**本轮一次主会话、300 秒上限，只读与对话规划；fresh / build / GET / 新实验预算均为 **0**。
- **未来预算：**未批准、未估实耗；不能把本轮主会话时限充作实验 wall-time 授权。
- **拟议运行数算式：**1 sanity + 1 baseline + 1 candidate = **3 planned runs**；无随机 seeds。重试未获准，不安排重试。
- **未来 CPU 算力估算式：**各 attempt 的 `核数 × 总 wall-seconds ÷ 3600` 相加；核数及时间未知，不能填写数值。
- **GPU：**拟议不使用；仍须在未来授权中明确。
- **单次／累计 hard limits：**wall-time、CPU-core-hour、内存、存储、数据准备时间及人工工时均待确认。Wall-time 应包括启动、评价及收尾。
- **存储核算：**必须确认原始数据、已有缓存和新证据哪些计入上限；不得擅自清理旧材料。
- **费用／外部资源：**方案不需要联网、付费 API、安装或外发；未来费用上限与币种仍须明确确认，不自行记成已批准。
- **失败计费：**失败、无效、超时 attempts 都计入算力、费用及 attempt 历史；剩余额度不自动允许重试。
- **未来停止权限：**拟议由用户及指定执行者在触及硬门时停止作业；责任人、方式与权限待确认，本轮未停止任何作业。
- **Feasibility：**3 个拟议 runs 无法纳入当前 **0 新实验**额度。因此计划不可执行，不缩掉独立 oracle 或 sanity 来绕过授权门。

### 本批授权字段：仅列缺口，不形成授权

| 字段 | 当前状态 |
|---|---|
| `scope` | 未来计划版本、精确写域、环境未指定 |
| `cost_limit`, `currency` | 未批准 |
| `compute_limit`, `compute_unit` | 未批准；拟议 CPU 使用 `cpu-core-hour` |
| `run_limit`, `run_count_basis` | 未批准；拟议 3，basis 为 `planned-run` |
| `per_attempt_cost_limit`, `per_attempt_compute_limit` | 未批准 |
| `concurrency_limit`, `retry_limit` | 未批准；本草稿不安排并发或重试 |
| `valid_for_hours`, `valid_until` | 未批准 |
| `batch_id`, `plan`, `mode` | 未绑定未来执行批次；当前只有对话计划 |
| `user_confirmation`, `confirmed_at`, `confirmation_basis` | 无执行确认，不伪造时间或引用 |
| `authorization_status` | **未授权**；没有写入研究日志 |

此时只需确认缺口，不请求“立即开跑”。默认政策不会被当成本批授权。

## 9. Statistical and Validity Plan

- Sampling unit 是**固定序列**；两个系统配对，没有独立随机样本。
- 不训练、不调参、不选 best seed；sanity fixture 与 final 序列分开。
- 最终比较只适用于这个序列；精确结果没有测量误差不等于不存在外推不确定性。
- 保留全部未来 attempts 的原始输出、错误与状态；缺失指标保持缺失，不填 0。
- 协议变更须用户批准，新旧结果分开；事后诊断标为 exploratory。
- 负结果只限制 C1 在指定序列上的成立；不说明所有输入都会失败，也不证明另一实现普遍正确。

## 10. Risks and Unresolved Decisions

| 缺口 | 影响 | 所需材料／决定人 |
|---|---|---|
| G1 数据未提供 | R001–R003 | 用户提供本地序列、来源、版本及读取许可；确认类型范围 |
| G2 独立总和与 evaluator 未提供 | C1、K1–K4 | 用户／评价负责人确认 oracle 依据、协议及 sanity fixture |
| G3 实现与环境未绑定 | R002/R003 | 用户提供现有实现及 Python 环境信息；不因此授权安装 |
| G4 写域与证据位置未指定 | 全部 runs | 用户提供精确候选及结果路径，保留原材料和旧结果 |
| G5 未来预算与本批授权缺失 | K5、全部启动门 | 用户明确完整批次字段及 hard limits |

**最高风险假设：**所谓“独立总和”实际由某个被测实现生成，导致循环验证。

### Final Checklist

- ✓ 核心报告比较、反解释和判定规则已规划；**没有实验结果**。
- ✓ 不主张新颖性、简洁性或 frontier 贡献；对应删去理由明确。
- ✓ Must-run 与可选项分开，每个 criterion 有证据要求。
- ✓ Sanity 与有效 baseline 均是候选启动前置门。
- **BLOCKED：**候选路径、固定评价面及真实隔离尚未绑定。
- **BLOCKED：**tracker、拟议运行数一致，但未来硬限未确定；当前零实验预算不允许执行。

---

# Experiment Tracker

这是待运行清单，不是 scheduler；所有证据均 **not collected**。

| Run ID | Milestone | Purpose / Criterion | System / Variant | Split / Seed | Metrics | Priority | Status | Planned Raw Evidence / Notes |
|---|---|---|---|---|---|---|---|---|
| R001 | M0 | 数据／oracle／evaluator sanity；K1/K2/K5 | 固定协议检查，不优化候选 | 独立 sanity fixture；seed N/A | 预期／实际判定、输入完整性 | MUST | **BLOCKED — NOT RUN** | 协议版本、fixture 判定、原始日志；实际路径未授权 |
| R002 | M1 | baseline；K3/K5 | 不变 `sum` | 固定 final 序列；seed N/A | `correct(sum)`、有效性 | MUST | **BLOCKED — NOT RUN** | 配置、输入标识、实际输出、oracle、时间及消耗；实际路径未授权 |
| R003 | M2 | 配对比较；K4/K5 | 从零累加的 `for` | 同一 final 序列；seed N/A | `correct(for)`、`agreement`、完整性 | MUST | **BLOCKED — NOT RUN** | 配置、原始输出、R002 配对依据、时间及消耗；实际路径未授权 |

## Playbook todolist：最终状态

编号、原句与链接保留；该 playbook 无步骤子列表。

1. 读 `skills/validation-cycle/experiment-plan/SKILL.md` 全文，并读它点名的 references 与 templates。计划内容、阶段和产出以该正文为准。不在这里重写科研流程。  
   **completed**；证据：实际扁平安装叶正文及其模板、block checks 均已完整读取，路径见开头。
2. 只读本次相关材料。未知项标缺口，不补预算数字。  
   **completed**；证据：输入限于用户消息与上述流程资源；G1–G5 明列，没有虚构数据或结果。
3. 计划达到「可供执行授权」前，按 [批次授权](../references/batch-authorization.md) 列出本批字段，请用户确认。确认的是这一批，不是工作区默认 `compute-policy.md`。  
   **blocked**；证据：授权字段已列出，但关键缺口未补，尚未达到可供执行授权门。
4. 用户确认本批后，把确认原文、时刻和全部字段写入工作区 `research-log.md` 的新段落。authorization_status 写「本批已确认」。默认政策额度保持 0，不抄进这条授权。  
   **blocked**；证据：无本批执行确认、无写域；未写研究日志。
5. 只把计划和 tracker 写到用户允许的路径。已有计划文件先展示差异。删除或覆盖既有实验结果时停，等另一次明确批准。  
   **blocked**；证据：用户仅允许对话输出；未创建、删除或覆盖文件。
6. 交付计划后停止。本路线不启动实验，不把本批确认交给 bridge 自动开跑。  
   **completed**；证据：已交付带缺口计划与 tracker；停在此处，无执行或自动交接。

## Handoff

- **Must-run block：**B1。
- **前三个 proposed runs：**R001 sanity → R002 `sum` baseline → R003 `for`；均未启动。
- **当前可供执行授权：否。**待用户确认 G1–G5，不把本轮验收约束当运行批准。
- **输出位置：仅对话草稿，未落盘。**
- **未启动实验、未配置环境；执行需用户另行授权。**