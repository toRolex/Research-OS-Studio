当前路线：**improvement**，仅做当前 tip 的只读门禁核对，不重跑科研流程。下一动作只读取已安装的 `research-os/playbooks/improvement.md` 全文；不会创建文件、联网、启动 fresh review、修复、补实验或编译。剩余授权：本轮主会话一次、300 秒上限；fresh/build/GET/新实验均为 0，写域未批准。

### 对话 todolist

以下保留 playbook 的编号、原句和子列表，仅附状态／证据。

**先读**

按路径读完：

1. `skills/writing-cycle/research-improvement/SKILL.md`  
   状态：pending。
2. `skills/writing-cycle/research-improvement/references/loop-methods.md`  
   状态：pending。
3. `skills/writing-cycle/research-improvement/references/composition-map.md`  
   状态：pending。
4. `skills/writing-cycle/research-improvement/templates/improvement-log.md`  
   状态：pending。

组合能力只在 `composition-map.md` 里点名。读那份映射，不把表抄进本文件，也不启动映射末尾列出的顶层入口。  
状态：pending。

**步骤**

1. 先过 `research-improvement` 的 loop-authorization 门。scope、写入范围、最大轮数、资源预算、副作用、正面结论标准和停止条件逐项确认。未确认的项不执行。  
   状态：in-progress；用户已声明新授权未确认，须读取叶合同核对停门。
2. 冻结基线：Claims 或草稿、方法与代码、原始结果、当前 diff、历史 findings。已有改进日志是待核实输入，不是已成立结论。  
   状态：blocked；步骤 1 尚未过门。
3. 每一轮由 fresh reviewer 直接读当前 primary artifacts。同上下文自查标成自查，不冒充独立审查。  
   状态：blocked；步骤 1 尚未过门，fresh 预算为 0。
4. 只在写入范围内做最小修复，并留下验证证据。补实验另过 experiment-topup 门；名额按 attempt 计，失败、超时、无效也占名额。重试额度不代替修复轮数。  
   状态：blocked；写域未批准，新实验预算为 0。
5. 用 `skills/writing-cycle/research-improvement/templates/improvement-log.md` 的骨架写本轮日志。原始审查回应逐字保留。日志写入用户授权的位置；没有授权时只在对话交付。  
   状态：blocked；未进入改进轮次，不创建日志文件。

**完成**

报告能对上实际读取和修改：轮次、分数轨迹、已修与未解决 findings、停止原因。达到轮数、预算、名额或正面结论后停止。不自动开始下一轮，也不自动进入投稿或新的顶层 Workflow。  
状态：pending；仅交付停门报告。

已逐项对照刚读到的 playbook：先读四项、组合限制、步骤 1–5 和完成要求均已保留，无子列表遗漏。

下一动作范围：按扁平安装映射，只读核实上述四个实际文件及全文，不进入基线或审查。剩余预算：本轮主会话仍限一次、300 秒内；fresh/build/GET/新实验均为 0，写域未批准。

## 停门结论

**当前路线：improvement。已完成授权门的只读核对，`loop-authorization` 未通过，停在步骤 1。** 不进入基线冻结、fresh review、repair 或 re-review。

### 读取证据与路径核实

实际安装根：`/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/`

以下文件均成功读取全文，未发现本次必读路径缺口：

- `research-os/playbooks/improvement.md`
- `research-improvement/SKILL.md`
- `research-improvement/references/loop-methods.md`
- `research-improvement/references/composition-map.md`
- `research-improvement/templates/improvement-log.md`

组合映射不是授权或自动调用链；本次未进入其审查、补实验或验证分支，因此未启动对应叶能力。

### 授权逐项核对

| 字段 | 当前确认情况与执行边界 |
|---|---|
| 材料 Scope | 原材料入口为 `fixtures/general/`；新循环的研究问题、材料集合、各类路径及排除项未确认。**不启动材料审查。** |
| 写入范围 | 未批准。**不执行写入，不创建任务或日志文件。** |
| 最大轮数 | 未确认。**不采用默认轮数，不启动首轮。** |
| 资源预算 | 本次门禁核对限一次主会话、300 秒；新循环预算未确认。fresh/build/GET/新实验预算均为 **0**。 |
| 外部副作用 | 已明确禁止联网、外发、安装、修改全局/main/原项目及删除/覆盖。**不执行。** |
| 补实验授权 | 未授权，名额 **0**。**不执行。** |
| 正面结论标准 | 分数阈值与 verdict 词表未确认。**不自行设定，不给出达标结论。** |
| 停止条件 | 用户明确要求授权未确认即停门。**现已触发。** |

### 对话 todolist 最终状态

**先读**四项及组合限制：completed；证据为上列全文读取。首次清单已逐项对照 playbook，编号、原句及要求无遗漏。

1. 先过 `research-improvement` 的 loop-authorization 门。scope、写入范围、最大轮数、资源预算、副作用、正面结论标准和停止条件逐项确认。未确认的项不执行。  
   **blocked**；授权核对已完成，但新循环授权未成立。
2. 冻结基线：Claims 或草稿、方法与代码、原始结果、当前 diff、历史 findings。已有改进日志是待核实输入，不是已成立结论。  
   **blocked**；未过步骤 1，未读取研究材料或冻结基线。
3. 每一轮由 fresh reviewer 直接读当前 primary artifacts。同上下文自查标成自查，不冒充独立审查。  
   **blocked**；未过授权门，fresh 预算为 0。
4. 只在写入范围内做最小修复，并留下验证证据。补实验另过 experiment-topup 门；名额按 attempt 计，失败、超时、无效也占名额。重试额度不代替修复轮数。  
   **blocked**；写域未批准，补实验名额为 0。
5. 用 `skills/writing-cycle/research-improvement/templates/improvement-log.md` 的骨架写本轮日志。原始审查回应逐字保留。日志写入用户授权的位置；没有授权时只在对话交付。  
   **blocked**；未启动轮次，无本轮审查回应或修复日志；仅在对话交付停门报告。

**完成**

报告能对上实际读取和修改：轮次、分数轨迹、已修与未解决 findings、停止原因。达到轮数、预算、名额或正面结论后停止。不自动开始下一轮，也不自动进入投稿或新的顶层 Workflow。  
**completed（仅停门报告）**；不表示改进循环已完成。

### 实际执行与边界

- **已用改进轮数：0**；未建立 Round 0 基线，无新分数或 verdict。
- **独立审查：`independent review not performed`**。未将旧审查、自查或用户陈述当作新独立 review。
- **Findings：未读取、未核实**；不能据此声称没有问题。
- **写入、修复、编译、实验、网络及远程动作：均为 0。**
- 未运行 Python、probe 或解析命令；未创建、删除或覆盖文件。
- tip `5efd2daffc68612def5e4660defb68db5a7780e3` 是用户提供的安装源标识，**本次未另行核验 Git tip**。
- wall-clock 未单独计量，不虚报耗时或剩余秒数；零预算项目仍未消耗。

**首要停止原因：新 `loop-authorization` 未成立；同时命中用户明确的停门要求。此次仅确认了读取覆盖与停门行为，不作整体安装验收通过或研究达标结论。到此停止。**