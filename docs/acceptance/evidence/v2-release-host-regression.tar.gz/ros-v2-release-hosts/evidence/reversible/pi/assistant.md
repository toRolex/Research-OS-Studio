本动作仅只读核实并读取已安装的 `research-os` 入口与 `custom` playbook，不创建任务、不联网、不委派。剩余预算：本轮一次主会话、300 秒；fresh/build/GET/新实验均为 0。唯一获准写入是新建 `outputs/inventory.md`，写后将亲自回读核对。


本动作只读 `custom` playbook 全文，确定其原文步骤。剩余预算仍限本轮主会话 300 秒内；fresh/build/GET/新实验均为 0，写域不变。


当前路线：`custom`。

### 对话 todolist（逐字保留 playbook 步骤）
1. 先确认已交付路线都不适用：不是 idea、实验计划、实验执行、论文写作、证明、审稿回复、转投、演讲、跨流程改进、续接，也不是只读推荐。已保存的证明或改进交接走 `skills/general/research-os/playbooks/pickup.md`，不在这里重新设计。
   - 状态：in-progress；证据：用户明确要求 TOY 库存专用分类，无对应科研流程。
2. 用现有材料写出有界流程：目标、输入、停止条件、允许写入的范围、不可逆停点、不做什么。
   - 状态：pending。
3. 只有两种理解会导向不同流程时才问一个问题。范围、材料或措辞不完全时，给出带条件的流程，不把缺项当成歧义。
   - 状态：pending。
4. 把流程交给用户。用户明确批准后，才按该流程执行；本文件本身不启动检索、实验、写入或子代理。
   - 状态：pending。

已逐项对照刚读取的原文：编号、原句完整，无子列表遗漏。该 playbook 没有指定执行叶 skill，不虚构叶入口。

本动作只读步骤 1 点名的 `pickup.md`（映射到实际安装目录），不启动续接流程。剩余预算：仅本轮主会话、300 秒内；fresh/build/GET/新实验均为 0；仅准新建 `outputs/inventory.md`。


清单状态更新：
- **1：completed**。这是新 TOY 分类，不是科研路线或已保存交接；`pickup.md` 已读，仅用于排除续接，不执行其流程。
- **2：completed**。有界流程如下：
  - 目标与输入：按用户给定映射 `apple → A`、`bolt → B` 生成两行正文。
  - 允许写入：仅新建 `outputs/inventory.md`；允许创建 `outputs` 目录。
  - 停止条件：目标已存在、目录是符号链接或非目录时停止，不覆盖；创建后亲自回读，核对恰好两行后交付并停止。
  - 不可逆停点：不执行删除、覆盖等动作；出现意外即停止报告。
  - 不做什么：不创建任务或附加文件，不联网、外发、安装、委派、编译或运行实验，不修改原材料、全局配置或 main。
- **3：completed**。映射、正文及写域明确，没有需要澄清的歧义。
- **4：in-progress**。流程已在此交付；用户本轮已明确批准该新建及回读，无需再次征询。

本动作检查目标不存在，并以禁止覆盖方式仅创建 `/private/tmp/ros-v2-release-hosts/projects/pi/outputs/inventory.md`（必要时创建 `outputs`）。剩余预算：本轮主会话 300 秒内；fresh/build/GET/新实验均为 0。


创建命令成功。本动作只回读实际文件 `/private/tmp/ros-v2-release-hosts/projects/pi/outputs/inventory.md`，核对两行正文；不再写入。剩余预算：本轮主会话 300 秒内；fresh/build/GET/新实验均为 0。此为主会话核验，不是 fresh 独立 review。


已新建并亲自回读核对 [`outputs/inventory.md`](outputs/inventory.md)，正文恰好两行：

```text
apple: A
bolt: B
```

Todolist 步骤 4：**completed**，证据为创建成功及实际文件回读；步骤 1–4 均已完成。未写其他文件，未联网、派 fresh、编译或运行实验。达到停止条件，本轮结束。