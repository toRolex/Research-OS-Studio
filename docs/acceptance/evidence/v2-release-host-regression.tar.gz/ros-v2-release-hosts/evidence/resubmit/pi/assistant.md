当前路线：**resubmit（转投）**。本轮只做本地、只读的流程验收，在 **adaptation-scope 门**停止；不重跑科研流程，不复制文件，不修改旧稿，也不假造官方 venue。

下一动作仅读取已安装的 `playbooks/resubmit.md` 全文并核实路径。剩余预算：主会话最多 300 秒；fresh review、build、GET、新实验均为 0。未获写域批准，所有清单和结果仅留在对话。


### 对话 todolist

1. **[in-progress]** 读 `skills/writing-cycle/resubmit-pipeline/SKILL.md` 全文。停在 adaptation-scope：用户批准新目录之前不创建、不复制、不覆盖。目标已存在、非空或指向旧稿时停止。
2. **[pending]** 按 `skills/writing-cycle/resubmit-pipeline/references/adaptation-methods.md` 锁定旧稿并在新目录适配模板。旧稿只读。规则缺失时保留未核实项。
3. **[pending]** 只读检查读 `skills/writing-cycle/paper-compile/SKILL.md`，引用检测读 `skills/writing-cycle/citation-audit/SKILL.md`。两份正文的自带门照旧生效。本步不改研究材料。
4. **[pending]** 停在 change-confirm。用户逐项决定之前零研究材料写入。编译修复与引用改写只记下待转交入口名 paper-compile-repair、apply-citation-fixes。本路线不打开它们的正文，也不执行它们；用户要做时另行点名。
5. **[pending]** 对已批准的本路线正文改动应用后，重做只读检查。报告格式用 `skills/writing-cycle/resubmit-pipeline/templates/adaptation-report.md`。
6. **[pending]** 交付新目录候选与报告。不向投稿系统提交、不上传、不发布。

已逐项对照刚读取的 playbook：六步编号和原句完整保留，原文无子列表，未发现漏项。证据：`/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/playbooks/resubmit.md`。

下一动作仅读取扁平安装布局中的 `resubmit-pipeline/SKILL.md` 全文；不进入适配或检查步骤。剩余预算：主会话 300 秒上限内；fresh/build/GET/新实验均 0，写入及复制授权为 0。


已读完 `resubmit-pipeline/SKILL.md`。其 `adaptation-scope` 门要求明确的新目录与写入许可；目前两者均未批准，因此不会创建或复制。

下一动作仅限：读取该叶引用的 `references/adaptation-methods.md` 全文，并核实 `fixtures/old-submission/` 的实际路径、目录项及符号链接；不编译、不做引用审计、不访问网络。剩余预算：主会话 300 秒上限内；fresh/build/GET/新实验均 0；写入、复制仍为 0。


已实核旧稿目录存在，实际路径为 `/private/tmp/ros-v2-release-hosts/projects/pi/fixtures/old-submission`；目录内列出 6 个文件，未发现符号链接。适配方法明确允许 venue-neutral 适配，不需要虚构官方 venue。

最后一次只读核实：读取旧稿 `paper.tex` 和 `figures/FIGURE_NOTE.md`，并计算这 6 个文件的 SHA-256 基线；不执行图脚本、不解析或编译 PDF。随后停在 adaptation-scope。剩余预算：主会话 300 秒上限内；fresh/build/GET/新实验均 0，写入与复制为 0。


## 已停在 adaptation-scope 门

**当前路线：resubmit。** 本轮仅完成入口读取与旧稿只读核实，未进入复制、适配或检查阶段。

### 已核实的范围与阻塞项

- **旧稿**：`fixtures/old-submission/` 存在，实际路径为 `/private/tmp/ros-v2-release-hosts/projects/pi/fixtures/old-submission`；共 6 个文件，未发现符号链接。已在工具输出中记录全部文件的 SHA-256 基线，未落盘。
- **材料性质**：`paper.tex` 明确标注 **EXPLICITLY TOY MATERIAL**，已有稿件为 venue-neutral LaTeX article。这里只确认材料标识，不重新验证其研究结论。
- **目标**：本地 venue-neutral 格式演练。适配方法明确支持这一模式；无官方 venue，不声称符合任何官方投稿规范。
- **阻塞项**：新目录尚未确认；新目录及报告位置没有写入授权。不得自行选址或创建候选目录。
- **实际操作**：零复制、零写入、零旧稿修改；无联网、外发、安装、Python 执行、新实验、编译或独立审查。旧图表说明中的历史检查记录不作为本轮 fresh review。
- **安装核实**：所需 playbook、叶正文及当前适用方法资源均实际存在并已读全文。你提供的源 tip `5efd2daffc68612def5e4660defb68db5a7780e3` 未另做版本一致性核验，不据此宣称已验证 tip。

### 对话 todolist（停门状态）

1. **[blocked — adaptation-scope；叶全文已读，新目录与写域未批准]** 读 `skills/writing-cycle/resubmit-pipeline/SKILL.md` 全文。停在 adaptation-scope：用户批准新目录之前不创建、不复制、不覆盖。目标已存在、非空或指向旧稿时停止。
2. **[pending — 未执行适配]** 按 `skills/writing-cycle/resubmit-pipeline/references/adaptation-methods.md` 锁定旧稿并在新目录适配模板。旧稿只读。规则缺失时保留未核实项。
3. **[pending — 未读取本步叶正文，未运行检查]** 只读检查读 `skills/writing-cycle/paper-compile/SKILL.md`，引用检测读 `skills/writing-cycle/citation-audit/SKILL.md`。两份正文的自带门照旧生效。本步不改研究材料。
4. **[pending]** 停在 change-confirm。用户逐项决定之前零研究材料写入。编译修复与引用改写只记下待转交入口名 paper-compile-repair、apply-citation-fixes。本路线不打开它们的正文，也不执行它们；用户要做时另行点名。
5. **[pending]** 对已批准的本路线正文改动应用后，重做只读检查。报告格式用 `skills/writing-cycle/resubmit-pipeline/templates/adaptation-report.md`。
6. **[pending]** 交付新目录候选与报告。不向投稿系统提交、不上传、不发布。

证据文件均位于安装根 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/`：
- `research-os/playbooks/resubmit.md`
- `resubmit-pipeline/SKILL.md`
- `resubmit-pipeline/references/adaptation-methods.md`

**本轮验收到此停止，不继续后续步骤。**