本次仅做既有 ML 交付的只读验收：不联网、不写文件、不编译、不运行实验，不生成 PDF 渲染文件；所有 Python 均用 `uv run python`。剩余预算：新 fresh / build / GET / 实验各 0，主会话限 300 秒。

下一动作只读取已安装入口和 ML playbook，确认续验路线及步骤；不会启动完整流程。


当前路线保持 `paper-writing / ml`，仅核验既有最终交付，不重跑写作流程。下一动作只读该 playbook 并列出实际 fixture 文件，以定位原批准、最终反馈和 PDF 绑定记录；剩余新 fresh / build / GET / 实验均为 0。


对话 todolist（逐字保留 playbook 步骤；本轮只验证既有产物，未授权部分不执行）：

1. 读 `skills/writing-cycle/ml-paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。补实验不在本次授权内。  
   **[in-progress]** 安装映射已实核：`.pi/skills/ml-paper-writing/SKILL.md`。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/ml-paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。  
   **[pending]**
3. ML 专属纪律读全文：
   - `skills/writing-cycle/ml-paper-writing/references/experiment-reporting.md`
   - `skills/writing-cycle/ml-paper-writing/references/reviewer-expectations.md`
   - 用户指定 venue 时读 `skills/writing-cycle/ml-paper-writing/references/venue-checklists.md`  
   **[pending]**
4. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`  
   **[pending]** 仅按当前续验范围读取，不启动旧流程。
5. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。  
   **[pending]**

首次清单已逐项对照刚读取的原文，编号、原句及子列表无遗漏。当前目录不是 Git 仓库，故无法由此处 `git rev-parse` 核实源 tip；不会把用户给定 SHA 当成已经实核。

下一动作只读叶全文、组合映射及实际稿件/CSV/canonical/构建记录。剩余新 fresh / build / GET / 实验均 0；不写文件。


已亲自读完当前主稿和五行 CSV。`canonical.md` 共 4716 行，首次返回仅到第 486 行，尚未读完；其开头仍指向旧 build-1，不能据此判断当前 PDF。下一动作只读 ML 纪律、七个适用叶及 canonical 标题定位，随后读取原始最终反馈和追加批准。剩余新 fresh / build / GET / 实验 / 修订均 0。


安装源仓库 HEAD 已实核为 `5efd2daffc68612def5e4660defb68db5a7780e3`。七个适用叶全文已读；未指定 venue，无定理/引理/证明，两个条件分支不适用。当前只有主会话自核，不启动 fresh reviewer；旧审查的跨家族状态需按追加记录分别判断。

下一动作只读 canonical 剩余原始记录、现有表图源和四项原材料，并读取本次 PDF/日志验收资源。剩余新 fresh / build / GET / 实验 / 修订均 0；不编译、不渲染、不落盘。


`canonical.md` 已分段读至末尾，已亲自读取原批准（200–206 行）、追加批准（2844–2857 行）和最新完整最终反馈（3792–4169 行），而非只看摘要。其追加节明确将 build-2 设为当前交付；旧 build-1 的缺图、旧 BLOCKED 和旧 fresh 记录仍属历史。

下一动作：只读最新构建日志/输入记录，并用现有解释器执行 UV 只读解析，独算 CSV、比较三组源码快照及旧最终反馈的哈希，直接解析实际 PDF 到 stdout；不运行项目脚本、不创建渲染文件。剩余新 fresh / build / GET / 实验 / 修订均 0。


本次独算已得到 **1NN 90.000%、majority 50.625%、平均配对差 39.375 pp**。三个当前 TeX 文件与 build-2 快照逐字节相同，哈希与构建记录及旧最终反馈一致；实际 PDF 哈希也一致，直接解析成功：7 页 Letter、226281 bytes、12 项字体均嵌入，stdout 文本与既有提取文本逐字节相同。最终日志仍有 1.15834 pt overfull，不能称“无警告”。

最后动作只读取已存在的七张页面图作本次目检（不生成渲染），并实核历史 raw session 路径是否可用及安装文件与源 tip 的对应关系。剩余新 fresh / build / GET / 实验 / 修订均 0；完成后停止。


## 验收结论

**本次只读自核支持保留既有 `draft`：五行算术成立，当前主稿、图表、build-2 快照与既有最终 PDF 的绑定一致。**  
不是新 fresh 独立审查，不是实验复现，也不升级为 `submission-candidate` 或科研 PASS。

### 1. 五行结果已独算，不依赖 canonical 摘要

直接读取 `fixtures/ml/results.csv`，用 **UV + Decimal** 对全部五行等权计算，无排除：

| seed | majority (%) | 1NN (%) | 1NN − majority (pp) |
|---:|---:|---:|---:|
| 0 | 53.125 | 84.375 | 31.250 |
| 1 | 50.000 | 93.750 | 43.750 |
| 2 | 50.000 | 87.500 | 37.500 |
| 3 | 46.875 | 90.625 | 43.750 |
| 4 | 53.125 | 93.750 | 40.625 |
| **等权均值** | **50.625** | **90.000** | **39.375** |

计算为：
- majority：`253.125 / 5 = 50.625%`
- 1NN：`450.000 / 5 = 90.000%`
- 配对差：`196.875 / 5 = 39.375 pp`

五行差值均为正；这是**百分点差**，不是相对提升，也不证明显著性或总体优势。当前表格全部行、十个图点的源码坐标也与 CSV 一致。

### 2. 当前稿件与 PDF 绑定已亲自核对

实际读取：
- `fixtures/ml-final/paper/main.tex` 全文及其图、表源；
- 四份 `fixtures/ml/` 原材料，未执行 fixture；
- `fixtures/ml-final/canonical.md` 全部 4716 行，包括原批准、追加批准及最新完整最终反馈；
- build-2 的记录、两遍编译输出、最终日志和 `.fls`；
- 实际 PDF 的只读解析，以及已有七张页面图。

三组当前源码与 `build-2/source/` **逐字节相同**，哈希与构建记录、旧最新最终反馈一致：

| 对象 | SHA-256 |
|---|---|
| 主稿 | `c6df284e3ff25a2e9af1412c0987d24b77d19f2f40ac526a226b3f8b35088c53` |
| 图源 | `c194008713bd587bd59e8bca264152745619699bdbb83cfb815f00b45c8dc23b` |
| 表源 | `5de4fde5a339a4c3b948749418ad9363828ccd936f1158742b0db4886ec3e881` |
| 当前 PDF | `616494eca2f81091d48cfd08605cb6ea3b83d07fbf80fa43058c27be3cfdf059` |

**当前 PDF：** `fixtures/ml-final/build-2/output/main.pdf`
- 7 页 Letter，226,281 bytes；
- `pdfinfo`、`pdffonts`、`pdftotext` 均返回 0；
- 12 项字体均嵌入；
- 本次 stdout 文本与既有 `pdf-text.txt` 逐字节一致；
- 既有页面图目检：表在 p4、十点图在 p5，标记与文字可辨，未见明显裁切；图页及末页留白仍在。

旧构建记录为 return 0、约 0.765 秒，日志支持一次 latexmk 内两遍 pdflatex。第一遍引用警告已收敛；**最终仍有 1.15834 pt overfull，主稿行 88–89 / p6**，不能称无警告。

canonical 开头的 build-1 是历史状态；**2766 行起追加节才是当前交付**，没有拿旧缺图 PDF 代替最新稿。

### 3. 旧 fresh 与本次自核严格分开

- 旧 build-1 同家族数字审查及压力尝试保留原版本限制；原 claim-audit 的跨家族能力 **BLOCKED 不被追认解除**。
- 旧追加 GLM 攻击／裁决记录为跨家族压力审查：2 answered、4 partial、1 unresolved；按已读规则映射仍为 **WARN / unresolved_major_or_minor**，不是 PASS。
- 旧最新 GPT 最终反馈为同家族独立 fresh：3 MAJOR、5 MINOR、其读取范围内未发现 CRITICAL。
- **本次为编排者自核，新增 fresh 为 0。** 未重新执行这些专项审查，也不宣称全文重新独审。

### 4. 未核实项与限制

仍未建立：
- 原始生产运行命令、不可变源版本与 CSV 的执行溯源；
- 原始预测、硬件、耗时、完整尝试与历史选择记录；
- 文献定位、原创性、机制解释、总体性能或效率；
- 全部历史 fresh/build/GET 消费的独立完整审计；
- PDF 与已有 PNG 的逐像素生成绑定、打印及完整可访问性；
- venue、发布权限、作者身份及投稿就绪。

历史 raw session 路径**实核存在，但本轮未逐份读取并重算其完整性**；canonical 内嵌原文不冒充此次对 raw traces 的独立认证。PDF 中 COMPUTE、CITATION、EVIDENCE 三项缺口仍可见，FIGURE 缺口已不存在。

安装源仓库 HEAD 实核为指定 `5efd2daffc68612def5e4660defb68db5a7780e3`；入口、ML playbook 和七个适用叶与源目录对应文件 `cmp=0`。这不是对整个安装包及源工作树所有文件的完整审计。

### 清单关闭与停止

先前逐字保留的 todolist 状态：
- **1、2、3：completed（本轮只读范围）**；venue 条件不适用，写入门未越过。
- **4：适用七叶全文读取 completed；新流程执行 blocked**，不重跑规划、生成、起草、编译或 fresh 审查；证明条件不适用。
- **5：completed**，维持既有 `draft`，对话交付后停止。

**本轮新增 fresh / build / 修订 / GET / 实验均 0；未写任务或报告文件，未生成渲染，未改原项目或全局配置。现停止。**