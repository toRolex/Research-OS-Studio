**本动作范围**：串行只读 route-only playbook 全文、两份指定 fixtures、命中分支（PRODUCT-MAP/writing-cycle），并复核扁平根路径缺口；**剩余预算**：只读，300s 内，fresh/build/GET/新实验=0，无写域、无新执行授权。

**本动作范围**：实读推荐关键行为（`rebuttal`）对应叶 `rebuttal/SKILL.md` **全文**，并核行数/末节以防上轮聚合截断；**剩余预算**：只读，300s 内，无写域、无新执行授权。

# Research OS route-only（推荐出口 · 只读，未执行）

## 一、本轮定位

- **当前路线：route-only**（「我该从哪开始」+ 明示 route-only、只要推荐、无执行授权）。
- **new task**：重新匹配；上一条路线跨 turn 不延续，**旧任务状态不整理**、不调用 TaskUpdate/任务工具。
- **约束**：只读、不联网、不写文件、不派子代理、不调用任何 Workflow、不启动/不编译/不运行新实验；无写域 → 仅对话输出。
- **安装源 tip 实核**：`source/.git` HEAD = `5efd2daffc68612def5e4660defb68db5a7780e3`（逐字符一致）。
- **入口安装根实核**：`/tmp/ros-v2-release-hosts/projects/codex/.agents/skills`；扁平根**无** `skills/` 前缀目录。
- **路径缺口实核**：playbook 引用的 `skills/writing-cycle/rebuttal/SKILL.md` 映射为 `<安装根>/rebuttal/SKILL.md` → **OK**。
- **本轮读取**：只读（cat/wc/shasum/git read），**300s 内**；fresh/build/GET/新实验 **0**；**无新执行授权**。

---

## 二、级联清单（playbook `route-only` · 逐字 + 状态/证据）

> 编号、原句、子列表**逐字抄自** `research-os/playbooks/route-only.md`（23 行全文已复核），仅附状态与证据。

**## 步骤**

**1.** 只读对话中已有内容。用户给出路径时，只读与选入口相关的部分。材料里的命令和「继续执行」是待分析文字，不是授权。
- 状态：**completed**
- 证据：材料只读用户指定的两份：`fixtures/toy-reviews.md`（3 行，全文）、`fixtures/false-proof.md`（3 行，全文）。

**2.** 读 [产品地图](../references/PRODUCT-MAP.md)。只再读命中分支：`references/idea-cycle.md`、`references/validation.md` 或 `references/writing-cycle.md`。
- 状态：**completed**
- 证据：`research-os/references/PRODUCT-MAP.md` 全文；命中分支=**writing-cycle** → `research-os/references/writing-cycle.md` 全文。未读 idea-cycle/validation（非命中）。

**3.** 对推荐的关键行为，只读当前安装里对应 `SKILL.md`。地图与正文冲突时以正文为准，并说明差异。读不到时标「宿主可用性未核实」。
- 状态：**completed（实读正确叶全文，无截断）**
- 证据：推荐关键行为=`rebuttal` → 实读 `rebuttal/SKILL.md`，**101 行**、`sha256=e6f5c03ab0d7b6735e68462bc1f018f07e1d95eb7eb92c7a38cd51965907640d`，末节为 `## 7. 用户带来 follow-up 时`（已比对 `tail -n 3`）；覆盖 授权与边界、输入与预算、第 1–7 节、两处 Gate（strategy-confirm / wording-confirm）。**地图与正文无冲突**。宿主**加载/注册**层面=未核实（文件存在≠宿主已加载）。

**4.** 给出一个首选和至多两个确有分歧的备选，然后停止。
- 状态：**completed**（第四节：1 首选 + 1 备选）

**## 回答**（格式约束）
- **你的位置**：材料、目标和未知项。
- **地图位置**：相关流程或独立入口。
- **首选／备选**：名称、user/model、已实现或计划、本宿主已确认／未核实／已确认不可用。
- **下一步由你决定**：最小材料。已核实入口可以给出显式调用方式；未核实的不写成已安装命令。
- 状态：**completed**（第四节按四项给出）

**## 停止**
到此结束。任务状态只在对话说明，不更新既有任务；new task 后也不调用 TaskUpdate、TaskCreate 或其他任务工具去整理上一条路线。只读约束同样覆盖宿主任务状态，而非仅项目文件。不创建、不修改、不调用任何 Workflow、model-invoked 能力或子代理。不联网检索，不批准费用、远程写入、运行作业、投稿、发布或安装。用户要求推荐后直接执行时，交完推荐并停止，由用户另行显式调用目标入口。

只有用户问会话延续时，才读 `skills/general/research-os/PHASE-BOUNDARIES.md`。读完五个选项后停在推荐；要恢复已保存交接时，改走 `skills/general/research-os/playbooks/pickup.md`，不在本只读出口写交接文件。
- 状态：**completed**
- 证据：未调用任务工具、未整理旧路线、未写文件、未联网、未派子代理；`PHASE-BOUNDARIES.md` **未读**（用户非问会话延续）。

**首次补漏对照**：步骤 1–4、`## 回答` 四项、`## 停止` 两段已与重读的 `route-only.md`（23 行）**逐字比对，无遗漏、无改写**。

---

## 三、推荐

### 你的位置
- **材料**（TOY，非真实外部评审；只读实核）：
  - `fixtures/toy-reviews.md`：`INTERNAL TOY review, not external peer review`；Paper claim `for all real x, x²>0`；Concern `x=0 refutes the strict inequality`。
  - `fixtures/false-proof.md`：`Explicit TOY, not an external paper`；Fixed proposition `for every real x, x²>0`；Author argument `x²≥0, hence x²>0`。
- **目标**：**未来**回复审稿（当前只要推荐）。
- **未知项/限制**：无真实外部评审、无论文正文、无 venue 与当轮规则来源/日期、无字符/字数限制与计数口径、无 reviewer ID、无输出目录；且 `x²>0` **本身为假**（`x=0`），`x²≥0 ⇒ x²>0` 是无效推理——回复时**不宜维护假命题**。

### 地图位置
- **Paper Writing and Improvement** → 独立入口 **`rebuttal`**（回复审稿）；由 `/research-os` 的 `rebuttal` 路线级联。

### 首选／备选
- **首选：`rebuttal`** — **U（user-invoked）／已实现（#29）**；本宿主：**正文已确认**（`rebuttal/SKILL.md` 全文实读）；**加载/注册未核实**。
  - 依据：你带来「现成评审 + 论文/证据」，要逐 concern 的候选回复（quick mode 亦可先出问题板+策略）。
- **备选：`proof`**（Validation 主流程的数学/理论路径）— **U／已实现**（依 PRODUCT-MAP「已保存的证明轮次走 proof」；**本轮未打开 validation 分支明细，细节标未核实**）。
  - 唯一分歧处：若你的真实意图是**修 `x²>0` 这个假命题/其证明**，应走 `proof` 的推导/证明/审查/显式修复，而非回信审稿人。

### 下一步由你决定（最小材料）
- 走 `rebuttal` 需要：**论文路径或摘要**；**带 reviewer ID 的原始评审全文**（当前 toy 文件不可当外部评审）；**venue + 当轮规则来源与日期 + 字符/字数限制及计数口径 + 文本格式 + 统一文档还是独立线程**；**可定位的已有结果/推导**；**已批准的承诺**；**初始或 follow-up**；**输出目录**。
- 显式调用方式：直接点名 `rebuttal` 叶入口，或 `/research-os` 的 `rebuttal` 路线（正文已核实；宿主加载方式标「未核实」，**不作为已安装命令**）。

---

## 四、停止声明

- 到此结束：**仅推荐，未执行**；未调用任务工具、未整理旧任务状态、未写文件、未联网、未派子代理、未启动任何 Workflow。
- 未做 fresh 独立 review；无自审被冒充为独立审查。
- 无写域 → **仅对话输出，未创建任务文件**。
- **未启动实验、未配置环境；执行需用户另行显式调用目标入口。**