当前路线：`paper-talk`。本轮只读核对既有 TOY/reading-group 材料，停在 `talk-authorization`；不生成或修改三稿、不构建。

下一动作仅从实际安装根读取 `paper-talk` playbook 全文。剩余授权：主会话有界一次、上限 300 秒；fresh review、build、GET、联网/外发、新实验均为 0；未获批准的文件写入为 0。


### 对话 todolist

1. 读 `skills/writing-cycle/paper-talk/SKILL.md` 全文。源论文与既有材料只读。停在 talk-authorization：输出目录和本轮允许写入的文件未确认时，只展示计划。  
   **状态：in-progress**；证据：已读安装入口的 `research-os/playbooks/paper-talk.md`。
2. 读 `skills/writing-cycle/paper-talk/references/story-and-delivery.md`，按 `skills/writing-cycle/paper-talk/templates/talk-materials.md` 提取证据并形成逐页大纲。停在 outline-confirm：大纲未确认时不生成三份正文。  
   **状态：pending**；须先通过第 1 步授权门。
3. 在授权目录生成 `slides.md`、`speaker_notes.md`、`TALK_SCRIPT.md`。三份使用同一逻辑页编号。请求的 Beamer 或 PPTX 再读 `skills/writing-cycle/paper-talk/references/slide-templates.md`；工具缺失时保留 Markdown，并写明未生成的格式。  
   **状态：pending**；须先通过授权门和大纲确认门。
4. 按 `skills/writing-cycle/paper-talk/references/talk-audit.md` 只读审查这三份实际产物。审查不改演讲，也不改论文。  
   **状态：pending**；不把旧审查或本轮自查记为新独立 review。
5. 内容修订、视觉精修和导出只在本次授权包含对应动作时进行。视觉步骤读 `skills/writing-cycle/paper-talk/references/visual-polish.md`。报告用 `skills/writing-cycle/paper-talk/templates/talk-report.md`。  
   **状态：pending**；本轮无修订、导出或构建授权。
6. 交付 slides、notes、script 与报告。不上传、不发布、不投稿。  
   **状态：pending**；本轮只允许对话输出。

首次清单已逐项对照 playbook：保留全部六步编号、原句和条件句，原文无步骤子列表，未遗漏。

下一动作仅读取扁平安装的 `paper-talk/SKILL.md` 全文，并只读核实安装根和四份既有材料的实际路径；不读取后续步骤资源以提前推进。剩余预算：主会话一次、总上限 300 秒；fresh/build/GET/新实验及写入均为 0。


已核实叶文件存在并读完：`.pi/skills/paper-talk/SKILL.md`；四份既有材料路径均存在，没有安装路径缺口。

下一动作只读这四份既有材料全文，满足叶正文第 1 节“已有大纲或输出先读”的要求；仅核对材料身份、旧结构与计时，不执行第 4 步审查，也不读取第 2 步资源或生成新大纲。剩余预算：仍限本次主会话、总上限 300 秒；fresh/build/GET/新实验/写入均为 0。


**已停在 `talk-authorization`，未越门。** 当前路线为 `paper-talk`，未重跑科研流程。

### 已核实的只读范围
- 已完整读取触发 playbook：`.pi/skills/research-os/playbooks/paper-talk.md`。
- 已完整读取叶正文：`.pi/skills/paper-talk/SKILL.md`；扁平安装路径实核存在，无此处路径缺口。
- 已完整读取既有材料：
  - `fixtures/talk/slides.md`
  - `fixtures/talk/speaker_notes.md`
  - `fixtures/talk/TALK_SCRIPT.md`
  - `fixtures/talk/talk.tex`

### 既有材料状态
- 按本轮用户声明作为 **TOY/旧交付验收材料**，不当作新科研证据。
- 原材料是 **9 个逻辑页**，S2/S4/S5 各含两个 overlay，源文件预期对应 **12 个物理页**；未读取或构建 PDF，因此不宣称实际导出页数已验证。
- 既有计时为主讲 **262 秒**＋buffer **30 秒**＝**292 秒**，在 5 分钟内；这是旧计划，不是本轮排练验证。
- 英语、基础统计 reading group、非匿名；旧材料将 Q&A 放在计时外，此设置尚未成为本轮新确认。
- 原论文全文、图像资产、原始结果未在本轮读取；没有作事实审查或视觉审查。

### Todolist 状态更新
首次展示的六步原句清单保留不变，仅更新状态：
- **第 1 步：blocked**——叶正文和既有材料已读，但新输出目录及允许写入的文件未确认，完成条件未满足。
- **第 2–6 步：pending**——未进入；未读取后续步骤资源，未形成新逐页大纲，未生成、审查、修订或导出三稿。

### 门前计划（仅展示，不执行）
后续可供选择：**沿用既有结构 / 修订既有结构 / 在新目录制作新版本**。须先明确新输出目录和逐文件写入范围；通过该门后才能提取证据、展示完整大纲，并另停在 `outline-confirm`。既有三稿不视为本轮大纲已获确认。

**本轮执行记录：零写入、零覆盖/删除、零构建、零 fresh review、零 GET/联网/外发、零安装、零新实验。** 未调用 Python，未改全局、main 或原项目。安装源 tip `5efd2daffc68612def5e4660defb68db5a7780e3` 仅作为用户提供的标识，未另行核验。旧审查与本轮阅读均不计为新独立 review。