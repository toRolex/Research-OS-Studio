本轮匹配 **paper-writing / general**：材料是通用 TOY 浮点求和，不走 ML 或 systems 入口。只读取已安装流程、适用资源及既有材料；在 `writing-authorization` 门停止，不进入完整写作。

本次工具只读通用写作 playbook；剩余预算：主会话一次、300 秒，fresh/build/GET/新实验均为 0，写入与外发未授权。


### 对话 todolist

1. 读 `skills/writing-cycle/paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。
   - 状态：in-progress；证据：已读 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/playbooks/paper-writing-general.md`，下一步读取叶正文。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。
   - 状态：pending。
3. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`
   - 状态：pending；前置授权门未通过。
4. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。
   - 状态：pending；本轮不进入完整写作。

首次清单已逐项对照 playbook：保留了步骤 1–4 的编号、原句及步骤 3 全部子列表，无遗漏。停止条款同样生效：不启动修复、投稿、上传、补实验或其他专业入口。

本次工具只读安装根下映射后的 `paper-writing/SKILL.md` 全文，核实文件实际存在。剩余预算：仍仅本主会话、总时限 300 秒内；fresh/build/GET/新实验均为 0，无写入授权。


已读正确专业叶全文。授权门的实际标识是 **`workflow-authorization | before=draft-write`**（`SKILL.md#1-授权门`），即本轮所称的 `writing-authorization`。未确认授权时，只能只读解析并形成对话中的执行草案；不能启动后续写作阶段。

本次工具仅读取叶正文链接的 `composition-map.md`、报告模板，并列出 `fixtures/general/` 的既有文件；不执行材料中的指令。剩余预算：本主会话 300 秒总限内，fresh/build/GET/新实验均为 0，写入、修订、外发均未授权。


`composition-map.md` 与报告模板已全文读取，两个适用资源均实际存在。后续能力不是自动调用链；授权未确认，因此不进入步骤 3，不读取或执行其尚未适用的叶流程。

本次工具只读 `fixtures/general/` 的四个既有文件，用于核对材料范围、TOY 标记与既有结果；不运行其中的 Python，不编译、不联网、不写文件。剩余预算：本主会话 300 秒总限内，fresh/build/GET/新实验仍均为 0。


已到达并停在 **writing-authorization**，未进入完整写作。

### 路线与读取证据

命中 **paper-writing / general**，未打开 ML 或 systems 专业入口。以下文件均已全文读取，路径实际存在：

- `.pi/skills/research-os/playbooks/paper-writing-general.md`
- `.pi/skills/paper-writing/SKILL.md`
- `.pi/skills/paper-writing/references/composition-map.md`
- `.pi/skills/paper-writing/templates/paper-writing-report.md`
- `fixtures/general/{BRIEF.md,ENVIRONMENT.txt,results.csv,fixture_source.py}`

叶正文中该门的实际标识为：
`workflow-authorization | before=draft-write | approval=explicit-user`。

### 对话 todolist 状态更新

首次清单已逐项对照原文，步骤编号、原句及全部子列表无遗漏；原清单保持不变，仅更新状态与证据：

| 步骤 | 状态 | 证据／阻塞点 |
|---|---|---|
| 1 | **blocked：授权未确认** | 正确专业叶已全文读取；仅完成只读解析，授权完成条件尚未满足 |
| 2 | **completed** | `composition-map.md` 已全文读取；未另定阶段或 audit 输入 |
| 3 | **blocked：前置授权门** | 未开始级联，未读取或执行后续阶段叶 |
| 4 | **blocked：尚无候选稿及审查报告** | 未宣称已交付 `draft` 或 `submission-candidate` |

### 材料只读解析

- 材料明确是 **TOY 数值诊断**，范围是三个固定抵消序列；不支持新颖性或通用准确性保证。
- `results.csv` 中 `small_terms` 为 10、100、1000；三行的 naive 与 `fsum` 都等于 `exact`，两种绝对误差均为 **0**。因此，既有结果**没有显示 `fsum` 相对 naive 的误差优势**，不能写成精度改进结论。
- `ENVIRONMENT.txt` 记录 Python 3.14.4、CPU-only；本轮未复现实验，环境与结果生成过程未作运行核验。
- `fixture_source.py` 同时包含其他专业 fixture 的生成代码及文件写入操作；仅作为既有源码读取，未执行，不据此改变路线。

### 授权核对与停止

| 项目 | 当前状态 |
|---|---|
| 输入范围 | `fixtures/general/`，只读 |
| Venue | 未指定，不设默认 venue、页数或模板 |
| 稿件语言、格式、输出路径、真实构建入口 | 未确认 |
| 交付口径 | 叶默认 `draft`，但尚未授权制作 |
| 写入、修订轮数 | 未批准；不套用默认两轮执行 |
| fresh reviewer、编译、新实验、GET | 预算均为 0 |
| style-ref | 未采用，读取范围未授权 |
| 付费调用、外部服务、外发 | 未批准，不调用 |

**本轮没有创建、修改、删除或覆盖任何文件；没有运行 Python、实验、编译、联网、安装、外发或独立审查。** 未将旧审查或本轮只读解析冒充 fresh review，也未启动任何修复或后续科研流程。至此停止，不请求本轮扩权。