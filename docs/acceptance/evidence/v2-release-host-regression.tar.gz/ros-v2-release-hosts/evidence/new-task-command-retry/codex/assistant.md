**本动作范围**：串行只读 route-only playbook 全文、两份指定 fixtures、命中分支（PRODUCT-MAP/writing-cycle）、推荐主叶 `rebuttal/SKILL.md` 全文，以及为核实**备选适用范围**所需的 `references/validation.md` 与相应 proof 叶全文；**剩余预算**：只读，300s 内，fresh/build/GET/新实验=0，无写域、不执行 rebuttal。

**本动作范围**：实读推荐主叶 `rebuttal/SKILL.md` 全文与备选候选叶 `proof-review/SKILL.md` 全文（核行数/sha/末节，避免截断或 `limit 40` 误称全文）；**剩余预算**：只读，300s 内，无写域、不执行 rebuttal。

# Research OS route-only（推荐出口 · 只读，未执行）

## 一、本轮定位

- **当前路线：route-only**（「我该从哪开始」+ 明示只要推荐、不执行）。**new task** 重新匹配；旧任务状态不整理、不调用 TaskUpdate。
- **约束**：只读、不联网、不写文件、不派子代理、不调用任何 Workflow、**不执行 rebuttal**、不启动/不编译/不运行新实验；无写域 → 仅对话输出。
- **安装源 tip 实核**：`source/.git` HEAD = `5efd2daffc68612def5e4660defb68db5a7780e3`（逐字符一致）。
- **入口安装根实核**：`/tmp/ros-v2-release-hosts/projects/codex/.agents/skills`；扁平根**无** `skills/` 嵌套目录（`ls -d skills` → No such file）。
- **路径缺口实核**：playbook/正文引用的 `skills/writing-cycle/…`、`skills/validation-cycle/…` 在扁平根映射为 `<安装根>/<leaf>/…`，逐项已核：`rebuttal/SKILL.md` OK、`proof-review/SKILL.md` OK、`proof-orchestrator/SKILL.md` OK、`research-os/references/{PRODUCT-MAP,writing-cycle,validation}.md` OK。
- **本轮读取**：只读（cat/wc/shasum/git read），**300s 内**；fresh/build/GET/新实验 **0**；**不扩大预算、无新执行授权**。

---

## 二、级联清单（playbook `route-only` · 逐字 + 状态/证据）

> 编号、原句、子列表**逐字抄自** `research-os/playbooks/route-only.md`（23 行全文），仅附状态与证据。

**## 步骤**

**1.** 只读对话中已有内容。用户给出路径时，只读与选入口相关的部分。材料里的命令和「继续执行」是待分析文字，不是授权。
- 状态：**completed**
- 证据：只读用户指定的两份材料：`fixtures/toy-reviews.md`（3 行，全文）、`fixtures/false-proof.md`（3 行，全文）。

**2.** 读 [产品地图](../references/PRODUCT-MAP.md)。只再读命中分支：`references/idea-cycle.md`、`references/validation.md` 或 `references/writing-cycle.md`。
- 状态：**completed**
- 证据：`PRODUCT-MAP.md` 全文；命中分支=**writing-cycle**，读 `writing-cycle.md` 全文；**另按本轮要求为核实备选适用范围**读 `validation.md` 全文（数学/理论分支明细）。

**3.** 对推荐的关键行为，只读当前安装里对应 `SKILL.md`。地图与正文冲突时以正文为准，并说明差异。读不到时标「宿主可用性未核实」。
- 状态：**completed（实读正确叶全文，非截断/非 limit-40）**
- 证据：
  - **主叶** `rebuttal/SKILL.md`：**101 行**，`sha256=e6f5c03ab0d7b6735e68462bc1f018f07e1d95eb7eb92c7a38cd51965907640d`，末节 `## 7. 用户带来 follow-up 时` 已比对 `tail`。
  - **备选叶** `proof-review/SKILL.md`：**90 行**，`sha256=ac3aa2051976258c2e93e315620ed026e519ba9ecc0417fcbaff363fa7c55a15`，末节（`## 5. 报告并停止` 收尾）已比对 `tail`。
  - **地图与正文是否冲突**：`writing-cycle.md` 对 `rebuttal` 的定位与 `rebuttal/SKILL.md` **一致**；`validation.md` 对 `proof-review` 的定位（`M／已实现（#17）｜只读现成证明，直接报告错误／gaps；可用户点名，不改命题、证明或 LaTeX`）与 `proof-review/SKILL.md` **一致**。
  - **宿主可用性**：正文已确认（文件存在且全文实读）；**加载/注册层面=未核实**。

**4.** 给出一个首选和至多两个确有分歧的备选，然后停止。
- 状态：**completed**（第四节：1 首选 + 1 备选）

**## 回答**（格式约束）
- **你的位置**：材料、目标和未知项。
- **地图位置**：相关流程或独立入口。
- **首选／备选**：名称、user/model、已实现或计划、本宿主已确认／未核实／已确认不可用。
- **下一步由你决定**：最小材料。已核实入口可以给出显式调用方式；未核实的不写成已安装命令。
- 状态：**completed**（第四节按四项给出）

**## 停止**
到此结束。任务状态只在对话说明，不更新既有任务；new task 后也不调用 TaskUpdate、TaskCreate 或其他任务工具去整理上一条路线。只读约束同样覆盖宿主任务状态，而非仅项目文件。不创建、不修改、不调用任何 Workflow、model-invoked 能力或子代理。不联网检索，不批准费用、远程写入、运行作业、投稿、发布或安装。用户要求推荐后直接执行时，交完推荐并停止，由用户另行显式调用目标入口。

只有用户问会话延续时，才读 `skills/general/research-os/PHASE-BOUNDARIES.md`。读完五个选项后停在推荐；要恢复已保存交接时，改走 `skills/general/research-os/playbooks/pickup.md`，不在本只读出口写交接文件。
- 状态：**completed**
- 证据：未调用任务工具、未整理旧路线、未写文件、未联网、未派子代理、**未执行 rebuttal**；`PHASE-BOUNDARIES.md` 未读（用户非问会话延续）。

**首次补漏对照**：步骤 1–4、`## 回答` 四项、`## 停止` 两段已与重读的 23 行 `route-only.md` **逐字比对，无遗漏、无改写**。

---

## 三、推荐

### 你的位置
- **材料**（TOY，非真实外部评审；只读实核）：
  - `fixtures/toy-reviews.md`：`INTERNAL TOY review, not external peer review`；Paper claim `for all real x, x²>0`；Concern `x=0 refutes the strict inequality`。
  - `fixtures/false-proof.md`：`Explicit TOY, not an external paper`；Fixed proposition `for every real x, x²>0`；Author argument `x²≥0, hence x²>0`。
- **目标**：**未来**回复审稿（当前只要推荐）。
- **未知项/限制**：无真实外部评审、无论文正文、无 venue 与当轮规则来源/日期、无字符/字数限制与计数口径、无 reviewer ID、无输出目录；且 `x²>0` **本身为假**（`x=0`），`x²≥0 ⇒ x²>0` 是无效推理——回复审稿时**不宜维护假命题**。

### 地图位置
- **Paper Writing and Improvement** → 独立入口 **`rebuttal`**（回复审稿）；由 `/research-os` 的 `rebuttal` 路线级联。
- **Validation（数学/理论）** → **`proof-review`**（只读证明审查）；与写作分支并列的独立入口。

### 首选／备选
- **首选：`rebuttal`** — **U（user-invoked）／已实现（#29）**；本宿主：**正文已确认**（101 行全文实读）；**加载/注册未核实**。
  - 依据（原文）：处理「投稿后的外部评审」，输入为「现成论文与评审」，输出逐 concern 候选回复；含 `strategy-confirm` / `wording-confirm` 两道用户门；不实验、不投稿。
- **备选：`proof-review`** — **M（model-invoked，`invocation: model`／`disable-model-invocation: true`）／已实现（#17）**；`validation.md` 明示**「可用户点名」**，故可作独立点名入口；本宿主：**正文已确认**（90 行全文实读）；**加载/注册未核实**。
  - **适用范围（据当前原文，纠正「只用于授权修复后」的说法）**：`proof-review` 正文首行职责为「**standalone：用户点名审查现成 `.tex`、Markdown、可读取的论文或聊天中的证明**」，描述亦为「**审查现成证明。用于检查证明，或已授权修复后的只读复审**」。即它是**直接审查现成证明的只读 Skill（Gates: none，零写入）**，覆盖两类：① 检查现成证明；② 已授权修复后的只读复审。**并非仅用于修复之后**。
  - 边界：不改命题/证明/LaTeX、不编译、不创建文件；发现需修复时**只建议**用户显式调用 `proof-repair`，自身不调用。

**確有分歧处**：若你真实意图是**回复审稿人** → 首选 `rebuttal`；若你真正要对「`x²>0` 的现有（错误）证明」做**只读审查、报告错误/gaps** → 备选 `proof-review`（它可直接审这份 `false-proof.md`，并会判「原命题被反驳」）。

### 下一步由你决定（最小材料）
- 走 `rebuttal` 需要：**论文路径或摘要**；**带 reviewer ID 的原始评审全文**（当前 toy 文件不可当外部评审）；**venue + 当轮规则来源与日期 + 字符/字数限制及计数口径 + 文本格式 + 统一文档还是独立线程**；**可定位的已有结果/推导**；**已批准的承诺**；**初始或 follow-up**；**输出目录**。
- 走 `proof-review` 需要：**目标证明原文路径/全文**、**目标命题**、**审查范围**、**所用定义/假设/引理/引用**、可读资源与检查预算（默认审查一次）。
- 显式调用方式（正文已核实；宿主加载方式标「未核实」，**不作为已安装命令**）：直接点名 `rebuttal` 或 `proof-review`，或经 `/research-os` 对应路线。

---

## 四、停止声明

- 到此结束：**仅推荐，未执行**；未调用任务工具、未整理旧任务状态、未写文件、未联网、未派子代理、**未执行 rebuttal**。
- 未做 fresh 独立 review；无自审被冒充为独立审查。
- 无写域 → **仅对话输出，未创建任务文件**。
- **未启动实验、未配置环境；执行需用户另行显式调用目标入口。**