**重新匹配（new task）**：「我该从哪开始…只要推荐不要执行」→ **当前路线：route-only**（即使句中含「回复审稿」执行词，只改变推荐对象，不改路线）。旧 todolist 不延续，不调用任务工具。

**动作 1（只读）**：读 `route-only` playbook 全文 + 实核 fixtures 存在性。预算：本轮 300s、0 fresh/build/GET/新实验、0 写域、无联网。

route-only 步骤 1 completed（fixtures 两文件实存，各 3 行）。**动作 2（只读）**：读 PRODUCT-MAP 全文，再只读命中分支。

**命中分支**：已有稿件（审稿意见）→ 想回复审稿 → 读 `references/writing-cycle.md`；`false-proof.md` 涉及证明 → 交叉命中 `references/validation.md`。**动作 3（只读）**：读两分支明细 + 命中叶 `SKILL.md`。

分支已明。route-only 步骤 2 completed。**动作 4（只读，最后一批）**：步骤 3 要求对推荐关键行为实读对应 `SKILL.md`——主推荐 `rebuttal`，涉证明材料的关键行为 `proof-review`，实核安装。

route-only 步骤 3 completed（两叶 SKILL.md 均实读关键正文；本宿主 Claude Code 已确认安装、user-invoked、`disable-model-invocation: true` 故需显式调用）。步骤 4：给出推荐后停止。

## 回答

**你的位置**
- 材料：`fixtures/toy-reviews.md`（3 行，TOY 内部审稿意见，非外部 peer review；claim「∀ real x, x²>0」+ concern「x=0 证伪严格不等式」）与 `fixtures/false-proof.md`（3 行，TOY 显式假证明，论证 x²≥0 ⇒ x²>0，量词/严格性缺口明显）。两文件已实读。
- 目标：未来回复审稿。
- 未知项：对应「论文」正文/证据材料是否存在；是否还要先修证明缺口；venue/规则/预算均未给——但推荐不需要这些。

**地图位置**：Writing Cycle → 独立用户入口 `rebuttal`（已实现 #29）；交叉：Validation → 数学/理论 `proof-review`（已实现 #17，U 可点名 standalone）。

**首选：`rebuttal`**（`/research-os` rebuttal 路线级联）
- user/model：U 入口，需你显式调用。本宿主已确认安装。
- 适用依据（正文实读）：「现成审稿意见与论文证据；原子化 concern、映射证据、区分可答／待澄清／需补工作。补实验／补证明只列建议……先交还用户另行启动适当流程」——审稿意见里若要求修证明，它会转建议而非自动启动证明流程。停止门：strategy-confirm、wording-confirm。
- 注意：TOY 材料只有 3 行 claim+concern，无完整论文/证据。叶合同允许规则缺失时先整理 concern 与策略，但**停在回复正文之前**——首次调用会先在步骤 1 报缺口。

**备选（确有分歧才列）**
1. **`proof-review`**（standalone 点名）——若你想先弄清 `false-proof.md` 的错误在哪，再决定 rebuttal 策略。分歧点：它是审查动作而非回复动作，且为「已授权修复后的只读复审」场景设计；两份材料都指向同一 x=0 缺口，审查结果可作 rebuttal 的证据输入，但次序可倒。已确认安装、只读零写入。
2. **`proof-repair`**（U，已实现 #17）——仅当你想修这份假证明；当前「只推荐不执行」，且证明修复不等于回复审稿，列为分歧备选。

**下一步由你决定**：最小材料 = ① 完整论文或证据材料路径（或确认只有这两份 fixture）；② 若走 rebuttal，提供 venue/轮次规则（缺失也可先停在策略阶段）；③ 显式调用方式：`/research-os` 带 rebuttal 意图，或点名 `rebuttal`。

到此结束。当前路线：route-only；未执行任何入口，未创建/修改文件，未调用任务工具。