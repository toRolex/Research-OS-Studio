当前路线：**paper-writing / ml**。本轮只读安装入口、对应 playbook、专业 ML 叶与当前适用的本地材料；不写文件、不联网、不运行实验、不编译，也不以通用 writing 入口替代。

本动作范围：读取 `paper-writing-ml.md` 全文以建立逐字 todolist。剩余预算：一次主会话、300 秒上限（尚未消耗计时额度）；fresh / build / GET / 新实验均为 0，写域与写作预算未批准。


### 对话 todolist

1. 读 `skills/writing-cycle/ml-paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。补实验不在本次授权内。
   - 状态：in-progress；证据：已读 `research-os/playbooks/paper-writing-ml.md`，待读专业叶全文。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/ml-paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。
   - 状态：pending。
3. ML 专属纪律读全文：
   - `skills/writing-cycle/ml-paper-writing/references/experiment-reporting.md`
   - `skills/writing-cycle/ml-paper-writing/references/reviewer-expectations.md`
   - 用户指定 venue 时读 `skills/writing-cycle/ml-paper-writing/references/venue-checklists.md`
   - 状态：pending。
4. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`
   - 状态：pending。
5. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。
   - 状态：pending。

首次逐项对照：编号、原句与子列表均已保留，无漏项；停止条款也已读，不启动修复、投稿、上传、补实验或通用 / Systems 入口。

本动作范围：读取安装根中映射后的专业 ML 叶全文，核实其授权门。剩余预算：主会话时间上限 300 秒，已用约 30 秒；fresh / build / GET / 新实验及已批准写作预算均为 0。


已实核专业叶路径存在，授权门为 `workflow-authorization`；缺确认时只允许只读解析与对话内执行草案。不会进入规划、绘图、起草或审查执行。

本动作范围：全文读取 composition map、两份 ML 专属纪律；只列出 `fixtures/ml/` 的本地文件及项目角色表、算力政策是否存在，以确定原始材料读取范围。剩余预算：仍限本轮 300 秒内；此前“约 30 秒”为估计，非计时证据；fresh / build / GET / 新实验 / 已批准写作预算均为 0。


当前适用资源已全文读完。未指定 venue，故不读 venue 清单、不假定会议；composition map 不构成后续调用授权。项目角色表与 `compute-policy.md` 均实核缺失：角色回退到当前会话实际模型 `cliproxy/gpt-6.1-sol`，thinking 未实核，不编造；默认算力额度为 0。

本动作范围：全文只读 `fixtures/ml/` 的全部四个文件（含原始 CSV、source、environment），以及专业叶许可证与报告模板；不执行 source、不调用 Python、不生成稿件或报告文件。剩余预算：本轮 300 秒硬上限内继续；fresh / build / GET / 新实验 / 已批准写作预算均为 0。完成只读解析后即停授权门。


**已停在专业 ML 授权门，未进入论文写作。** 当前路线保持 `paper-writing / ml`，没有读取或调用通用 writing 入口，也没有用一般数学材料替代 ML 材料。

### 只读解析结果

已全文读取 `fixtures/ml/` 的全部四个文件：

| 材料 | 已核实内容 |
|---|---|
| `BRIEF.md` | 明确为**实际执行的 TOY ML 比较**，不是现实数据集研究；固定合成条件，不允许进一步实验。 |
| `results.csv` | seeds 为 0–4，共五个 seed；每个 seed 均为 32 个训练样本、32 个测试样本，同时记录 train-majority 与 1-NN accuracy。五行中 1-NN 均高于 majority；这不构成显著性检验。 |
| `fixture_source.py` | ML 部分是二维合成二分类，标签为 `int(x[0]+x[1]>0)`；固定 1-NN、无调参。文件还含 general / systems 材料生成逻辑及写入操作，**仅阅读，未执行，未将其他部分用作 ML 证据**。 |
| `ENVIRONMENT.txt` | 记录 Python 3.14.4、macOS 15.6.1 arm64、CPU only、无外部数据及“No failed attempts”。后者是既有环境记录，不是本轮独立核验。 |

目前没有预先报告的不确定性量、显著性检验、CPU 具体型号或运行时长／总算力记录；这些保持缺口，不估算、不补实验。已知 framing 只支持固定 TOY 条件下的比较，不能外推真实数据集表现或宣称新颖性。

### 授权门核对

实际安装叶已核实存在并全文读取：

`/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/ml-paper-writing/SKILL.md`

门：`workflow-authorization | before=draft-write | approval=explicit-user`

- **输入范围**：上述四个文件，原材料全部只读。
- **Venue**：未指定；brief 要求 venue-neutral，不设默认会议，venue 合规未核对。
- **语言、稿件格式、输出位置、真实构建入口**：未确认。
- **交付口径**：叶默认 `draft`，但尚无候选稿，不声称已经交付。
- **写入清单与写作预算**：未批准；本轮没有任何已获准写入。
- **修订轮数**：未批准，实际执行 0 轮；没有把默认 2 轮当成授权。
- **资源**：fresh / build / GET / 新实验均为 0，实际均未使用。
- **独立 reviewer、材料边界、style-ref**：未批准／未确定，均未执行。
- **远程、外发、安装、付费服务**：禁止或未批准，均未执行。

项目 `.agents/research-os-models.md` 与 `compute-policy.md` 实核缺失；模型回退到当前会话实际报告的 `cliproxy/gpt-6.1-sol`，thinking 未核实、不编造。缺失算力政策不产生运行许可。

### 对话 todolist — 最终状态

以下继续保留 playbook 的步骤编号、原句及子列表；首次展示已逐项对照，无漏句。

1. 读 `skills/writing-cycle/ml-paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。补实验不在本次授权内。
   - **状态：blocked（授权未确认）**。证据：专业叶全文、`fixtures/ml/` 四文件全文；只读解析完成，工作流完成条件尚未满足。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/ml-paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。
   - **状态：completed**。证据：安装根下 `ml-paper-writing/references/composition-map.md` 全文；未执行被组合能力。
3. ML 专属纪律读全文：
   - `skills/writing-cycle/ml-paper-writing/references/experiment-reporting.md`
   - `skills/writing-cycle/ml-paper-writing/references/reviewer-expectations.md`
   - 用户指定 venue 时读 `skills/writing-cycle/ml-paper-writing/references/venue-checklists.md`
   - **状态：completed**。证据：前两份资源全文已读；未指定 venue，第三项条件未触发。
4. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`
   - **状态：blocked（前置授权门）**。未进入、未读取这些叶，不声称已执行或已实核其路径。
5. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。
   - **状态：blocked（尚未获准产生候选稿与审查报告）**。没有宣称 draft 或 submission-candidate 就绪。

**本轮交付仅为对话内只读解析及授权草案。** 未创建任务文件，未写入、删除或覆盖任何文件；未运行 Python、source、新实验或编译；未联网、外发、安装，也未重跑完整科研流程。没有 fresh review，未把旧审查或本轮解析冒充独立审查。安装源 tip 使用用户给定标识，未另行核验其提交身份。至此停止，不继续过门。