**本动作范围**：串行只读重读触发 playbook 全文、叶全文与 `batch-authorization.md`，并复核扁平根路径缺口；**剩余预算**：只读，300s 内，fresh/build/GET/新实验=0，无写域。

# Research OS 编排结果（同一任务续接 · `experiment-plan` 路线）

## 一、本轮定位与约束（非 new task）

- **保持原路线原步骤**：当前路线仍为 `experiment-plan`；本轮**只补「待提供材料」清单**，不改到 bridge、不改动计划的 Claim/Block 结构、不启动。
- **约束不变**：预算仍未知（不补数字）、无写域 → 仅对话输出；只读、不实现、不启动、不联网/外发/安装、不运行新实验、不编译、不删/覆盖；本轮含 probe/解析在内**若未来执行，Python 一律 `uv run python`**（本轮不执行任何 Python）。
- **安装源 tip 实核**：`source/.git` HEAD = `5efd2daffc68612def5e4660defb68db5a7780e3`（与请求逐字符一致）。
- **入口安装根实核**：`/tmp/ros-v2-release-hosts/projects/codex/.agents/skills`；`research-os/SKILL.md` 与 `experiment-plan/SKILL.md` 均存在。
- **路径缺口复核**：扁平根**无** `validation-cycle/`（`ls` 报 `No such file or directory`）；playbook 步骤 1 路径按规则映射到 `<安装根>/experiment-plan/SKILL.md`，上轮 `diff -rq` 已确认与源 tip 树 `skills/validation-cycle/experiment-plan/` **IDENTICAL**。
- **模型表**：`.agents/research-os-models.md` 缺失 → 回退当前 session 模型并明示回退，不编造 slug。
- **算力**：工作区根 `compute-policy.md` 缺失 → 默认政策范围未指定，**预算 0、未知**。
- **读取预算**：仅只读 `exec_command`（cat/ls），**300s 内**；fresh/build/GET/新实验 **0**。

---

## 二、级联清单（playbook `experiment-plan` 步骤·逐字 + 状态/证据）

> 编号、原句、子列表**逐字抄自** `research-os/playbooks/experiment-plan.md`，仅附状态与证据。

**## 步骤**

**1.** 读 `skills/validation-cycle/experiment-plan/SKILL.md` 全文，并读它点名的 references 与 templates。计划内容、阶段和产出以该正文为准。不在这里重写科研流程。
- 状态：**completed**
- 证据：本轮重读叶全文 `experiment-plan/SKILL.md`；点名资源 `experiment-plan/references/block-checks.md`、`experiment-plan/templates/experiment-plan.md`（上轮已读全文）；步骤 3 引用的 `research-os/references/batch-authorization.md` 本轮重读全文。路径缺口已实核并映射。

**2.** 只读本次相关材料。未知项标缺口，不补预算数字。
- 状态：**completed**（本轮在该步产出上补「待提供材料清单」，见第四节；未补任何预算数字）
- 证据：只读材料同上一轮（`fixtures/toy-reviews.md`、`fixtures/bridge-expired/*`、`fixtures/proof/round-1/*` 等）；工作区根无 `research-log.md`/`compute-policy.md`。**本轮新增交付=待提供材料清单**。

**3.** 计划达到「可供执行授权」前，按 [批次授权](../references/batch-authorization.md) 列出本批字段，请用户确认。确认的是这一批，不是工作区默认 `compute-policy.md`。
- 状态：**blocked（条件未触发）**
- 证据：`batch-authorization.md` 已重读；计划**未达「可供执行授权」**，`## 停止` 分支生效，故**不发起本批确认**。其字段清单本轮**仅作为「待提供材料清单」的推导来源**，非确认请求。

**4.** 用户确认本批后，把确认原文、时刻和全部字段写入工作区 `research-log.md` 的新段落。authorization_status 写「本批已确认」。默认政策额度保持 0，不抄进这条授权。
- 状态：**not started（blocked）**
- 证据：无本批确认、无写域 → 未写 `research-log.md`。

**5.** 只把计划和 tracker 写到用户允许的路径。已有计划文件先展示差异。删除或覆盖既有实验结果时停，等另一次明确批准。
- 状态：**completed（以「仅对话、零写入」满足）**
- 证据：本轮**未创建/未覆盖任何文件**；未触碰 `fixtures/bridge-expired/EXPERIMENT_PLAN.md` 等既有材料。

**6.** 交付计划后停止。本路线不启动实验，不把本批确认交给 bridge 自动开跑。
- 状态：**completed**
- 证据：本轮交付后停止；未启动、未进入 bridge。

**## 停止**
计划未达到可授权时，交付标了缺口的草稿并停止，研究日志不写运行许可。用户拒绝本批确认时，保留已有材料，不写 authorization_status。
- 状态：**completed（命中「计划未达到可授权」分支）**
- 证据：交付 BLOCKED 草稿与待提供清单后停止；未写运行许可、未写 authorization_status。

**首次补漏对照**：步骤 1–6 与 `## 停止` 两句已与本轮重读的 playbook **逐字比对，无遗漏、无改写**。

---

## 三、本轮的 Phase 级执行证据（叶全文已重读）

- **Phase 0/1**（问题、输入、约束、缺口；Claims 与评价面）：结论不变——**关键项缺，判 BLOCKED 草稿**。
- **Phase 1「资源范围」原句**：「缺少资料时标为待提供，不安装工具或申请算力。」→ **本轮职责即把散落缺口整理为可勾选的「待提供材料清单」**。
- **Phase 3「逐 criterion evidence」**：每条 criterion 的主证据位置待提供（见第四节 C/D/F）。
- **Phase 4「bind 实际项目位置、数据/协议标识符」**：绑定项缺 → 列入清单（见第四节 B–E）。
- **Phase 5**：本轮**不重写**计划正文，只补输入侧清单；tracker 未落盘。
- **未做**：无 fresh 独立 review（旧 `fixtures/proof` 审查为既有结果，不冒充新审查）；未执行任何 Python/实验。

---

## 四、交付：待提供材料清单（TOY：`sum` vs `for` 正确性等价）

> 用途：把上一轮 BLOCKED 草稿的缺口收敛为**用户可逐条提供/批准**的清单。
> 预算仍未知 → **不填任何数字**；无写域 → 仅对话；不改 bridge、不启动。
> 标记：`[必备-执行前]` 缺则计划不可执行；`[必备-授权前]` 缺则无法通过本批确认；`[可选]`。

### A. 研究问题与命题族（解锁 Phase 1 冻结）
| # | 待提供材料 | 解锁对象 | 决策人 |
|---|---|---|---|
| A1 | 确认「正确性」的判据：两实现**互等** 或 与**独立 oracle** 相等（二选一或组合） | C1/C2、K1、B1/B2 | 用户 |
| A2 | 确认取值域与量词：整数范围、序列长度范围、是否含空序列/负数/0/超长（溢出边界） | C1/C2、B2 | 用户 |
| A3 | 确认 C1（primary）+ C2（边界 supporting）是否即为最终 claim 集（≤2） | Claim Map | 用户 |

### B. 数据（解锁 Phase 1「Fixed evaluation surface」）
| # | 待提供材料 | 解锁对象 | 决策人 |
|---|---|---|---|
| B1 `[必备-执行前]` | **冻结的本地整数序列 S**（内容或确定性生成规则）+ 来源与许可 | B1、K1、M2 | 用户 |
| B2 `[必备-执行前]` | **边界子集**定义（空、单元素、全负、含 0、长度/溢出边界） | B2、K2、M3 | 用户 |
| B3 | split/采样单位（确定性 toy 可声明「无划分」，需显式写出） | 评价面 | 用户 |
| B4 | 序列/边界的**证据去向**（未来结果文件位置） | K1/K2 主证据绑定 | 用户 |

### C. 真值 / Oracle（解锁 Phase 4 baseline-first）
| # | 待提供材料 | 解锁对象 | 决策人 |
|---|---|---|---|
| C1 `[必备-执行前]` | **参考真值来源**：闭式 `n(n+1)/2` / 内置 `sum` / 外部权威值，及版本绑定 | K3、M1、B1 | 用户 |
| C2 | oracle 与两个被测实现的**访问隔离**是否为强制（否则注明「计划职责边界，非强制隔离」） | 评价面 | 用户 |
| C3 | oracle 缺陷时的处理：停比较+用户批新协议+旧结果记为不可比（确认或改写） | 协议变更规则 | 用户 |

### D. 评估器与指标（解锁 Phase 3 逐 criterion）
| # | 待提供材料 | 解锁对象 | 决策人 |
|---|---|---|---|
| D1 `[必备-执行前]` | 评估器代码/协议位置（或「复用既有 evaluator」的具体文件） | K1/K2 主证据、M0 | 用户 |
| D2 `[必备-执行前]` | 指标定义：决定性指标（逐例输出相等）+ 方向/单位/聚合 | K1/K2 | 用户 |
| D3 | 选择规则、seeds/配对（确定性 → **seeds=N/A 需显式声明**并给理由） | 统计计划 | 用户 |
| D4 | 成功阈值与**负/不确定/无效/运行失败**的区分规则（预specify） | Failure interpretation | 用户 |
| D5 | 次要指标（若有） | Phase 3 | 用户 |

### E. 候选范围与写域（解锁 Gate `output-path`）
| # | 待提供材料 | 解锁对象 | 决策人 |
|---|---|---|---|
| E1 `[必备-授权前]` | 候选文件**具体路径**：`sum` 实现与 `for` 实现（当前为 proposed，未创建） | Candidate scope、B1/B2 | 用户 |
| E2 `[必备-授权前]` | **允许的写域**（计划文件、tracker、未来结果目录的具体路径） | Gate output-path、步骤 5 | 用户 |
| E3 | 计划/tracker 落盘路径或「保持仅对话」 | 步骤 5 | 用户 |
| E4 | 语言偏好（正文语言；代码/路径/指标名保留原形） | Phase 5 | 用户 |

### F. 执行/预算授权（batch-authorization 本批确认字段；**本批字段仅供授权前填写，非本次确认**）
| # | 待提供材料（字段） | 说明 | 决策人 |
|---|---|---|---|
| F1 `[必备-授权前]` | `scope`（计划、允许写域、环境） | 未指定则本批不能执行 | 用户 |
| F2 | `cost_limit`、`currency` | 有限非负 | 用户 |
| F3 | `compute_limit`、`compute_unit`（cpu-core-hour / gpu-device-hour） | 有限非负；异构分行 | 用户 |
| F4 | `run_limit`、`run_count_basis`（planned-run） | 非负整数 | 用户 |
| F5 | `per_attempt_cost_limit`、`per_attempt_compute_limit` | ≤ 累计上限 | 用户 |
| F6 | `concurrency_limit`（启动时 ≥1）、`retry_limit` | 非负整数 | 用户 |
| F7 | `valid_for_hours`、`valid_until`（带时区 ISO8601） | 有限非负 | 用户 |
| F8 `[必备-授权前]` | `batch_id`、`plan`、`mode`、`user_confirmation`（原话）、`confirmed_at`、`confirmation_basis`、`authorization_status` | basis 须指向用户原话，非默认政策 | 用户 |

- **禁止**：unlimited、负数、NaN、无单位；未知项停下来问，**不补默认数**（本轮预算保持未知/0）。

### G. 运行约定（未来执行时适用；本轮不执行）
| # | 待确认材料 | 来源 |
|---|---|---|
| G1 | 所有 Python（含 probe/解析）**只用 `uv run python`** | 用户本轮明示（已记录） |
| G2 | 不联网/外发/安装、不编译、不删/覆盖、不改全局/main/原项目 | 用户本轮明示（已记录） |
| G3 | 运行记账按 batch-authorization「每次留账」「硬停」执行 | `batch-authorization.md` |

### 缺口 → 清单 → 解锁（速查）
| 缺口 | 清单项 | 解锁 |
|---|---|---|
| 无数据 | B1、B2 | B1/B2、K1/K2 |
| 无 evaluator / 指标 | D1、D2、D4 | Phase 3、K1/K2 |
| 无 oracle | C1 | M1、K3 |
| 定义歧义（“正确性”） | A1 | C1 判据 |
| 无写域 | E1、E2、E3 | Gate output-path |
| 预算未知 | F1–F8（**须用户给值，不补数**） | 本批确认 |

---

## 五、停止声明

- 本轮仅补**待提供材料清单**：**未落盘、未创建任务文件**（仅对话输出）；未改到 bridge；未启动实验、未配置环境；未联网/外发/安装；未编译；未删除/覆盖任何材料。
- 计划状态：**BLOCKED 草稿**（可执行性依赖 A–F 关键项）；预算**仍未知**；无写域。
- 未做 fresh 独立 review；旧 `fixtures/proof` 审查为**既有结果**，未冒充新审查。
- **未启动实验、未配置环境；执行需用户另行授权。**