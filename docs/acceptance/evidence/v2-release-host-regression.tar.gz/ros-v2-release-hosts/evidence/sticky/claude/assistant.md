**延续确认**：同一路线 `experiment-plan`、同一 todolist，不重匹配、不转 bridge、不启动。本动作范围=仅对话输出补充清单；剩余预算=本轮 300s 内、0 fresh/build/GET/新实验、0 写域（无需工具调用，材料清单全部来自已读叶合同与既有草稿缺口）。

## 待提供材料清单（补入 BLOCKED 草稿，状态仍为「待补全，不可执行」）

每项标注：影响 block → 所需材料 → 待决策人=用户。预算数字一律留空，不代填。

| # | 材料 | 具体待定项 | 影响 | 决策人 |
|---|---|---|---|---|
| P1 | 数据定义 | 「本地整数序列」的确切来源与形态：内置常量 / 既有文件路径（如有需给实际路径）/ 生成规则；长度范围；是否含空、单元素、负数、零、大整数（超过机器字长触发 Python 任意精度语义） | B1 数据集字段、M0 sanity | 用户 |
| P2 | 评价面固定 | 一致性判据：精确 `==` 逐例比对是否即最终 metric；metric 公式、单位、聚合方式（全例通过率 vs 首个失配即停） | 固定评价面、K1 decision rule | 用户 |
| P3 | 参照/oracle | 无 ground truth 的替代参照：候选=手工小序列期望值表（如 `[1,2,3]→6`）、独立第三次实现、或数学归纳界；选定后其局限需一并确认 | K2、M1 gate | 用户 |
| P4 | 未来写域 | 若后续执行：候选实现路径（proposed、尚不存在）、允许的输出/证据落点、tracker 路径；当前无写域，仅对话 | 候选范围、步骤 4/5 | 用户 |
| P5 | 环境与执行方式 | Python 版本约束；确认所有运行（含 probe 与解析）一律 `uv run python`；执行宿主 | M2、预算核算 | 用户 |
| P6 | 本批授权字段 | batch-authorization 全字段：scope、cost_limit/currency、compute_limit/compute_unit、run_limit/run_count_basis、per_attempt 上限、concurrency_limit、retry_limit、valid_for_hours/valid_until、batch_id、confirmation_basis | 步骤 3→4 推进；全部留 ❓ | 用户 |
| P7 | 停止权 | 未来作业的 stop authority 与所需授权形式 | Compute budget「Stop conditions」项 | 用户 |

**不变项重申**：步骤 3 仍 in-progress（等 P6 确认）；步骤 4/5 blocked（无写域不落盘）；步骤 6 pending——本轮仅交付本清单即停止。计划 status 不升级，仍为 **blocked draft，不可执行**。未启动实验、未配置环境；执行需用户另行授权。