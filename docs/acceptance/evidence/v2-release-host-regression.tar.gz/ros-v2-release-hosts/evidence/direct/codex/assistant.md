我先做只读侦察：确认安装根、读取 skill 全文引用的资源（references/templates）与被审材料路径。**本动作范围**：只读文件系统中的 skill 资源与候选 fixtures；**预算**：本轮 300s、fresh/build/GET/新实验均 0；不改全局/main/原项目，不联网、不安装、不编译、不写文件。

路径与 tip 实核 + 读取剩余资源（agents/openai.yaml、SKILL.md 落盘比对、`/tmp`→`/private/tmp` 解析、`.git` 存在性）。**范围**：只读校验；**预算**：剩余 ≈270s。

`/tmp → /private/tmp` 已确认为同一路径（路径缺口实核通过）。但 cwd 下 **无 `.git`**，且 `uv run python` 因用户级缓存目录不可写失败。重试剩余实核（SHA、openai.yaml、带可写缓存的 uv）。

导入源 tip 记录在 `skills-lock.json`，且 fixtures 内有两个无关的 fixture `.git`。查锁文件中的 tip 哈希，并取 SKILL.md 全文以逐字核对 todolist。

# proof-review · 只读证明审查（同上下文检查）

> 角色与预算明示：本回复为**同一主会话、同一模型、同一上下文窗口**内完成的一次审查。**独立 fresh 审查未运行**（用户给定 fresh 预算 = 0）。零写入、零编译、零联网、零新实验；唯一一次 Python 用 `uv run python`，且仅做算术取证。

---

## 0. 环境实核（路径缺口 + tip）

| 项 | 结果 | 证据 |
|---|---|---|
| 安装根 vs 工作区路径缺口 | **同一目录**（缺口不成立） | `readlink /tmp` = `private/tmp`；`pwd -P` = `/private/tmp/ros-v2-release-hosts/projects/codex`；故 `/tmp/ros-v2-release-hosts/projects/codex/.agents/skills` ≡ `/private/tmp/.../.agents/skills` |
| 安装源 tip `5efd2daffc68612def5e4660defb68db5a7780e3` | **核实一致** | `git --git-dir=/tmp/ros-v2-release-hosts/source/.git rev-parse HEAD` 返回同一 SHA |
| 被审材料存在 | 存在 | `fixtures/false-proof.md`（3 行，121B，sha256 `a624db22…ec2a`） |
| 落盘 playbook | 与给定全文一致 | `.agents/skills/proof-review/SKILL.md` sha256 `ac3aa205…5a15`；front-matter `disable-model-invocation: true` |
| cwd 是否 git 仓库 | **否**（此处无 `.git`） | `git rev-parse HEAD` → `fatal: not a git repository`；仅 `fixtures/setup-*` 下有无关 fixture `.git` |

> 说明：`skills-lock.json` 中 `proof-review` 仅记内容 `computedHash`（`e410764f…`），不含 tip；tip 的唯一本地可信来源是 `source` 仓库 HEAD，已如上核实。

---

## 1. Playbook todo-list（逐字保留步骤编号/原句/子列表，仅附状态与证据）

**## 1. 读取与界定**
1. 读取目标完整证明及所依赖的 definitions、assumptions、lemmas、theorems、propositions、corollaries；LaTeX 跟随范围内的 `\input` / `\include`，记录读不到的依赖。普通 Markdown 或无 theorem 环境的行文也按数学内容识别，不用环境名判定“无证明”。
   *[完成] 已读全 3 行；无 `\input`/`\include`；无引用的 def/lemma/theorem。*
2. 列出文件/行或章节/公式定位、实际读取范围、主定理和它的准确假设与结论。外部定理需要原始 statement 和适用条件；无法读取时标为未核实引用。
   *[完成] 定位见 §2；主命题 = L2，假设 = x 为实数（无其他限制），结论 = x²>0；无外部定理引用。*
3. 确定本次是 fresh review 还是同一次 repair 内的复审。fresh review 不沿用上次“通过”；复审可用旧问题编号追踪，但仍直接读取当前完整证明和依赖。
   *[完成] 非 repair 复审；本次为**同上下文检查**，无先前“通过”可沿用；**独立 fresh 审查未运行**。*

**完成条件**：每项输入已读或明确列为未读；范围、主命题及依赖清单确定。确无证明材料时返回“不适用”与查找范围后停止；只有证明描述而无足够论证时返回“材料不足”，不是“不适用”。
　*[满足] 输入全读；范围/主命题/依赖已定；有论断+推理，非“不适用/材料不足”。*

**## 2. 建立证明义务图**
按 [证明义务清单](references/proof-obligations.md) 建立全部六类记录：依赖 DAG、假设使用表、符号类型、显式量词陈述、微命题、极限顺序。
　*[完成] 六类见 §3。*
可在授权内让不同角色提取各节，但**提取者只记录作者声称的证明位置，不裁定已证明**。合并所有片段后再检查跨节符号和依赖循环；没有并行能力就顺序做。记录留在回复上下文中，不创建 ledger/state 文件。
　*[完成] 未委派；顺序完成；未创建任何文件。*
**完成条件**：每个非平凡步骤都有义务和出处，所有 theorem/lemma application 均列出侧条件；缺失出处与数学无效分别记录。
　*[满足] 唯一步骤 MC-1 有义务+出处；无定理应用；缺失侧条件与数学无效分别记录。*

**## 3. 审查与反例**
八个检查名：
- A DEFINITIONS
- B HYPOTHESIS DISCHARGE
- C INEQUALITY AUDIT
- D INTERCHANGE AUDIT
- E PROBABILITY MODE
- F UNIFORMITY & CONSTANTS
- G EDGE/DEGENERATE CASES
- H DEPENDENCY CONSISTENCY

　*[完成] A–H 逐项裁定见 §4；D/E/F 判 N/A 并给理由。*
细则、问题分类、双轴严重度、定理侧条件和反例策略在 [数学审查规则](references/review-rules.md)。每个问题给出原论断、定位、具体理由、下游影响以及最小修复方向；方向只是建议。
　*[完成] 已读 review-rules.md 全文；发现见 §5。*
若当前执行者写过被审证明，优先交给可用且已获授权的独立审查者；审查者直接读取同一完整原文和必要依赖，不能只看作者摘要。现有宿主不能提供独立角色时可以自查，但必须标为“非独立自查，独立复核未完成”。不虚构跨模型、审查身份或独立性。
　*[完成] 标注：**非独立自查；独立复核未完成（fresh 预算 0）**；不虚构独立性。*
对每个关键引理以及 CRITICAL/MAJOR 问题做反例尝试，保留失败尝试、候选和代数核实结果。数值搜不到反例不证明正确。存在原文外假设、需要改变命题或假设时，只报告需用户决定的变化，不偷偷补条件。
　*[完成] 反例尝试见 §6；未偷偷补 x≠0。*
**完成条件**：A–H 对每项适用命题已检查或注明未完成；每个关键引理都有反例尝试及结果；每条发现有可复查的理由。
　*[满足]*

**## 4. 整体闭合与可选重述检查**
整体闭合只在这里。核对：
- 声明与证明结论的量词、常数和一致性范围完全对应。
- 所有义务得到论证，或明确作为假设。
- 分支覆盖边界和退化情况。
- 归纳基、归纳步、归纳假设及递减度量正确。
- 每个 WLOG 有无损约化义务。
- 依赖 DAG 无循环。

　*[完成] 逐条见 §7；末两条 N/A（无归纳、无 WLOG）。*
区分“作者给出位置”和“此位置论证成立”。
　*[完成] 作者给出 L3 位置，但该位置论证**不成立**。*
用户指定重述检查（或 `--restatement-check`）时，再完整执行 [跨位置重述回归](references/restatement-check.md)。将漂移与证明正确性分开报告，缺失扫描不写成“无漂移”。
　*[未运行] 用户未指定 `--restatement-check`，默认未执行。*
**完成条件**：整体闭合各项给出依据或未完成项；重述检查报告实际覆盖范围和未读位置。
　*[满足] 闭合见 §7；重述检查状态=未运行。*

**## 5. 报告并停止**
使用 [审查报告结构](templates/review-report.md)…*[完成] 本回复采用该结构。*
仅在全部义务…可写“本次审查未发现阻断问题”…*[不满足条件] 存在有效反例 → 写“原命题被反驳”。*
编译状态固定据实写“本次未运行”…最后列出待用户决定事项。需要修复时只建议用户显式调用 `proof-repair`，不调用它、不开始下一轮或其他 Workflow。
　*[完成] 见 §8/§9；本轮到此停止。*

> 首轮补漏核对（对照 SKILL.md 原文，90 行）：结构行 grep 覆盖 `## 1–5`、8 个检查名、5 个完成条件、6 条闭合 bullet、权限边界段——**无漏项**。

---

## 2. 范围与结论（对应模板）

- **目标命题及原始假设、结论**：`fixtures/false-proof.md:2` — `for every real x, x²>0`；假设：x∈ℝ（无限制）；结论：x²>0。
- **已读文件/章节/公式及未读依赖**：已读 `fixtures/false-proof.md` 全 3 行；已读 SKILL.md 与三份 references + 模板全文。**未读依赖：无**（材料无外部 def/lemma/theorem/引用）。
- **本次角色**：**非独立自查（同上下文）**；可核实独立性边界 = 0（同一 session/模型/上下文，独立 fresh 审查未运行）。
- **结论**：**原命题被反驳**。理由：存在满足全部原假设（x∈ℝ）却违背结论的实例 x=0。
- **当前完成与未完成的检查**：A/B/C/G 已查并命中；D/E/F/H 已判 N/A 并给理由；重述检查未运行；独立复核未完成。

---

## 3. 证明义务（六类）

**① Dependency DAG**：节点 {ℝ, 平方运算, MC-1}；边 MC-1 依赖「∀x∈ℝ: x²≥0」+（未声明的）严格化步骤。无环（单节点链）。

**② 假设使用表**：无 lemma/theorem 应用。唯一推理 MC-1 隐含使用**未声明假设 `x≠0`**（因 x²>0 ⟺ x≠0），作者未列出、未证明 → 记 `HIDDEN_ASSUMPTION / CASE_INCOMPLETE`。

**③ Typed Symbol Table**
```
x   : real, ∀-bound, 无其他约束
x²  : real, 且 x² ≥ 0（∀x∈ℝ 成立；=0 ⟺ x=0）
```

**④ Canonical Quantified Statement**（审查转述，不改原命题）
```
∀x ∈ ℝ:  x² > 0
（无额外参数、无极限顺序）
```

**⑤ Micro-Claim Inventory**
```
MC-1
Context: ∀x∈ℝ（无假设）
⊢ Goal: x² > 0
Rule（作者声称）: x²≥0 ⟹ x²>0
Side-conditions: 需要 x≠0（即需建立 x²>0 ⟺ x≠0 的严格分支）
Claimed discharge: fixtures/false-proof.md:3「x²≥0, hence x²>0」
Review: 该 Rule 不成立（≥ 不能推出 >）；侧条件 x≠0 既未声明也未建立 → 在 x=0 失败
```

**⑥ Limit-Order Map**：N/A（无渐近、无极限、无 O/o/Θ）。

---

## 4. A–H 检查

| 检查 | 裁定 | 说明 |
|---|---|---|
| A DEFINITIONS | ✅ 无问题 | `x`（实数）、`x²`（普通实平方）含义明确，无歧义/换义。 |
| B HYPOTHESIS DISCHARGE | ⚠️ 命中 | 无定理调用；但「hence」依赖未声明的隐含条件 `x≠0`，未 discharge。 |
| C INEQUALITY AUDIT | ⚠️ 命中（核心） | 不等式链 `x²≥0 ⇒ x²>0` 为非严格→严格的非法升级，跳过中间步。 |
| D INTERCHANGE AUDIT | N/A | 无 limit/导数/期望/积分交换。 |
| E PROBABILITY MODE | N/A | 无 a.s./依概率/L²/期望/w.h.p.。 |
| F UNIFORMITY & CONSTANTS | N/A | 无 O/o/Θ/≲、无一致性参数、无 ε/常数。 |
| G EDGE/DEGENERATE CASES | ⚠️ 命中 | 退化例 x=0 恰是击破反例，作者未覆盖。 |
| H DEPENDENCY CONSISTENCY | ✅ 无问题 | 单节点链，无环、无语义循环、无前向引用。 |

---

## 5. 发现

**F1 — 原命题为假**
- status：INVALID ｜ impact：GLOBAL ｜ severity：**FATAL**（INVALID + GLOBAL）｜ category：A/CASE_INCOMPLETE（亦见 D/Scope 层面的 INVALID）
- location：`fixtures/false-proof.md:2`
- statement：`for every real x, x²>0`
- why wrong：∀x∈ℝ，x²≥0 且 x²=0 ⟺ x=0；故取 x=0 得 0²=0，不满足 >0。全称命题被单例反驳。
- counterexample：**x=0，已代数核实**（x∈ℝ 满足全部原假设）。
- affects：整条结果（唯一论断）——主结论整体失去依据。
- minimal fix direction（**不应用**）：需改变命题，属"待用户决定"。

**F2 — 推理无效**
- status：UNJUSTIFIED（作为推导，未能建立其结论；结论本身为假见 F1）｜ impact：GLOBAL ｜ severity：**FATAL/CRITICAL**（该步是通向假结论的唯一桥）
- location：`fixtures/false-proof.md:3`
- statement：`x²≥0, hence x²>0`
- why wrong：由 P≥0 不能推出 P>0；缺失分支 P=0（x=0）。该步等价于偷偷假设 `x≠0`。属 C 类不等式强度误用 + LOGICAL_GAP + CASE_INCOMPLETE。
- affects：F1 的结论未被建立；若命题被改为 x≠0 才可能（但那是改命题）。
- minimal fix direction（**不应用**）：补构造性侧条件 x≠0，或弱化结论——均触发命题/假设变更，属"待用户决定"。

---

## 6. 反例尝试

| 对象 | 策略/构造 | 原假设是否满足 | 代数检查结果 | 已核实反例/候选/失败及理由 |
|---|---|---|---|---|
| 命题 ∀x∈ℝ: x²>0 | Degeneracy：取 x=0 | 满足（x=0∈ℝ，无其他假设） | 0²=0，`0>0` 为假 | **已核实反例**（`uv run python` 佐证：`x=0.0 -> x**2=0.0, >0? False`） |
| 推理规则 P≥0 ⇒ P>0 | Degeneracy：取 P=0（x=0） | 满足前提 P≥0 | 前提真、结论假 → 规则无效 | **已核实** |
| 试图"救活"原命题 | 限制 x≠0 | — | 限制后 x²>0 为真 | **失败/不可用**：原命题是 ∀x∈ℝ 无限制；加限制=改命题（待用户决定） |
| 反例不存在之猜想 | 遍历反驳 ∀ | — | 单例即足以反驳全称 | 不成立 |

> 未找到反例不构成证明；本处为**找到反例**，故写"原命题被反驳"。

---

## 7. 整体闭合

- 量词/常数/一致范围：陈述与结论量词一致（单个 ∀ over ℝ），无常数、无一致范围冲突 —— **对应**，但命题本身为假。
- 全部义务得到论证或显式作为假设：**未闭合** —— MC-1 未建立，且含未声明假设 x≠0。
- 分支覆盖边界与退化情形：**未覆盖** —— x=0 退化分支漏缺，且正是反例。
- 归纳基/步/假设/递减度量：N/A（无归纳）。
- WLOG 无损约化：N/A（无 WLOG）。
- DAG 无环：**满足**（单节点）。
- 「作者给出位置」vs「论证成立」：作者在 L3 给出唯一论证位置，但**该位置论证不成立**。

**重述检查（用户指定时）**：**未运行**（默认；用户未指定 `--restatement-check`，材料亦无多位置重述）。

---

## 8. 证据与限制（对应模板）

- 有完整论证的部分：**无**（唯一推理 MC-1 无效；唯一"事实"∀x x²≥0 正确但不足）。
- 仍显式假定/依赖未核实外部定理的部分：无外部定理被引用。
- 未解决 gaps / 失败路线：F1 命题为假、F2 推理无效，均属需用户决定的结构性变更，非本轮可闭合。
- **本次文件写入：无。**
- **编译：本次未运行**（未引用任何已有编译记录）。
- **形式化/kernel 验证：未运行**；本审查非 Lean/Coq kernel 检查，模型共识不构成科研结论。
- **独立性：本次为同上下文（非独立）自查；独立 fresh 审查未运行（预算 0）。** 不虚构跨模型/审查身份。
- 工具限制：无联网、无安装、无外发；`uv run python` 仅用一次且仅做算术取证；无新实验。

---

## 9. 待用户决定

1. 是否**修改命题**：原命题 `∀x∈ℝ: x²>0` 为假。可选方向（仅建议，未应用）：弱化为 `x²≥0`，或限定 `x≠0`，或改条件式 `x≠0 ⟹ x²>0`。
2. 是否**补独立复核**：本次为同上下文自查，用户给定 fresh 预算 0，故**独立 fresh 审查缺失**；如需可另行授权一次真正独立的 fresh review。
3. 如需修复：请**显式调用 `proof-repair`**（本轮不自动调用、不启动下一轮或其他 Workflow）。

到此停止。