本轮只做只读验收：核实安装入口与 `fixtures/setup-conflict`，读取适用指令、触发的 playbook/叶文件、旧材料和结果；在对话中展示冲突与拟变更，不写文件、不搬迁、不改日志或周边 `KEEP`。新项目指令位置仍视为未确认。

剩余预算：主会话最多 300 秒；fresh/build/GET/新实验均为 0；联网、外发、安装、编译和 Git 写操作均为 0。先检查路径、文件类型和指令文件位置。


路径已实核：`/tmp/.../.pi/skills` 和 `/private/tmp/.../.pi/skills` 均可访问，旧工作区的五个研究文档、角色表及 `AGENTS.md` 都存在。宿主目录不是 Git 仓库，因此不能用其 HEAD 验证安装源 tip；不会把你给出的 tip 当作已独立验证的结果。

下一动作仍限只读：读取已安装 setup playbook、冲突规则、模板和旧工作区全部相关文件，记录字节基线。剩余预算不变，写入授权为 0。


已逐项读取并对照 playbook 全文及全部四份模板、冲突规则和旧材料。没有缺失种子；`AGENTS.md` 的实际 Research OS 区块与按 `research/` 代入的模板一致，前后的 `KEEP-OUTSIDE-BEFORE` / `KEEP-OUTSIDE-AFTER` 均在区块外。旧日志明确是 TOY baseline，不能视为新实验或新独立 review。

下一动作只读：记录七个旧文件的字节数与 SHA-256、核对导航和模板相同性，读取安装锁记录；按步骤 2 仅调用本地 `pi --list-models` 查询，不启动另一模型会话。主会话仍受 300 秒上限约束；fresh/build/GET/新实验/写入预算仍全部为 0。


只读对照发现的主要问题不是现有内容冲突，而是**输出目标与授权未确定**：

- 已有政策与默认模板逐字相同；没有理由替换。
- 已有角色表的模型 `cliproxy/glm-5.3-flash` 在本轮清单内，但旧文件中的“本 session”确认记录不能冒充本轮八角色确认；本轮不生成新角色表。
- 旧工作区可直接沿用；五份文档均存在，不补种子、不改日志。
- 旧 `AGENTS.md` 只有一个 Research OS 区块，边界在 `## Local commands` 之前；不能因“新项目指令位置未确认”就默认改旧文件或在宿主根创建文件。

下一动作只读核实本地安装源 HEAD、已安装 setup 文件与源文件一致性，并复核旧文件和全局文件元数据。之后展示逐字保留编号、原句及子列表的对话 todolist，停在位置确认门；不执行 Write。fresh/build/GET/新实验/写入剩余预算仍为 0，300 秒会话时限尚未达到。


本地安装源 HEAD 已实核为你指定的 `5efd2daffc68612def5e4660defb68db5a7780e3`。源中 setup 的真实路径是 `skills/general/setup-research-os/`；刚才两个预设比较路径均不存在，所以那次**未完成源/安装内容比较**，不能计为通过。

下一动作仅对这个实际路径做只读目录比较，补上这项证据。已复核七个旧文件的 SHA-256 全部未变，全局角色文件 mtime 未变。距首次计时约 96 秒，300 秒时限约余 204 秒；其他预算仍为 0。


## 只读验收结果

**未写入任何文件，未搬迁材料，未启动研究流程。停在新项目指令位置确认门。**

- 安装入口已实核：`/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/setup-research-os/`。
- 本地安装源 HEAD：`5efd2daffc68612def5e4660defb68db5a7780e3`。
- 源中实际路径：`/tmp/ros-v2-release-hosts/source/skills/general/setup-research-os/`；与安装目录执行 `diff -qr`，结果为 **0，无差异**。
- 沿用工作区：`fixtures/setup-conflict/research/`，材料原位保留。
- 七个旧文件的 SHA-256 复核均与读取基线一致。
- 全局 `~/.agents/pstack-models.md` 未读取正文，mtime 两次均为 `1791006579`。
- 本轮没有新增模型会话、实验、编译、联网、安装、任务文件或独立 review。这里只是只读对照，不是新独立审查。

### 冲突与拟变更

| 实际路径 | 原有内容与核对结果 | 拟处理；尚未授权 |
|---|---|---|
| `fixtures/setup-conflict/research/README.md` | 明确标注 `integer-sum-toy` 验收 fixture；三个导航目标均存在 | 原字节保留，不搬迁 |
| `fixtures/setup-conflict/research/project.md` | 用户旧材料，含 `MATERIAL-DO-NOT-MOVE` | 全文保留，不套种子 |
| `fixtures/setup-conflict/research/findings.md` | 已存在，初始化未生成研究发现 | 全文保留 |
| `fixtures/setup-conflict/research/research-log.md` | 旧 TOY 日志，未运行真实实验，未知成本仍未知 | **整文件保留，不追加 setup 记录，不插字段** |
| `fixtures/setup-conflict/research/compute-policy.md` | 与已安装默认模板逐字相同，`cmp` 返回 0；额度为 0，非运行授权 | 无需替换 |
| `fixtures/setup-conflict/.agents/research-os-models.md` | 已有八角色，均为 `cliproxy/glm-5.3-flash \| off` | 原样保留；不把旧确认冒充本轮确认 |
| `fixtures/setup-conflict/AGENTS.md` | 只有一个实际 Research OS 区块；其内容与 `research/` 模板一致 | 旧文件原样保留；**不能默认把它认定为新输出目标** |
| 新项目指令文件 | 项目根、文件位置及相对导航路径尚未确定 | 不创建、不拟造已批准路径 |

本轮 `pi --list-models` 成功；旧表模型出现在清单中，thinking 为 `yes`，但**档位未在清单中分开列出**。本轮没有逐角色确认，因此不展示或生成“本轮已确认”的新八行角色表。

**当前拟写入集合为空。** 这不是完整写入草稿已获批，也不是初始化全部完成。

### 旧材料与实际指令区块

`fixtures/setup-conflict/research/project.md`——原样保留：

```markdown
# Existing toy material

MATERIAL-DO-NOT-MOVE
```

`fixtures/setup-conflict/research/research-log.md`——原样保留：

```markdown
# Existing toy research log

fixture baseline bytes; no real experiments; unknown costs stay unknown.
```

日志为 **102 字节**，前后 SHA-256 均为：

```text
0fe3a308c49d0076e78936cb0edd1d79302ca05dc3016ba857b62baa5984ddb0
```

`fixtures/setup-conflict/AGENTS.md`——以下为实际全文，不是新目标的获批草稿：

```markdown
# Existing instructions

KEEP-OUTSIDE-BEFORE

## Research OS

研究工作区位于 `research/`。处理本项目的研究任务前，先读 [研究导航](research/README.md)，再读取其中与当前任务相关的原始材料。材料保持原有自然格式和位置。

Idea Discovery、Validation、Paper Writing and Improvement 均由用户显式发起，互不自动启动。内部能力仅在当前授权职责、写入范围与资源内执行；缺少材料、工具或授权时说明缺口。

初始化补齐基础导航、项目级角色表和默认算力政策。默认政策的额度是 0，不是运行许可。各 Workflow 的具体产物在用户首次授权使用时创建。环境、付费资源和远程副作用由项目用户决定。

## Local commands

KEEP-OUTSIDE-AFTER
```

区块边界为 `## Research OS` 至 `## Local commands` 之前；两处 `KEEP` 均属于区块外内容。整文件 **798 字节**，前后 SHA-256 均为：

```text
14c78d2f02a09243f9f2cabbb0ccfb7b06856d2a16f596615fbb5fbf840ee120
```

## 对话 todolist：保留 playbook 原编号、原句与子列表

首次已逐项对照已安装全文补漏；以下不补造第 3、7 步。仅附状态与证据。后续步骤的只读预检不代表跨越确认门执行。

### 1. Explore

只读检查当前项目：

- 确认项目根目录，读取适用的项目指令和 README。
- 检查根目录 `CLAUDE.md`、`AGENTS.md`，以及已有 `## Research OS` 区块。
- 查找 `.agents/research-os-models.md`、工作区里的 `compute-policy.md`、`README.md`、`project.md`、`findings.md`、`research-log.md`。已有非空工作区优先沿用，例如 `research/`、`notes/`、`docs/research/`。
- 记录这些文件是否存在，以及角色表、政策、研究日志的当前字节。全局 `~/.agents/pstack-models.md` 只记录路径和修改时间，用来事后核对它没变。
- 区分文件、目录、符号链接与不可读对象。指令文件链接指向项目外、链接失效或访问被拒时，停止该写入。

完成条件：能列出项目根、已有导航、角色表、政策、日志、指令文件候选，以及未知项。此时没有任何写入。

**状态／证据：** 旧项目根为 `fixtures/setup-conflict/`；相关七个文件均为可读普通文件，工作区为目录。旧根有 `AGENTS.md`，无 `CLAUDE.md`；适用旧指令、导航、角色表、政策、材料及日志已全文读取。新输出项目根与指令位置仍未知。零写入。

### 2. 列出可用模型

向当前宿主查询本 session 真正可用的模型。Pi 用 `pi --list-models`，读出 provider、model id，以及该行 thinking 是 yes 还是 no。其他宿主用它自己的模型列表命令；命令失败或结果不含模型 id 时，说明清单未知并停止，不编造 slug。

每条候选记成 `provider/model-id`。thinking 为 no 的模型只允许 `off`。thinking 为 yes 的模型只在 `off`、`minimal`、`low`、`medium`、`high`、`xhigh`、`max` 中选择该模型实际支持的档位；清单没写具体档位时，向用户标出“档位未在清单中分开列出”，由用户选定其中一档。

完成条件：后续推荐的每个模型都能在这次命令输出里逐字找到。

**状态／证据：** 已执行本地 `pi --list-models`，含 provider、model id、thinking 列。未发起模型调用。旧模型 `cliproxy/glm-5.3-flash` 在清单内；档位未在清单中分开列出。未推荐新模型。

### 确认模型

八个角色固定为 orchestrator、literature、ideator、implementer、analyst、prover、writer、reviewer。一次只确认一个角色，推荐放在前面：一个清单内的 `provider/model-id`，加一个该模型支持的 thinking。

Gate: model-confirm | before=role-table-write | approval=explicit-user | source=SKILL.md#确认模型

用户给出的 slug 不在本轮清单中时，停下并重新询问。未确认的模型不进入草稿，也不写入文件。八个角色都确认后，才展示整份角色表：每行 `角色: provider/model-id | thinking`，不多行、不缺行。

完成条件：八个角色各自有一条用户确认过的、且模型属于本轮清单的角色行。

**状态／证据：** 本轮未确认，门未通过。旧表只作旧材料读取；不重写、不生成新表。

### 4. Present

简述哪些文件复用、哪些缺失、哪些需要决定。推荐可见的 `research/`；已有工作区沿用。材料留在原处。

默认政策按 [compute-policy.md](templates/compute-policy.md) 整文件起草。它的额度是 0，范围和有效期是未指定。向用户说明：默认政策不是本批运行许可，不能据此启动实验或付费调用。

完成条件：用户已看到事实、建议和预计写入范围。

**状态／证据：** 冲突与拟变更已在上表展示。旧工作区无缺失基础文档；政策与模板逐字相同，默认政策不是本批运行许可。当前写入集合为空。

### 5. Ask

一次只问一个尚未决定的问题：

1. 工作区有歧义时，问沿用哪一个。没有工作区时，问是否采用 `research/`。同名文件不能当目录。
2. 项目名称或说明无法从材料确定时，只问缺失项，或允许跳过。
3. 指令文件优先已有 `CLAUDE.md`，否则已有 `AGENTS.md`。两者都有时只改前者。都没有时询问创建哪一个，也允许暂不创建。
4. 内容冲突按 [冲突与重复执行规则](references/conflicts.md) 逐项选择。角色表和政策文件若与确认稿不同，选择保留现状或整文件替换，不做半文件拼接。

完成条件：每个拟写入项的路径和冲突处理已确定。用户拒绝时零写入并停止。

**状态／证据：** `references/conflicts.md` 已全文读取。工作区沿用已明确；新项目指令位置未明确，在此停门。旧项目存在 `AGENTS.md` 不等于获得修改旧项目的许可。

### 6. Draft

读取 [基础文档种子](templates/workspace.md)、[角色表形状](templates/research-os-models.md)、[默认算力政策](templates/compute-policy.md) 和 [研究日志字段](templates/research-log.md)。只用所需部分。

向用户展示完整草稿：

- `.agents/research-os-models.md` 的全文，八行都是已确认模型。
- 工作区 `compute-policy.md` 的全文。用户没有另给一批真实授权时，使用默认模板原文。
- 缺失的导航、项目说明、findings、研究日志。日志只在文件不存在时创建。
- 指令文件中拟写入的 `## Research OS` 区块，以及保留不动的其余内容。

导航只链接已经存在或本批会创建的文件。

完成条件：每一处拟写入内容都已展示，没有隐藏文件。

**状态／证据：** 四份叶模板均已全文读取；只读对照完成。未进入完整新草稿：位置未确认、模型确认门未通过。旧 AGENTS 实际全文及保留内容已展示；无隐藏拟写入项。

### 确认写入

Gate: write-confirm | before=workspace-write | approval=explicit-user | source=SKILL.md#确认写入

询问是否按这份完整草稿写入。沉默、推荐答案、单个路径选择和“已安装”都不算同意。用户改草稿后，重新展示受影响全文再确认。用户拒绝则零写入。

若确认稿与目标文件字节相同，报告“无需写入”并停止。

完成条件：当前全文获得明确写入同意，或已停止。

**状态／证据：** 无写入批准；未把沿用工作区、安装完成或路径事实当作授权。此次停在位置确认，不请求对尚未成立的完整草稿进行写入批准。

### 8. Write

写入前重新读取全部目的文件。内容与 Draft 所见不一致、新建路径已经出现，或指令文件候选的优先级变了，就停止整批，回到 Ask。

按获批全文写入：

- 角色表和政策文件整文件替换。确认稿与现状字节相同时跳过。不在文件末尾追加第二套角色或第二套额度。
- 只创建缺失的导航、项目说明、findings、研究日志。研究日志已存在时不打开它来改写。
- `## Research OS` 区块原位更新一次；没有时追加一次。其他区块逐字保留。

不创建、不修改 `~/.agents/pstack-models.md`。遇到写入错误立即停止，报告已成功和未完成的文件。

完成条件：获批内容已写入且没有额外文件；或失败已报告并停止。

**状态／证据：** 未执行。无 write/edit、目录创建、搬迁、覆盖或 Git 写操作。

### 9. Verify

重新读取每个获批文件，对照确认稿的字节、角色行数、政策字段和链接目标。核对：

- `.agents/research-os-models.md` 恰好八个角色，每个模型都属于写入前那份清单。
- `compute-policy.md` 仍写明不是运行授权。
- 既有 `research-log.md` 的字节与 Explore 时相同。
- `~/.agents/pstack-models.md` 的修改时间与 Explore 时相同；本来不存在则仍然不存在。
- Research OS 区块只有一份，没有多余空目录或研究产物。

完成条件：全部获批变更已逐项核对，结果和局限已告诉用户。

**状态／证据：** 无获批变更，因此不是写后验收。只读复核：旧表八角色、模型在本轮清单内；政策非运行授权；七个旧文件哈希未变；全局 mtime 未变；实际 Research OS 区块一份。不能据此宣称本轮模型确认或新独立 review 完成。

### 10. Stop

告知角色表、政策和工作区导航的实际路径。重复运行只补缺失项；角色表和政策在用户确认新全文后整文件替换。到此停止，不启动研究流程。

**状态／证据：** 本轮只读验收停止。实际路径：

- 角色表：`fixtures/setup-conflict/.agents/research-os-models.md`
- 政策：`fixtures/setup-conflict/research/compute-policy.md`
- 导航：`fixtures/setup-conflict/research/README.md`

---

**唯一待确认问题：新项目指令文件拟放在哪个项目根下、哪个项目内路径？也可以选择“暂不创建”。** 路径选择只解除位置歧义，不构成写入批准。