当前路线：**paper-writing / systems**。本轮仅做已安装 tip 的只读组合验收；不重跑科研流程，不读取通用 writing 入口替代 systems 入口。

下一动作范围：读取 systems playbook 全文。剩余预算：一次主会话、300 秒上限；fresh / build / GET / 新实验均为 0；写入域未授权，仅在对话中记录清单。


### 对话 todolist

1. 读 `skills/writing-cycle/systems-paper-writing/SKILL.md` 全文，并按它执行。写入、图表、源码、文献、报告或付费调用之前，停在该文件的授权门。授权未确认时只做只读解析。补实验须另行授权。  
   状态：in-progress；证据：已读 `research-os/playbooks/paper-writing-systems.md`，下一步读取安装根下的叶正文。
2. 阶段、被组合能力与审查输入只读 `skills/writing-cycle/systems-paper-writing/references/composition-map.md`。不把该文件正文抄进本 playbook，也不另定 audit 输入。  
   状态：pending。
3. Systems 专属纪律读全文：
   - `skills/writing-cycle/systems-paper-writing/references/systems-writing-methods.md`
   - `skills/writing-cycle/systems-paper-writing/references/evaluation-methods.md`
   - `skills/writing-cycle/systems-paper-writing/references/checklist.md`
   - `skills/writing-cycle/systems-paper-writing/references/venue-and-reviewer.md`
   - `skills/writing-cycle/paper-plan/references/systems-blueprints.md`
   - `skills/writing-cycle/paper-plan/references/systems-patterns.md`  
   状态：pending。
4. 按叶 skill 的顺序级联，并读完下列全文：
   - `skills/writing-cycle/paper-plan/SKILL.md`
   - `skills/writing-cycle/academic-plotting/SKILL.md`
   - `skills/writing-cycle/paper-drafting/SKILL.md`
   - `skills/writing-cycle/paper-compile/SKILL.md`
   - `skills/writing-cycle/paper-claim-audit/SKILL.md`
   - `skills/writing-cycle/citation-audit/SKILL.md`
   - `skills/writing-cycle/claim-stress-test/SKILL.md`
   - 稿件含定理、引理或证明时再读 `skills/validation-cycle/proof-review/SKILL.md`  
   状态：pending。
5. 证据面缺口保持叶 skill 的标签，包括 `MISSING SCALABILITY EVIDENCE`。不把缺失数据写成已有结果。  
   状态：pending。
6. 交付口径按叶 skill：`draft` 或 `submission-candidate`。候选稿与审查报告交付后停止。  
   状态：pending。

已逐项对照 playbook：六个步骤、步骤 3/4 的全部子列表均已保留，无漏句。停止条款也保持：不启动修复、投稿、上传、补实验，不打开通用或 ML 写作入口。

下一动作范围：只读实际安装路径 `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/systems-paper-writing/SKILL.md` 全文；不执行写作或构建。剩余预算：仍限本次主会话 300 秒窗口；fresh / build / GET / 新实验 0，写入未授权。


**已停在 systems 专业授权门，未继续写作流程。**

实际读取并核实存在的文件：
- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/research-os/playbooks/paper-writing-systems.md`：全文。
- `/tmp/ros-v2-release-hosts/projects/pi/.pi/skills/systems-paper-writing/SKILL.md`：全文。

停止依据：叶正文 `§1 授权门` 的 `workflow-authorization`。缺确认时只能只读解析并形成执行草案，不能进入写入或付费／远程／高成本调用。此次未批准输出路径、构建及 fresh review，且用户明确要求在此门停止。

### 门前核对

| 项目 | 本轮状态 |
|---|---|
| 输入范围 | 用户指定 `fixtures/systems/`，TOY list/set 系统实现微基准；**尚未读取材料目录，不能声称已核验原始结果** |
| 系统证据面 | 用户明确无 scalability 结果；保留 **`MISSING SCALABILITY EVIDENCE`**，不外推曲线；其他证据面未核实 |
| Venue、语言、格式 | 未确认；未设置默认 venue、页数、模板或 deadline |
| 输出路径与写入清单 | 未批准；仅对话输出 |
| 构建入口与执行 | 未确认入口；build 预算 0，未编译 |
| 独立审查 | fresh 预算 0，未执行；未将旧审查或自查算作 fresh review |
| 修订轮数 | 未确认；未采用默认轮数开跑 |
| 交付口径 | 未交付候选正文或审查报告，因此本轮不宣称已交付 `draft` 或 `submission-candidate` |
| 外部服务、补实验 | 未获批，预算 0，未执行 |

### Todolist 状态更新

上条清单的**步骤编号、原句及全部子列表保持不变**，只更新状态与证据：

1. **blocked** — 叶全文已读；停在 `systems-paper-writing/SKILL.md §1`，不能把全文读取等同于整个步骤完成。
2. **pending（授权门阻塞）** — 未读 `composition-map.md`。
3. **pending（授权门阻塞）** — 六项专属资源均未读取。
4. **pending（授权门阻塞）** — 未级联任何下游叶入口。
5. **pending（授权门阻塞）** — 对话保留 `MISSING SCALABILITY EVIDENCE`；尚未核验或写入计划、契约、报告。
6. **pending（授权门阻塞）** — 未交付候选稿或审查报告。

**实际副作用：无。** 未创建任务文件，未写入、删除或覆盖文件；未读取通用／ML writing 入口；未联网、外发、安装、运行 Python、新实验或编译。

用户给定安装源 tip 为 `5efd2daffc68612def5e4660defb68db5a7780e3`；本轮仅核实上述安装文件及其正文，**未独立验证该 commit 与安装内容的一致性**。本轮到此停止。