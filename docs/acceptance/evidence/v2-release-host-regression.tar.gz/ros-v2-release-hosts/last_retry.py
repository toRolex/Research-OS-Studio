from run import run
from pathlib import Path
import json,concurrent.futures
E=Path('/tmp/ros-v2-release-hosts/evidence')
def sid(h):
 for l in (E/'experiment-plan'/h/'stdout.jsonl').read_text().splitlines():
  try:x=json.loads(l)
  except:continue
  if h=='claude' and x.get('type')=='system' and x.get('session_id'):return x['session_id']
  if h=='codex' and x.get('type')=='thread.started':return x['thread_id']
def nt(h):
 run(h,'new-task-retry','new task 我该从哪开始？未来回复审稿，当前只要推荐不要执行。只读fixtures/toy-reviews.md与fixtures/false-proof.md，入口原文route-only逐字清单必须遵守；推荐关键行为实读正确叶全文，若limit或shell聚合结果缺叶就续读，不虚报已读。不得整理旧任务状态/TaskUpdate。此次是唯一针对原完成条件的重试，不给任何新执行授权。',resume=sid(h))
def dr():
 run('codex','direct-uv-retry','proof-review 直接点名只读审查 fixtures/false-proof.md，固定命题不改、不修复，亲读原文+叶与必要资源。全Python严格UV，包括路径probe、解析和fallback，环境不可写可用shell pwd -P/readlink/shasum，不准裸python/python3；不能uv失败就裸Python兜底，不需数值程序即可符号反例。只读不创建缓存或脚本，fresh预算0诚实同上下文。')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(lambda f:f(),[lambda:nt('claude'),lambda:nt('codex'),dr]))
