from run import run
from pathlib import Path
import json,concurrent.futures
E=Path('/tmp/ros-v2-release-hosts/evidence')
def sid(h):
 for l in (E/'experiment-plan'/h/'stdout.jsonl').read_text().splitlines():
  x=json.loads(l)
  if h=='claude' and x.get('type')=='system' and x.get('session_id'):return x['session_id']
  if h=='codex' and x.get('type')=='thread.started':return x['thread_id']
def one(h):run(h,'new-task-command-retry','new task 我该从哪开始？未来回复审稿，当前只要推荐不要执行。只读fixtures/toy-reviews.md与fixtures/false-proof.md；原文route-only首次清单应逐字完整，推荐关键行为实读正确叶全文，不用limit40或错误shell声称全文。proof-review并非只用于授权修复后，若推荐备选请从当前原文核实适用范围。不得整理旧任务TaskUpdate、不执行rebuttal。此次仅纠正harness slash命令未执行的重试，不扩大预算。',resume=sid(h))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(one,['claude','codex']))
