from pathlib import Path
import json,hashlib,re,tarfile
R=Path('/tmp/ros-v2-final-contract')
summary={}
for case in ('expired','valid','expired-retest','valid-retest'):
 P=R/case
 before=json.loads((R/f'evidence/{case}.before.json').read_text())
 after={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in P.rglob('*') if p.is_file()}
 frozen=['plan.md','method.py','evaluator.py','meter.py','results.csv','compute-policy.md','.agents/research-os-models.md','findings.md']
 unchanged=all(after[k]==before[k] for k in frozen)
 events=[]; bare=[]; jobs=[]; model_records=[]
 sessions=[R/f'evidence/{case}.session.jsonl',*sorted((P/'sessions').glob('*.jsonl'))]
 for s in sessions:
  for lineno,l in enumerate(s.read_text().splitlines(),1):
   e=json.loads(l)
   if e.get('type') in ('model_change','thinking_level_change'):model_records.append({'session':str(s.relative_to(R)),**e})
   m=e.get('message',{})
   if m.get('role')=='assistant':
    for b in m.get('content',[]):
     if b.get('type')=='toolCall':
      record={'session':str(s.relative_to(R)),'line':lineno,'name':b['name'],'arguments':b['arguments']};events.append(record)
      if b['name']=='bash':
       cmd=b['arguments']['command']
       if re.search(r'(?<!uv run )\bpython3?\s+(?:-c|-|[\w./]+\.py)',cmd):bare.append(record)
       shell_part=cmd.split("<<",1)[0]
       if re.search(r'uv run python meter\.py (?:fail|success)',shell_part):jobs.append(record)
 meters=[json.loads(p.read_text()) for p in sorted((P/'results').glob('*.meter.json'))]
 costs=sum(m['cost_usd'] for m in meters);cpu=sum(m['cpu_core_hour'] for m in meters)
 if 'expired' in case:
  assert not jobs and not list((P/'results').glob('*'))
  assert before['research-log.md']==after['research-log.md']
 if case=='valid-retest':
  assert len(jobs)==2 and [m['exit_code'] for m in meters]==[7,0]
  assert not bare
  assert len(list((P/'sessions').glob('*.jsonl')))==3
  assert len(meters)==2 and cpu<.004 and costs==0
  log=(P/'IMPROVEMENT_LOG.md').read_text()
  for s in (P/'sessions').glob('*review*.jsonl'):
   finals=[]
   for l in s.read_text().splitlines():
    m=json.loads(l).get('message',{})
    if m.get('role')=='assistant' and m.get('stopReason')=='stop':finals.append(''.join(b.get('text','') for b in m.get('content',[]) if b.get('type')=='text'))
   assert finals and finals[-1] in log
 assert unchanged
 summary[case]={'frozen_unchanged':unchanged,'job_calls':len(jobs),'bare_python_calls':len(bare),'new_files':sorted(set(after)-set(before)),'changed_files':sorted(k for k in before if before[k]!=after[k]),'actual_cpu_core_hour':cpu,'actual_cost_usd':costs,'meter_exit_codes':[m['exit_code'] for m in meters],'models':model_records}
 (R/f'evidence/{case}.after.json').write_text(json.dumps(after,indent=2))
 (R/f'evidence/{case}.tools.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
(R/'evidence/mechanical-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
# Scan payload text, plus decoded JSON strings. Emit no potential secret values.
patterns={
 'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'provider_key':r'\b(?:sk-[A-Za-z0-9]{24,}|ghp_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,}|AKIA[A-Z0-9]{16})',
 'bearer':r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}',
 'url_userinfo':r'https?://[^\s/@:]+:[^\s/@]+@',
 'signed_query':r'(?i)(?:X-Amz-Signature|X-Amz-Security-Token|X-Goog-Signature|[?&]token)=[^\s&"\\]{16,}',
}
candidates=[]
for p in R.rglob('*'):
 if not p.is_file() or p.name in ('SHA256SUMS.json','scan.json'):continue
 text=p.read_text(errors='replace')
 if p.suffix in ('.json','.jsonl'):
  def strings(value):
   if isinstance(value,str):return [value]
   if isinstance(value,list):return [s for item in value for s in strings(item)]
   if isinstance(value,dict):return [s for item in value.values() for s in strings(item)]
   return []
  decoded=[]
  try:
   records=[json.loads(text)] if p.suffix=='.json' else [json.loads(l) for l in text.splitlines() if l.strip()]
   decoded=[s for record in records for s in strings(record)]
  except (ValueError,TypeError):pass
  text+='\n'+'\n'.join(decoded)
 for category,pattern in patterns.items():
  hits=list(re.finditer(pattern,text))
  if hits:candidates.append({'path':str(p.relative_to(R)),'category':category,'count':len(hits)})
scan={'regular_files':sum(p.is_file() for p in R.rglob('*')),'categories':list(patterns),'candidates':candidates,'value_output':False}
(R/'evidence/scan.json').write_text(json.dumps(scan,indent=2))
assert not candidates,candidates
manifest={str(p.relative_to(R)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
(R/'evidence/SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
archive=Path('/Users/rolex/Documents/Codes/githubProject/MyProject/Research OS Studio.v2-final-contract-fixes/docs/acceptance/evidence/v2-final-contract-fixes.tar.gz')
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(R.rglob('*')):
  if p.is_file():tf.add(p,arcname='ros-v2-final-contract/'+str(p.relative_to(R)),recursive=False)
with tarfile.open(archive) as tf:
 files={m.name:tf.extractfile(m).read() for m in tf.getmembers() if m.isfile()}
 for key,value in manifest.items():
  b=files['ros-v2-final-contract/'+key]
  assert len(b)==value['bytes'] and hashlib.sha256(b).hexdigest()==value['sha256']
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_payloads':len(manifest),'scan':scan,'cases':{k:{kk:vv for kk,vv in v.items() if kk not in ('models','new_files')} for k,v in summary.items()}},ensure_ascii=False,indent=2))
