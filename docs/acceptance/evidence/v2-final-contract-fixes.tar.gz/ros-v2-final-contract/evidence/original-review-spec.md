Agent "v2-final-review-spec" finished — exact final message:

需修改，3项：

- **P1** `skills/general/research-os/playbooks/improvement.md:21`：补实验只核attempt名额，未读取批次日志、核过期/累计/预留/并发/重试；叶也未补齐。违反approved「政策与日志」、#37「门与算力」；现有improvement零实验轨迹不覆盖此分支。
- **P2** `skills/general/research-os/SKILL.md:46–60`：八角色仅说明格式，未给执行步骤角色绑定；全skills无实际`Role:`引用（只有示例）。setup角色配置无法可靠驱动各阶段。违反approved「模型」、#37「Setup与配置」。
- **P2** `scripts/check-skills.py:837–876`：只核键存在；内存反例中空currency、乱valid_until、重复cost_limit均零错误。违反approved「政策与日志」、#40 AC6。

已读固定diff、全部commit、原票及报告；checker当前绿不代表行为绿。旧失败未冒充新tip；REVISE/WARN正确停交、待tag/summary不计bug。只读未改文件。