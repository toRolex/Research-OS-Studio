# 最终报告 — research-improvement（batch topup-valid，TOY 验收）

**结论：positive 达成 — Round 2 score 9/10 + verdict `ready`（词表 ready/almost/not ready 中达到 ready）**

## 分数轨迹
| 轮次 | 分数 | Verdict |
|---|---|---|
| Round 1 | 3 | not ready |
| Round 2 | 9 | **ready** |

## 执行摘要
- **门与基线**：loop-authorization 与 experiment-topup 门逐项核对通过（状态/依据/时钟/scope/累计/per_attempt/名额/并发/retry）；基线冻结至 `baseline/`，冻结文件（plan/method/evaluator/meter/results.csv/compute-policy）经 diff 验证全程未改，无 `__pycache__`（PYTHONDONTWRITEBYTECODE=1）。
- **补实验（2/2 attempts，串行，并发 1）**：
  - `a1`：真实 **exit 7**（故意诊断失败，按要求保留），实耗 6.144167e-06 cpu-core-hour
  - `a2`：真实 **exit 0**，completed，n=5，**measured MAE 0.0**（我独立重算并与文件核对一致），实耗 6.925556e-06 cpu-core-hour
  - 实测合计 1.307e-05 ≤ 0.004；cost 0 USD；每次 attempt 前有预留、后有 raw 实账（meter RUSAGE_CHILDREN sidecars 为准）
- **第三次 attempt：明确拒绝，未运行** — 理由为 attempt 名额耗尽（run_count_basis=attempt，run_limit=2，a1 失败同占名额）；retry_limit=3 与剩余累计预算均不恢复名额。账面有拒绝记录。
- **三次 fresh dispatch**（模型 dialogs 3/3）：review1（cliproxy/gpt-6.1-sol | medium，`--tools read`）→ implementer（cliproxy/glm-5.3-flash | high，持单一记账/启动权限，我暂停写账待其完成并亲读账与原始结果核实）→ review2（同 review1 规格，只给 primary 路径/原 findings/当前 diff/问题/标准）。每次独立 session、无 fork/resume。
- **修复**：CLAIMS.md 证据化（实测引用，scope 不变、无新颖性声明）、账目闭合、估计/实测分离陈述（R1-3 的“给 meter 加 enforcement”因代码冻结记为 rejected）。
- **停止原因**（首要为正面结论）：正面结论 9+ready ∥ 最大轮数 2 达到 ∥ attempt 名额 2/2 用尽 ∥ 时钟未过期（12:53:42Z < 15:39:47Z，未延长）。

## 未解决项
- **R2-1**（低）：`current.diff` 补丁格式与实际 CLAIMS.md 不完全一致 — 第二轮只审不再修，留待用户决定是否重新生成。
- **R2-2**（低，已记录）：第三 attempt 拒绝与“无覆盖”属账本级程序性断言，无独立回溯审计。

## 资源
CPU 实耗 1.307e-05 / 0.004 cpu-core-hour；wall 8m42s / 45min；scope 内存储 ~2MB / 3MB；dialogs 3/3（不计科研 job 额度）。

产物：`IMPROVEMENT_LOG.md`（含两轮逐字原始审查回应）、`research-log.md`（完整账目与拒绝记录）、`results/a{1,2}.json` + sidecars、`reviews/review{1,2}.*`、`prompts/`、`sessions/`、`baseline/`、`evidence/`。未自封 publication-ready；a1 失败路线保留；未启动任何其他顶层入口。