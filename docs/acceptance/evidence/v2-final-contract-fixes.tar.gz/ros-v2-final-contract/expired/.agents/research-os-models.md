orchestrator: cliproxy/glm-5.3-flash | high
literature: cliproxy/glm-5.3-flash | high
ideator: cliproxy/glm-5.3-flash | high
implementer: cliproxy/glm-5.3-flash | high
analyst: cliproxy/glm-5.3-flash | high
prover: cliproxy/glm-5.3-flash | high
writer: cliproxy/glm-5.3-flash | high
reviewer: cliproxy/gpt-6.1-sol | medium
