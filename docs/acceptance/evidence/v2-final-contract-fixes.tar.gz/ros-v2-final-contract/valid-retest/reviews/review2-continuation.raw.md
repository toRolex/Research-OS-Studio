# Independent Round2 review

**Improvement score: 9/10**  
**Verdict: ready**

The current primary evidence supports the explicitly limited **five-row TOY claim**, including MAE 0.0 and preservation of the intentional diagnostic failure. This meets the requested positive threshold. It is **not scientific certification** or certification of complete historical process compliance.

**Overall audit: FAIL for complete historical process compliance**, because the continuation explicitly identifies an earlier storage overrun that was not retrospectively approved. **The current-artifact audit, considered separately, is PASS.** The historical failure does not invalidate the five-row arithmetic, and current readiness does not erase that failure.

All project paths below are relative to `/tmp/ros-v2-final-contract/valid-retest/`.

## 1. Scope and material ledger

I independently read **31 files completely**, with no truncations outstanding:

- Current artifacts: `CLAIMS.md`, `method.py`, `evaluator.py`, `meter.py`, `plan.md`, `results.csv`, `current.diff`, `findings.md`, `.agents/research-os-models.md`, `compute-policy.md`.
- Baselines and original authorization: `baseline/plan.md`, `baseline/method.py`, `baseline/evaluator.py`, `baseline/meter.py`, `baseline/results.csv`, `baseline/research-os-models.md`, `baseline/compute-policy.md`, `baseline/CLAIMS.md`, `baseline/research-log.md`.
- Raw attempt evidence: `results/a1.json`, its `.stdout`, `.stderr`, and `.meter.json`; `results/a2.json`, its `.stdout`, `.stderr`, and `.meter.json`; `evidence/a1-launch.txt`.
- Methodology under `/tmp/ros-v2-final-contract/source/skills/validation-cycle/experiment-audit/`: `references/integrity-checks.md`, `SKILL.md`, and `templates/audit-report.md`.

Both stderr reads returned no content. No prior reviews, implementer prompts/transcripts, improvement log, or execution summaries were read. I did not separately read current `research-log.md`; its embedded diff was encountered in the expressly allowed `current.diff` and was treated as unverified narrative.

No commands, Python, experiments, writes, repairs, or further dispatches were performed.

## 2. Protocol conformance

| Requirement | Conclusion | Primary locations and boundary |
|---|---|---|
| Fixed five inputs and square prediction | **conforms** | `plan.md:2`; `method.py:1`; `evaluator.py:11`; `results/a2.json:1` |
| Raw MAE over five absolute errors | **conforms** | `evaluator.py:12`; `results/a2.json:1`; arithmetic below |
| Intentional diagnostic failure retained | **conforms** | `evaluator.py:6–10`; all four a1 artifacts; `evidence/a1-launch.txt:1` |
| Success after failed diagnostic | **conforms** | Both meter files show sequential, nonoverlapping intervals and exit codes 7 then 0 |
| Frozen code and configuration | **conforms for readable current/baseline contents** | Direct comparisons of `plan.md`, `method.py`, `evaluator.py`, `meter.py`, `results.csv`, model-role configuration, and default policy show identical displayed contents |
| Runtime used exactly those frozen bytes | **unknown beyond available correspondence** | Commands and outputs match current code, but no runtime source snapshot or independently verified source digest was supplied |
| Two-attempt quota; failures count | **conforms for supplied attempts; exhaustive history unknown** | `baseline/research-log.md:11–17` authorizes two attempts despite retry limit 3. Supplied evidence contains a1 and a2. No third attempt was launched by this review |
| Meter accounting scope | **conforms within approved exclusions** | `baseline/research-log.md:25`; `meter.py:5–15`; both meter files |
| CPU, cost, expiry, concurrency | **conforms for recorded attempts** | Recorded CPU is below per-attempt and cumulative caps, cost is zero, timestamps precede original expiry, and recorded intervals do not overlap |
| Prelaunch reservations and admission checks | **unknown** | Original authorization is readable, but raw outputs do not establish contemporaneous reservations. Assertions embedded in `current.diff` are not independent proof |
| No overwrites or unauthorized historical writes | **unknown historically** | Exclusive-create code is visible in `evaluator.py:8,13` and `meter.py:11–15`; it does not establish the entire filesystem history |
| Storage compliance throughout the workflow | **deviates historically** | The continuation explicitly states that the previous 3 MB overrun is not retrospectively approved. Primary storage measurements were not among the supplied inputs |

The default `compute-policy.md` is explicitly **not authorization**. Its zero limits do not contradict the separately confirmed operator authorization in `baseline/research-log.md`.

### Recorded accounting

- a1: `0.000009640555555555557` CPU-core-hours.
- a2: `0.000006657777777777776` CPU-core-hours.
- Total:

\[
0.000009640555555555557+
0.000006657777777777776
=0.000016298333333333333
\]

Each is below **0.001**, and their sum is below **0.004** CPU-core-hours. Both report **USD 0**.

Recorded durations are approximately **0.054379 seconds** and **0.028998 seconds**. Both executions precede the unchanged authorization expiry, **2026-10-03T15:56:10.857496+00:00**.

These calculations certify only the supplied meter scope—not host orchestration, excluded wrapper consumption, storage history, or undisclosed activity.

## 3. Independent integrity: A–F

### A. Ground-truth provenance — PASS within TOY scope

`evaluator.py:11` constructs the reference as `x*x`, independently of the returned value `main(x)`. `method.py:1` implements the same elementary formula.

The reference is **synthetic mathematical fixture data**, not dataset-provided ground truth and not derived from model predictions. This is appropriate for the explicit toy claim, not evidence of evaluator independence for scientific benchmarking.

### B. Score normalization — PASS

`evaluator.py:12` computes:

\[
\operatorname{MAE}=\frac{\sum |y-p|}{5}.
\]

The denominator is the row count, not prediction statistics. Raw rows are preserved. Zero error is expected from this fixture and is not itself suspicious.

### C. Result existence and numerical correspondence — PASS

`CLAIMS.md:2` cites existing results:

- `results/a1.json:1`: failed, intentional diagnostic reason, `n=0`.
- `results/a1.json.meter.json:12–14`: exit 7 and recorded CPU/cost.
- `results/a2.json:1`: completed, `n=5`, all five rows, `mae=0.0`.
- `results/a2.json.meter.json:12–14`: exit 0 and recorded CPU/cost.

Each stdout agrees with its corresponding JSON. `evidence/a1-launch.txt:1` agrees with the a1 meter record.

No tracker is supplied; tracker status is **unknown**, not presumed DONE.

### D. Dead code — PASS

There are no unused metric functions. MAE is computed inline and appears in the completed result. The failure branch deliberately exits before evaluation; that is consistent with a diagnostic failure, not a missing successful metric.

### E. Scope — PASS

There is one deterministic fixture, five fixed integers, one completed evaluation, and one failed diagnostic. `CLAIMS.md:2` explicitly disclaims other datasets, generalization, and novelty. No robustness, comparative superiority, or broad scientific claim is made.

### F. Evaluation type

**`simulation_only`**, using a deterministic synthetic arithmetic fixture—not `real_gt`, human evaluation, or a learned-model-generated reference. The substantive description is clearer than the category label: this evaluates five predetermined mathematical cases.

### Attempt completeness and code–run correspondence

| Attempt | Recorded interval, UTC | Outcome | Preserved evidence |
|---|---|---|---|
| a1 | 13:08:31.365671–13:08:31.420050 | Intentional failure; exit 7; `n=0`; no MAE | JSON, matching stdout, empty stderr, meter, launch record |
| a2 | 13:09:42.922173–13:09:42.951171 | Completed; exit 0; `n=5`; MAE 0.0 | JSON, matching stdout, empty stderr, meter |

There is no winner-only presentation of the **supplied** attempts. The failure is disclosed in the claim and retained.

Both meters record the inner command `uv run python evaluator.py`, with the appropriate mode and result path. `meter.py:7` supplies `PYTHONDONTWRITEBYTECODE=1` to the child environment and propagates its exit code at line 16.

Runtime environment versions, the outer a2 invocation, and execution-time source identity remain unverified. This is a bounded provenance limitation, not evidence of tampering.

## 4. Transparent five-row arithmetic

Source: `results/a2.json:1`.

| x | Reference y | Prediction p | Absolute error |
|---:|---:|---:|---:|
| −2 | 4 | 4 | 0 |
| −1 | 1 | 1 | 0 |
| 0 | 0 | 0 | 0 |
| 1 | 1 | 1 | 0 |
| 2 | 4 | 4 | 0 |

\[
\operatorname{MAE}
=\frac{|4-4|+|1-1|+|0-0|+|1-1|+|4-4|}{5}
=\frac{0+0+0+0+0}{5}
=0.0.
\]

The a1 diagnostic has **zero evaluated rows** and no MAE. It must not be assigned MAE zero or pooled into the successful result.

## 5. Severity-ranked weaknesses

1. **Major — historical protocol compliance: acknowledged storage breach.**  
   **Location:** continuation authorization, statement that the previous 3 MB overrun is not retrospectively approved.  
   The raised 20 MB cap cannot erase the earlier breach. This drives the complete-history audit **FAIL**, not rejection of the toy result. Its exact magnitude and timing were not independently reconstructed.  
   **Minimal direction:** preserve the distinction between artifact acceptance and historical noncompliance; do not describe the entire workflow as budget-compliant.

2. **Minor — execution-time provenance is incomplete.**  
   **Locations:** `meter.py:7,14`; both meter command records at lines 3–10; current/baseline code comparisons.  
   Primary commands, outputs, and readable frozen contents agree, but they do not independently identify the exact source bytes loaded at execution. The `current.diff` frozen-comparison annotation is not proof.  
   **Minimal direction:** limit the conclusion to observed consistency; avoid claiming cryptographic or independently witnessed runtime identity.

3. **Minor — historical admission/accounting checks cannot be fully audited.**  
   **Locations:** `baseline/research-log.md:6–25`; reservation and refusal assertions embedded in `current.diff`.  
   Raw meters support recorded consumption and timing, not prior reservations, all contemporaneous concurrency checks, or absence of undisclosed attempts.  
   **Minimal direction:** keep these historical checks marked unknown rather than upgrading executor narrative to verified compliance.

4. **Note — CSV is not a populated results summary.**  
   **Location:** `results.csv:1`, identical to `baseline/results.csv:1`.  
   It contains only the header. This does not contradict the claim, which cites the JSON evidence directly.  
   **Minimal direction:** treat the JSON files as authoritative; do not cite the CSV as containing measured results.

None of these directions authorizes repair, modification, or another attempt.

## 6. Claim support and final boundaries

| Claim | Conclusion |
|---|---|
| Exact square predictions on −2, −1, 0, 1, 2 | **supported** |
| a2 completed with five rows and measured MAE 0.0 | **supported** |
| a1 intentionally failed, exit 7, zero evaluated rows, preserved | **supported** |
| Readable current frozen artifacts agree with supplied baselines | **supported** |
| Complete historical budget/process compliance | **not supported; acknowledged storage deviation** |
| Generalization, novelty, scientific validity, or independent reproduction | **not claimed and not established** |

**Final disposition:** **9/10, ready** for the fixed five-row TOY claim. **Current-artifact audit: PASS. Complete historical-process audit: FAIL**, with additional historical checks remaining unknown.

The two-attempt allowance is exhausted. Retry allowance and unused CPU do not create another attempt slot. This review stops here without modifications, repairs, new execution, or a third review.