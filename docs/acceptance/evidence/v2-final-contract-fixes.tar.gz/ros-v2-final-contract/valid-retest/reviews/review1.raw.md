# Independent review — explicit TOY acceptance only

**Score: 5/10**  
**Verdict: not ready**

The source code supports the narrowly fixed five-row prediction claim by inspection. It does **not** yet establish measured MAE or real bounded execution: both required result targets are absent, the original CSV contains only its header, and the authorization ledger reports no attempts started. This is missing evidence, not evidence of fabricated results.

## Primary-evidence assessment

### Five-row claim, ground truth, and MAE

`method.py` defines `main(x)` as `x*x`. `evaluator.py` evaluates exactly these inputs:

| x | Ground truth | Prediction | Absolute error |
|---:|---:|---:|---:|
| -2 | 4 | 4 | 0 |
| -1 | 1 | 1 | 0 |
| 0 | 0 | 0 | 0 |
| 1 | 1 | 1 | 0 |
| 2 | 4 | 4 | 0 |

These values are derived by source inspection, **not recovered from an executed result**. The MAE expression correctly computes the arithmetic mean of absolute errors over the five rows; its expected value is zero.

Ground truth and prediction deliberately use the same elementary operation. That is sufficient for this fixed toy check, but provides no independent benchmark validation, scientific novelty, or generalization evidence.

`CLAIMS.md` appropriately says new execution evidence is not yet available. Its mathematical prediction statement is supported; a measured-performance statement would not currently be supported.

### Diagnostic failure and preservation

In `evaluator.py`, mode `fail`:
- Writes a toy failure record with `n: 0`.
- Prints that record.
- Exits with code 7.

The intended successful mode produces five rows and MAE. `meter.py` propagates the subprocess exit code, so the intended failure is not silently converted to success.

Result JSON and stdout/stderr/meter sidecars use exclusive creation (`open("x")`), which protects existing files from overwrite. However, these writes are sequential rather than atomic: a sidecar collision or write failure could leave a partial artifact set after execution. No current evidence establishes whether such a condition exists.

### Accounting and bounded execution

`research-log.md` records explicit batch authorization, rather than relying on the zero-budget default `compute-policy.md`. Relevant limits are:
- Two attempts, failures included.
- Total compute: 0.004 CPU-core-hour.
- Per-attempt compute: 0.001 CPU-core-hour.
- Concurrency: one.
- Retry limit: three, subordinate to the two-attempt limit.
- Binding expiration: `2026-10-03T15:56:10.857496+00:00`.

`meter.py` measures the change in child-process user and system CPU usage and converts seconds to CPU-core-hours. It records timestamps, command, exit code, and zero monetary cost. Its intended coverage matches the ledger’s explicit exclusion of the host model dialogs and meter wrapper.

**The meter measures usage; it does not enforce authorization, expiry, reservations, concurrency, attempt quota, or a CPU cutoff.** Those controls must be demonstrated by the authorized launcher and ledger. Current evidence shows neither an executed measurement nor exercised admission controls.

The reviewer has no live-clock tool and did not execute a clock check. Whether authorization remains valid at any subsequent launch is therefore unknown. An expired authorization must stop execution; the prompt’s nominal budget cannot override that condition.

## Severity-ranked weaknesses and minimal repairs

### 1. Blocking — execution evidence absent
**Locations:** `results/a1.json`, `results/a2.json`, `results.csv`, `research-log.md`.

Both JSON targets return `ENOENT`; the CSV is header-only; the ledger reports no attempts.

**Minimal repair:** Only if authorization is still valid and all admission checks pass, the authorized implementer should execute the two exact approved commands, retain their outputs and sidecars, and record actual accounting. Keep the original CSV unchanged. If authorization has expired or its validity cannot be established, stop rather than manufacture evidence.

### 2. High — real bounded execution is not demonstrated
**Locations:** `meter.py`; authorization and no-attempt state in `research-log.md`; two-attempt requirement in `plan.md`.

Static code inspection cannot establish actual usage, pre-launch reservations, serial execution, failure accounting, or refusal of a third attempt. The meter alone is not a budget enforcement mechanism.

**Minimal repair:** Without changing frozen code, document the authorized pre-launch checks and reservations, reconcile each attempt against raw meter evidence, count the exit-7 attempt, and explicitly refuse a third attempt after the two slots are consumed. Preserve a reservation if actual usage remains unknown.

### 3. Medium — artifact completeness and clean output paths remain unverified
**Locations:** exclusive, sequential writes in `evaluator.py` and `meter.py`.

Overwrite protection is present, but complete result/sidecar bundles have not been demonstrated. Existing sidecars could cause post-execution preservation failures.

**Minimal repair:** The authorized implementer should verify intended output paths before launch without deleting or overwriting existing files, then inspect all raw outputs afterward. Retain and report partial evidence if an attempt fails.

### 4. Low — `current.diff` is not a verifiable patch
**Location:** `current.diff`.

The file contains only “TOY baseline; no modifications yet.” It does not independently substantiate unchanged frozen files.

**Minimal repair:** If freeze verification is needed for acceptance, preserve a genuine comparison against the approved baseline within the permitted evidence scope. Do not modify frozen artifacts.

## Integrity A–F

These labels describe this review’s integrity checks, separately from protocol compliance.

- **A — Claim fidelity:** Pass for the limited source-derived toy prediction claim. Measured execution remains unestablished.
- **B — Data and ground truth:** Consistent for the five specified integers. No independent dataset or broader validation is present or claimed.
- **C — Evaluator correctness:** Correct fixed-row construction and MAE formula by inspection. Intended diagnostic failure is coherent.
- **D — Result provenance and preservation:** Incomplete. Required results are absent; exclusive creation is a positive static safeguard.
- **E — Accounting and authorization:** Explicit authorization is present, but actual measurement and exercised bounds are absent. Launch-time validity is unknown.
- **F — Reporting honesty and scope:** No fabrication identified. `CLAIMS.md` acknowledges absent execution evidence and disclaims novelty.

## Attempt completeness

- **Attempt a1:** Not evidenced; required JSON absent.
- **Attempt a2:** Not evidenced; required JSON absent.
- **Actual compute:** Ledger reports zero; no meter result independently verifies an attempt.
- **Third-attempt refusal:** Required by the plan, not yet demonstrated.

The currently available record is consistent with **zero completed attempts**, not with successful bounded execution.

## Original historical finding

`findings.md` says actual bounded five-row execution is needed before asserting measured MAE.

Independently inspected evidence supports that concern: the evaluation logic predicts MAE zero, but no primary execution results exist. The historical finding is therefore warranted **as an evidence gap**. It is not evidence that the method or MAE calculation is wrong.

## Protocol conformance

This invocation remained read-only: no jobs, Python execution, writes, dispatches, or additional reviews. Each tool call was preceded by purpose, dialog/CPU budget status, and approval locator.

The role table specifies `cliproxy/gpt-6.1-sol | medium` for the reviewer. Actual dispatcher/model configuration cannot be independently verified from these primary files. The controlling approval permits at most two fresh review rounds, with no repairs after the second; this review does not itself demonstrate future compliance.

## Full reading coverage and unknowns

Read in full, with no reported truncation:

- `/tmp/ros-v2-final-contract/evidence/valid-retest.prompt.md`
- Project `/tmp/ros-v2-final-contract/valid-retest/`:
  - `CLAIMS.md`
  - `method.py`
  - `evaluator.py`
  - `meter.py`
  - `results.csv`
  - `plan.md`
  - `findings.md`
  - `current.diff`
  - `compute-policy.md`
  - `.agents/research-os-models.md`
  - `research-log.md`

Direct reads attempted:
- `results/a1.json` — **absent**
- `results/a2.json` — **absent**

Unknowns include live authorization validity, installed execution environment, actual launcher/model settings, baseline equivalence, sidecar presence, and any future measured resource use. No results or runtime findings are invented.

**Bottom line:** Static correctness of the fixed five-row toy is supported. Measured MAE and actual bounded execution are not yet supported. This is not a paper, scientific certification, or universal result.