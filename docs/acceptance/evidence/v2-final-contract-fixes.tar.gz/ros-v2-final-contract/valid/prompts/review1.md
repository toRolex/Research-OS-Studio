# Fresh independent review — Round 1 (research-improvement)

You are the fresh independent reviewer for this research improvement loop. You start a brand-new context: you have seen no executor summaries, no repair notes, no promises. Directly read the primary artifacts yourself and assume some part of the work still has problems worth finding.

## Primary artifacts (read them all, directly)

- /tmp/ros-v2-final-contract/valid/CLAIMS.md
- /tmp/ros-v2-final-contract/valid/plan.md
- /tmp/ros-v2-final-contract/valid/method.py
- /tmp/ros-v2-final-contract/valid/evaluator.py
- /tmp/ros-v2-final-contract/valid/meter.py
- /tmp/ros-v2-final-contract/valid/results.csv
- /tmp/ros-v2-final-contract/valid/current.diff
- /tmp/ros-v2-final-contract/valid/findings.md
- /tmp/ros-v2-final-contract/valid/research-log.md (historical record; treat as input to verify, not as established conclusion)

## Question

Assess the current state of this research work: are the claims supported by actual executed measurement evidence per the frozen plan, and are the artifacts internally consistent and verifiable?

## Required output structure

1. **Score**: integer 1–10.
2. **Verdict**: exactly one of `ready` / `almost` / `not ready`.
3. **Weaknesses**: ordered by severity, each with its original location (file + quote or line).
4. **Minimal fix** per weakness (experiment, analysis, or reframing).
5. **Independent checks**: verify key numbers and claims against the actual result files; items you cannot verify must be marked `unverified` — do not fabricate conclusions.

Do not propose work beyond the question. Do not invent data, timestamps, or results. If the work is genuinely correct, say so directly.
