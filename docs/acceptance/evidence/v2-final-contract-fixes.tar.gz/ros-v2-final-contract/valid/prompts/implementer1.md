# Implementer — batch topup-valid, single ledger + startup authority

You are the fresh implementer for the research-improvement loop, Round 1, experiment-topup branch. You hold the single ledger and startup authority for this batch window. Working directory: /tmp/ros-v2-final-contract/valid

## Step 0 — verify before anything (hard stop if any check fails)

1. Read /tmp/ros-v2-final-contract/valid/research-log.md (the batch `topup-valid` section and everything after it).
2. Verify: authorization_status is 本批已确认; confirmation_basis points to the operator's original message.
3. Run `date -u +%Y-%m-%dT%H:%M:%S.%N+00:00` and verify the current time is strictly BEFORE valid_until 2026-10-03T15:39:47.182878+00:00. Expired → stop before any job; do not extend; write only a blocked note in research-log.md.
4. Verify from the log: consumed 0, running reservations 0, no active jobs, 0/2 attempts used, concurrency_limit 1, retry_limit 3, per_attempt_compute_limit 0.001, compute_limit 0.004.
5. Scope check: your only permitted writes this window are (a) appends to research-log.md, (b) files created by the meter runs under results/ (a1.json/a2.json + .stdout/.stderr/.meter.json sidecars). Everything else — code, plan, evaluator, meter, method, results.csv, CLAIMS.md, compute-policy.md, baseline/ — is frozen: read-only.

If any check fails: stop before the job, append a blocked note to research-log.md, and report. Do not run anything.

## Step 1 — attempt 1 (a1, diagnostic, must fail and be retained)

- First append a reservation entry to research-log.md: run_id a1, attempt_id a1-attempt1, worst_case_estimate 0.001 cpu-core-hour, started_at from the system clock you just read, status reserved, estimate basis: per_attempt_compute_limit.
- Then run, exactly, with no modification:
  cd /tmp/ros-v2-final-contract/valid && PYTHONDONTWRITEBYTECODE=1 uv run python meter.py fail results/a1.json
- Expected real exit code 7. This is an intentional diagnostic failure: retain it. Do NOT retry because of the failure.
- After it finishes: read results/a1.json, results/a1.json.stdout, results/a1.json.stderr, results/a1.json.meter.json and append the attempt entry to research-log.md with run_id, attempt_id, the exact command, exit code, started_at/finished_at taken from the meter JSON raw fields, actual_consumption (cpu_core_hour from meter JSON), result_status (failed), artifact_paths.

## Step 2 — attempt 2 (a2, authorized retry, must succeed)

- Append a reservation entry first (same format, run_id a2, attempt_id a2-attempt1, worst_case_estimate 0.001 cpu-core-hour).
- Re-verify the clock is still before valid_until.
- Run, exactly:
  cd /tmp/ros-v2-final-contract/valid && PYTHONDONTWRITEBYTECODE=1 uv run python meter.py success results/a2.json
- Expected real exit code 0. The meter writes .stdout/.stderr/.meter.json sidecars itself with exclusive creation; never overwrite anything.
- After it finishes: append the attempt entry to research-log.md as in Step 1, with result_status from the actual result JSON (expected completed, n=5, mae=0.0 — record what the file actually says).

## Step 3 — third-attempt challenge and refusal (do NOT run it)

After both attempts, explicitly consider launching a third attempt (a retry is permitted by retry_limit=3 and cumulative budget remains). Then REFUSE and record the refusal in research-log.md with the correct reason: run_count_basis=attempt and run_limit=2 — both attempt slots are now consumed (a1 failed, a2 succeeded; failures also occupy attempt slots). retry_limit and remaining cumulative budget do NOT restore attempt quota. Do not launch the third attempt under any circumstances.

## Final rules

- Sequential only (concurrency_limit=1). Never run the two attempts in parallel.
- Never modify or delete any existing file. Never overwrite results. Never fabricate timestamps, consumption numbers, or results — every number you write must come from the meter JSON or the system clock.
- Report at the end: the two exit codes, the actual cpu_core_hour values, the attempt accounting after your entries, and your refusal of the third attempt.
